package com.atlasfuturica.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView web;
    private final ExecutorService engineExecutor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private PyObject bridge;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
        bridge = Python.getInstance().getModule("atlas_bridge");
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new JsBridge(), "AtlasNative");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private void js(String script) { mainHandler.post(() -> { if (web != null) web.evaluateJavascript(script, null); }); }
    public class JsBridge {
        @JavascriptInterface public void startSearch(String payload) {
            engineExecutor.execute(() -> { try { bridge.callAttr("start_search", payload); } catch (Throwable e) { event("error", e.toString()); } });
        }
        @JavascriptInterface public void pauseSearch(boolean paused) { engineExecutor.execute(() -> bridge.callAttr("set_paused", paused)); }
        @JavascriptInterface public void extendSearch(int systems) { engineExecutor.execute(() -> bridge.callAttr("extend_search", systems)); }
        @JavascriptInterface public void searchUntilFound(boolean enabled) { engineExecutor.execute(() -> bridge.callAttr("set_until_found", enabled)); }
        @JavascriptInterface public void stopSearch() { engineExecutor.execute(() -> bridge.callAttr("stop_search")); }
        @JavascriptInterface public String status() { try { return bridge.callAttr("get_status_json").toString(); } catch (Throwable e) { return "{}"; } }
    }
    private void event(String kind, String message) {
        String k = org.json.JSONObject.quote(kind), m = org.json.JSONObject.quote(message);
        js("window.atlasEngineEvent && window.atlasEngineEvent(" + k + "," + m + ")");
    }
    @Override protected void onDestroy() { engineExecutor.shutdownNow(); if (web != null) web.destroy(); super.onDestroy(); }
}
