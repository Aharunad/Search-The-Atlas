#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import fibonacci_nms_grass_colour_rule_v20a8a as colour
import fibonacci_nms_native_sky_index_rule_v20d3r8 as native_sky

VERSION = "20D3R8.0.0"
ATMOSPHERE_CHANNELS = (
    ("Sky", 17),
    ("SkyHorizon", 22),
    ("SkyFog", 23),
    ("SkyHeightFog", 24),
    ("SkySunset", 25),
    ("SkyNight", 26),
)
DAY_FILTER_VALUES = native_sky.DAY_FILTER_VALUES
PALETTE_FILTER_VALUES = (
    "Blue",
    "Cyan",
    "Green",
    "Yellow / Gold",
    "Orange / Red",
    "Purple / Pink",
    "Grey / Neutral",
    "White / Pale",
    "Dark / Unusual",
)

# Live-rendered sky corrections are separate from exact native SkyColour data.
# This preserves reverse-engineered native values while making user-facing
# searches and exports describe an observed in-game broad appearance.
VERIFIED_RENDERED_DAY_SKY_OVERRIDES = {
    "#487CDA": {
        "family": "Pink / Magenta",
        "display": "Pink / Magenta (verified; native Blue #487CDA)",
        "status": "live_rendered_control_verified",
        "control_portal": "13F15051E655",
        "control_planet_number": 1,
        "verified_date": "2026-07-26",
        "evidence": "clear-day in-game screenshot supplied by FIBONACCI",
    },
}


def rendered_day_sky_summary(native_day: dict[str, Any]) -> dict[str, Any]:
    native_hex = str(native_day.get("hex", "")).upper()
    override = VERIFIED_RENDERED_DAY_SKY_OVERRIDES.get(native_hex)
    if override is not None:
        return dict(override)
    return {
        "family": str(native_day.get("family", "")),
        "display": str(native_day.get("display", "")),
        "status": "native_family_used_no_live_override",
        "control_portal": None,
        "control_planet_number": None,
        "verified_date": None,
        "evidence": None,
    }


def broad_family(raw: str) -> str:
    return {
        "Black / very dark": "Dark / Unusual",
        "White / pale neutral": "White / Pale",
        "Grey / neutral": "Grey / Neutral",
        "Red": "Orange / Red",
        "Orange": "Orange / Red",
        "Yellow": "Yellow / Gold",
        "Green": "Green",
        "Cyan": "Cyan",
        "Blue": "Blue",
        "Purple": "Purple / Pink",
        "Pink / magenta": "Purple / Pink",
    }.get(str(raw), "Mixed / Unusual")


def channel_result(
    name: str,
    palette_index: int,
    palette: dict[str, Any],
    raw: dict[str, Any],
) -> dict[str, Any]:
    rows = []
    categories = []
    hex_values = []
    for slot, (source_index, rgba) in enumerate(
        zip(raw["source_indices"], raw["colours"])
    ):
        rgba = [float(value) for value in rgba]
        family = colour.colour_family(rgba)
        broad = broad_family(family)
        hexa = colour.rgba_hex(rgba).upper()
        rows.append({
            "slot": slot,
            "source_index": int(source_index),
            "rgba": rgba,
            "hex": hexa,
            "colour_family": family,
            "broad_family": broad,
        })
        if broad not in categories:
            categories.append(broad)
        hex_values.append(hexa)
    return {
        "channel": name,
        "palette_index": int(palette_index),
        "num_colours_name": palette.get(
            "num_colours_name",
            "",
        ),
        "source_indices": [
            int(value)
            for value in raw["source_indices"]
        ],
        "colours": rows,
        "primary": rows[0],
        "broad_categories": categories,
        "hex_values": hex_values,
        "summary": " | ".join(
            f"{row['broad_family']} {row['hex']}"
            for row in rows
        ),
    }


def recovered_seeds(
    planet_root_seed: int,
) -> dict[str, int]:
    child_3 = colour.generate_child_seeds(
        planet_root_seed,
        3,
    )[2]
    state = colour.MWCState.from_seed(child_3)
    palette_writer_seed, atmosphere_writer_seed = (
        colour.derive_seed_pair(state)
    )
    return {
        "child_3": int(child_3),
        "palette_writer_seed": int(
            palette_writer_seed
        ),
        "atmosphere_writer_seed": int(
            atmosphere_writer_seed
        ),
    }


class AtmosphereColourRule:
    def __init__(
        self,
        rule_data_path: Path,
        native_sky_tables_path: Path,
        native_sky_regression_path: Path,
    ):
        self.palette_rule = colour.GrassColourRule(
            rule_data_path
        )
        self.native_sky_rule = (
            native_sky.NativeSkyIndexRule(
                native_sky_tables_path
            )
        )
        self.native_sky_regression_path = Path(
            native_sky_regression_path
        )

    def predict(
        self,
        *,
        planet_root_seed: int,
        biome_source_file: str,
        biome: int,
        biome_subtype: int,
    ) -> dict[str, Any]:
        palette_path, palettes = (
            self.palette_rule.merged_palette_list(
                biome_source_file
            )
        )
        seeds = recovered_seeds(planet_root_seed)

        main_state = colour.MWCState.from_seed(
            seeds["palette_writer_seed"]
        )
        cloud_raw = None
        for palette_index in range(17):
            cloud_raw = colour.write_one_palette(
                main_state,
                palettes[palette_index],
            )
        if cloud_raw is None:
            raise RuntimeError(
                "Cloud palette was not generated."
            )

        channels = {
            "Cloud": channel_result(
                "Cloud",
                16,
                palettes[16],
                cloud_raw,
            ),
        }
        for name, palette_index in ATMOSPHERE_CHANNELS:
            raw = colour.write_one_palette(
                colour.MWCState.from_seed(
                    seeds["atmosphere_writer_seed"]
                ),
                palettes[palette_index],
            )
            channels[name] = channel_result(
                name,
                palette_index,
                palettes[palette_index],
                raw,
            )

        native = self.native_sky_rule.predict(
            planet_root_seed=planet_root_seed,
            biome=biome,
            biome_subtype=biome_subtype,
        )
        day = native["day_sky"]
        rendered_day = rendered_day_sky_summary(day)
        dusk = native["dusk_sky"]
        night = native["night_sky"]

        flat = {
            "atmosphere_child_3_seed_hex": (
                f"0x{seeds['child_3']:016X}"
            ),
            "atmosphere_writer_seed_hex": (
                f"0x{seeds['atmosphere_writer_seed']:016X}"
            ),
            "atmosphere_seed_rule": (
                "orchestrator_child_3 derived seed pair 2; "
                "state reset per atmosphere channel"
            ),
            "native_sky_child_14_seed_hex": (
                native["child_seed_hex"]
            ),
            "native_sky_index_rule": native["method"],
            "native_day_colour_index": int(
                native["day_colour_index"]
            ),
            "native_dusk_colour_index": int(
                native["dusk_colour_index"]
            ),
            "native_night_colour_index": int(
                native["night_colour_index"]
            ),
            "native_day_list_source": (
                native["day_list_source"]
            ),
            "native_dusk_list_source": (
                native["dusk_list_source"]
            ),
            "native_night_list_source": (
                native["night_list_source"]
            ),
            "native_day_sky_hex": day["hex"],
            "native_day_sky_family": day["family"],
            "native_day_sky_display": day["display"],
            "native_day_sky_rgba": dict(day["rgba"]),
            "rendered_day_sky_family": rendered_day["family"],
            "rendered_day_sky_display": rendered_day["display"],
            "rendered_day_sky_status": rendered_day["status"],
            "rendered_day_sky_control_portal": rendered_day["control_portal"],
            "rendered_day_sky_control_planet_number": rendered_day["control_planet_number"],
            "rendered_day_sky_verified_date": rendered_day["verified_date"],
            "rendered_day_sky_evidence": rendered_day["evidence"],
            "native_dusk_sky_hex": dusk["hex"],
            "native_dusk_sky_family": dusk["family"],
            "native_dusk_sky_display": dusk["display"],
            "native_dusk_sky_rgba": dict(dusk["rgba"]),
            "native_night_sky_hex": night["hex"],
            "native_night_sky_family": night["family"],
            "native_night_sky_display": night["display"],
            "native_night_sky_rgba": dict(
                night["rgba"]
            ),
            # Compatibility keys retained for existing search,
            # exports, profiles and GUI state.
            "day_atmosphere_category": rendered_day["family"],
            "day_atmosphere_representative_hex": (
                day["hex"]
            ),
            "day_atmosphere_display": rendered_day["display"],
            "day_atmosphere_method": native["method"],
            "day_atmosphere_validation": (
                "V20D3R7R1 fresh independent validation: "
                "18/18 planets and 54/54 native outputs exact"
            ),
            "day_atmosphere_claim": (
                native["claim"] + " User-facing rendered appearance may include "
                "live-verified exact-value overrides while native fields remain unchanged."
            ),
            "atmosphere_palette_prediction_status": (
                "validated_v20d1r2_36_of_36_address_only"
            ),
            "native_sky_index_prediction_status": (
                "validated_v20d3r7r1_54_of_54_fresh_"
                "independent"
            ),
            "atmosphere_palette_claim": (
                "Exact generated Cloud, Sky, SkyHorizon, "
                "SkyFog, SkyHeightFog, SkySunset and "
                "SkyNight palette sequences."
            ),
        }

        key_map = {
            "Cloud": "cloud",
            "Sky": "sky",
            "SkyHorizon": "horizon",
            "SkyFog": "fog",
            "SkyHeightFog": "height_fog",
            "SkySunset": "sunset",
            "SkyNight": "night",
        }
        for native_name, key in key_map.items():
            channel = channels[native_name]
            flat.update({
                f"atmosphere_{key}_source_indices": list(
                    channel["source_indices"]
                ),
                f"atmosphere_{key}_palette_colours": list(
                    channel["colours"]
                ),
                f"atmosphere_{key}_categories": list(
                    channel["broad_categories"]
                ),
                f"atmosphere_{key}_hex_values": list(
                    channel["hex_values"]
                ),
                f"atmosphere_{key}_summary": (
                    channel["summary"]
                ),
                f"atmosphere_{key}_primary_hex": (
                    channel["primary"]["hex"]
                ),
                f"atmosphere_{key}_primary_family": (
                    channel["primary"]["broad_family"]
                ),
            })

        return {
            "planet_root_seed_hex": (
                f"0x{planet_root_seed & colour.MASK64:016X}"
            ),
            "biome_source_file": (
                biome_source_file
                .replace("\\", "/")
                .strip()
                .upper()
            ),
            "colour_palette_file": palette_path,
            "seeds": {
                key: f"0x{value:016X}"
                for key, value in seeds.items()
            },
            "channels": channels,
            "native_sky_indices": native,
            "day_appearance": {
                "category": day["family"],
                "representative_hex": day["hex"],
                "representative_rgba": dict(
                    day["rgba"]
                ),
                "display": day["display"],
                "method": native["method"],
                "validation": flat[
                    "day_atmosphere_validation"
                ],
                "claim": native["claim"],
            },
            "flat_fields": flat,
            "claim": (
                flat["atmosphere_palette_claim"]
                + " "
                + native["claim"]
            ),
        }

    def verify_regression(
        self,
        regression_path: Path,
    ) -> dict[str, Any]:
        payload = json.loads(
            Path(regression_path).read_text(
                encoding="utf-8-sig"
            )
        )
        failures = []
        checks = 0
        correct = 0

        for expected in payload.get("rows", []):
            # Palette regression predates the native index
            # closure and does not contain biome/subtype for all
            # rows. Verify only its exact palette schedule here.
            palette_path, palettes = (
                self.palette_rule.merged_palette_list(
                    expected["biome_source_file"]
                )
            )
            seeds = recovered_seeds(
                int(expected["planet_root_seed_hex"], 0)
            )
            checks += 1
            if (
                f"0x{seeds['atmosphere_writer_seed']:016X}"
                == expected[
                    "atmosphere_writer_seed_hex"
                ]
            ):
                correct += 1
            else:
                failures.append({
                    "portal": expected["planet_portal"],
                    "field": "atmosphere_writer_seed",
                })

            main_state = colour.MWCState.from_seed(
                seeds["palette_writer_seed"]
            )
            cloud_raw = None
            for palette_index in range(17):
                cloud_raw = colour.write_one_palette(
                    main_state,
                    palettes[palette_index],
                )
            channels = {
                "Cloud": channel_result(
                    "Cloud",
                    16,
                    palettes[16],
                    cloud_raw,
                ),
            }
            for channel_name, palette_index in (
                ATMOSPHERE_CHANNELS
            ):
                raw = colour.write_one_palette(
                    colour.MWCState.from_seed(
                        seeds[
                            "atmosphere_writer_seed"
                        ]
                    ),
                    palettes[palette_index],
                )
                channels[channel_name] = channel_result(
                    channel_name,
                    palette_index,
                    palettes[palette_index],
                    raw,
                )

            for (
                channel_name,
                channel_expected,
            ) in expected["channels"].items():
                checks += 2
                channel_actual = channels[
                    channel_name
                ]
                if (
                    channel_actual["source_indices"]
                    == channel_expected[
                        "source_indices"
                    ]
                ):
                    correct += 1
                else:
                    failures.append({
                        "portal": expected[
                            "planet_portal"
                        ],
                        "channel": channel_name,
                        "field": "source_indices",
                    })
                if (
                    channel_actual["hex_values"]
                    == channel_expected["hex_values"]
                ):
                    correct += 1
                else:
                    failures.append({
                        "portal": expected[
                            "planet_portal"
                        ],
                        "channel": channel_name,
                        "field": "hex_values",
                    })

        native_result = (
            self.native_sky_rule.verify_regression(
                self.native_sky_regression_path
            )
        )
        checks += int(native_result["total"])
        correct += int(native_result["correct"])
        failures.extend(
            {
                "native_sky_index": True,
                **failure,
            }
            for failure in native_result[
                "failures"
            ]
        )

        exact = (
            checks > 0
            and correct == checks
            and not failures
            and native_result["exact"]
        )
        return {
            "version": VERSION,
            "status": (
                "PASS_ATMOSPHERE_AND_NATIVE_SKY_"
                "REGRESSION_V20D3R8"
                if exact
                else "ERROR_ATMOSPHERE_AND_NATIVE_SKY_"
                "REGRESSION_V20D3R8"
            ),
            "exact": exact,
            "correct": correct,
            "total": checks,
            "planet_count": (
                len(payload.get("rows", []))
                + int(native_result["planet_count"])
            ),
            "palette_planet_count": len(
                payload.get("rows", [])
            ),
            "native_sky_planet_count": int(
                native_result["planet_count"]
            ),
            "native_sky_regression": native_result,
            "failures": failures,
            "claim": (
                "Exact atmosphere palette schedule plus "
                "24-planet native sky-index regression, "
                "including 18 fresh independent planets."
            ),
        }
