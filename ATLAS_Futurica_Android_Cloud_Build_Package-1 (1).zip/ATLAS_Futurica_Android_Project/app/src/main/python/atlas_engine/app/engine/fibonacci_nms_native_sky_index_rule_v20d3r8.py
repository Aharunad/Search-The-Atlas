#!/usr/bin/env python3
"""Exact current-build native Day/Dusk/Night sky-index replay.

Recovered in V20D3R6 and independently validated in V20D3R7R1 across:
- 3 fresh systems;
- 18 fresh planets;
- 54/54 native Day/Dusk/Night selector outputs.

Native route:
planet root seed -> child seed 14 -> MWC state
draw 1 -> weighted DayColourIndex
draw 2 -> DuskColourIndex by unsigned mulhi(count)
draw 3 -> NightColourIndex by unsigned mulhi(count)
"""
from __future__ import annotations

import json
import struct
from pathlib import Path
from typing import Any

VERSION = "20D3R8.0.0"
MASK32 = 0xFFFFFFFF
MASK64 = 0xFFFFFFFFFFFFFFFF
MWC_MULTIPLIER = 0x5A76F899
AVALANCHE_A1 = 0x64DD81482CBD31D7
AVALANCHE_A2 = 0xE36AA5C613612997
CHILD_SEED_ORDINAL = 14
FLOAT_EPSILON = 1.1920928955078125e-07
INVERSE_U32 = 2.3283064370807974e-10

DAY_FILTER_VALUES = (
    "Blue",
    "Cyan",
    "Green",
    "Yellow / Gold",
    "Orange / Gold",
    "Purple / Pink",
    "Purple / Blue",
    "Grey / Neutral",
    "Mixed / Neutral",
)


def f32(value: float) -> float:
    return struct.unpack("<f", struct.pack("<f", float(value)))[0]


def ror32(value: int, count: int) -> int:
    value &= MASK32
    count &= 31
    return ((value >> count) | (value << (32 - count))) & MASK32


def avalanche(value: int) -> int:
    value &= MASK64
    value ^= value >> 33
    value = (value * AVALANCHE_A1) & MASK64
    value ^= value >> 33
    value = (value * AVALANCHE_A2) & MASK64
    value ^= value >> 33
    return value & MASK64


class MWC:
    def __init__(self, seed: int):
        low = seed & MASK32
        if low == 0:
            low = 1
        self.low = low
        self.carry = (
            ror32(low, 16)
            ^ ((seed >> 32) & MASK32)
            ^ low
        ) & MASK32

    def draw(self) -> int:
        combined = (
            MWC_MULTIPLIER * self.low + self.carry
        ) & MASK64
        self.low = combined & MASK32
        self.carry = (combined >> 32) & MASK32
        return self.low


def generate_child_seeds(
    seed: int,
    count: int = 26,
) -> list[int]:
    state = MWC(seed)
    output: list[int] = []
    for _ in range(count):
        low = state.draw()
        high = state.draw()
        output.append(avalanche((high << 32) | low))
    return output


def effective_biome_index(
    biome: int,
    biome_subtype: int,
) -> int:
    if int(biome_subtype) == 25:
        return 12  # Swamp
    if int(biome_subtype) == 26:
        return 13  # Lava
    return int(biome)


def normalize_family(value: str) -> str:
    return {
        "Blue": "Blue",
        "Cyan": "Cyan",
        "Green": "Green",
        "Yellow / gold": "Yellow / Gold",
        "Orange / gold": "Orange / Gold",
        "Purple / pink": "Purple / Pink",
        "Purple / blue": "Purple / Blue",
        "Grey / neutral": "Grey / Neutral",
        "Mixed / neutral": "Mixed / Neutral",
    }.get(str(value), str(value))


class NativeSkyIndexRule:
    def __init__(self, tables_path: Path):
        self.tables_path = Path(tables_path)
        self.tables = json.loads(
            self.tables_path.read_text(encoding="utf-8-sig")
        )

    @staticmethod
    def filter_values() -> tuple[str, ...]:
        return DAY_FILTER_VALUES

    def _settings(
        self,
        phase: str,
        biome: int,
        biome_subtype: int,
    ) -> tuple[list[dict[str, Any]], str]:
        table = self.tables[phase]
        effective = effective_biome_index(
            biome,
            biome_subtype,
        )
        per_biome = table.get("per_biome", [])
        if 0 <= effective < len(per_biome):
            row = per_biome[effective]
            settings = list(row.get("settings", []))
            if settings:
                return settings, str(row.get("name", effective))
        return list(table["generic"]), "GenericSettings"

    @staticmethod
    def _weighted_day_index(
        state: MWC,
        settings: list[dict[str, Any]],
    ) -> tuple[int, dict[str, Any]]:
        if not settings:
            raise RuntimeError("Native Day sky settings list is empty.")

        total = f32(0.0)
        for entry in settings:
            total = f32(
                total + f32(entry["selection_weighting"])
            )

        draw_word = state.draw()
        random_value = f32(
            f32(draw_word * INVERSE_U32)
        )
        target = f32(
            f32(
                random_value
                * f32(total - f32(FLOAT_EPSILON))
            )
            + f32(FLOAT_EPSILON)
        )

        cumulative = f32(0.0)
        selected = 0
        for index, entry in enumerate(settings):
            cumulative = f32(
                cumulative
                + f32(entry["selection_weighting"])
            )
            selected = index
            if cumulative >= target:
                break

        return selected, {
            "draw_word": draw_word,
            "draw_word_hex": f"0x{draw_word:08X}",
            "weight_sum_f32": total,
            "target_f32": target,
            "selected_cumulative_f32": cumulative,
        }

    @staticmethod
    def _uniform_index(
        state: MWC,
        settings: list[dict[str, Any]],
    ) -> tuple[int, dict[str, Any]]:
        if not settings:
            raise RuntimeError("Native sky settings list is empty.")
        draw_word = state.draw()
        index = (
            (draw_word & MASK32) * len(settings)
        ) >> 32
        return int(index), {
            "draw_word": draw_word,
            "draw_word_hex": f"0x{draw_word:08X}",
            "count": len(settings),
        }

    @staticmethod
    def _sky_summary(
        entry: dict[str, Any],
    ) -> dict[str, Any]:
        sky = dict(entry["colours"]["SkyColour"])
        family = normalize_family(sky["family"])
        return {
            "rgba": dict(sky["rgba"]),
            "hex": str(sky["hex"]).upper(),
            "family": family,
            "display": f"{family} {str(sky['hex']).upper()}",
        }

    def predict(
        self,
        *,
        planet_root_seed: int,
        biome: int,
        biome_subtype: int,
    ) -> dict[str, Any]:
        child_seed = generate_child_seeds(
            int(planet_root_seed),
            CHILD_SEED_ORDINAL,
        )[CHILD_SEED_ORDINAL - 1]
        state = MWC(child_seed)

        day_settings, day_source = self._settings(
            "DAY",
            biome,
            biome_subtype,
        )
        dusk_settings, dusk_source = self._settings(
            "DUSK",
            biome,
            biome_subtype,
        )
        night_settings, night_source = self._settings(
            "NIGHT",
            biome,
            biome_subtype,
        )

        day_index, day_draw = self._weighted_day_index(
            state,
            day_settings,
        )
        dusk_index, dusk_draw = self._uniform_index(
            state,
            dusk_settings,
        )
        night_index, night_draw = self._uniform_index(
            state,
            night_settings,
        )

        day_entry = day_settings[day_index]
        dusk_entry = dusk_settings[dusk_index]
        night_entry = night_settings[night_index]

        return {
            "version": VERSION,
            "child_seed_ordinal": CHILD_SEED_ORDINAL,
            "child_seed": child_seed,
            "child_seed_hex": f"0x{child_seed:016X}",
            "effective_biome_index": effective_biome_index(
                biome,
                biome_subtype,
            ),
            "day_colour_index": day_index,
            "dusk_colour_index": dusk_index,
            "night_colour_index": night_index,
            "day_list_source": day_source,
            "dusk_list_source": dusk_source,
            "night_list_source": night_source,
            "day_entry": day_entry,
            "dusk_entry": dusk_entry,
            "night_entry": night_entry,
            "day_sky": self._sky_summary(day_entry),
            "dusk_sky": self._sky_summary(dusk_entry),
            "night_sky": self._sky_summary(night_entry),
            "draws": {
                "day": day_draw,
                "dusk": dusk_draw,
                "night": night_draw,
            },
            "method": (
                "native writer RVA 0x16FEC00; "
                "planet child seed 14; draws 1/2/3"
            ),
            "claim": (
                "Exact native DayColourIndex, DuskColourIndex and "
                "NightColourIndex plus selected current-build sky-table "
                "entries. Final rendered screenshots can still vary with "
                "solar angle, weather blending, exposure and renderer LUTs."
            ),
        }

    def verify_regression(
        self,
        regression_path: Path,
    ) -> dict[str, Any]:
        payload = json.loads(
            Path(regression_path).read_text(
                encoding="utf-8-sig"
            )
        )
        failures: list[dict[str, Any]] = []
        correct = 0
        total = 0

        for expected in payload.get("rows", []):
            actual = self.predict(
                planet_root_seed=int(
                    expected["planet_root_seed_hex"],
                    0,
                ),
                biome=int(expected["biome"]),
                biome_subtype=int(
                    expected["biome_subtype"]
                ),
            )
            checks = (
                (
                    "day_colour_index",
                    actual["day_colour_index"],
                    int(expected["day_colour_index"]),
                ),
                (
                    "dusk_colour_index",
                    actual["dusk_colour_index"],
                    int(expected["dusk_colour_index"]),
                ),
                (
                    "night_colour_index",
                    actual["night_colour_index"],
                    int(expected["night_colour_index"]),
                ),
                (
                    "day_sky_hex",
                    actual["day_sky"]["hex"],
                    str(expected["day_sky_hex"]).upper(),
                ),
            )
            for field, observed, wanted in checks:
                total += 1
                if observed == wanted:
                    correct += 1
                else:
                    failures.append({
                        "planet_portal": expected[
                            "planet_portal"
                        ],
                        "field": field,
                        "expected": wanted,
                        "actual": observed,
                    })

        exact = (
            total > 0
            and correct == total
            and not failures
        )
        return {
            "version": VERSION,
            "status": (
                "PASS_NATIVE_SKY_INDEX_REGRESSION_V20D3R8"
                if exact
                else "ERROR_NATIVE_SKY_INDEX_REGRESSION_V20D3R8"
            ),
            "exact": exact,
            "correct": correct,
            "total": total,
            "planet_count": len(payload.get("rows", [])),
            "current_control_planets": int(
                payload.get("current_control_planets", 0)
            ),
            "fresh_independent_planets": int(
                payload.get("fresh_independent_planets", 0)
            ),
            "failures": failures,
            "claim": (
                "24 planets exact: six current controls and "
                "18 fresh independent planets."
            ),
        }
