#!/usr/bin/env python3
"""
FIBONACCI NMS ADDRESS-ONLY BUILDING LEVEL + HAS SCRAP REPLAY V4P

V4P converts V4O's live table capture into a completely offline
portal-address predictor.

Address-derived inputs:
- root planet seed, Biome, BiomeSubType and planet class from V4J1;
- child seed #1 from the exact 26-child seed fanout;
- exact child-1 pre-loop RNG schedule.

Build-global input:
- V4O's captured eight-value HasScrap eligibility vector.

Outputs:
- BuildingLevel;
- global scrap-gate draw;
- eligibility decision;
- HasScrap.

Safety:
- NMS does not need to be open;
- no process access;
- no process-memory writes;
- no game/save/MODS/settings/EXE/DLL writes.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import json
import math
import struct
import sys
from argparse import Namespace
from datetime import datetime
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
VENDOR = HERE / "vendor"
if VENDOR.is_dir():
    sys.path.insert(0, str(VENDOR))

VERSION = "4P.0.0"
TAG = "address_only_building_level_has_scrap_replay_v4p"

V4J1_PATH = (
    HERE / "fibonacci_nms_address_only_biome_classifier_emulator_v4j1.py"
)
REPLAY_PATH = HERE / "_v3r_replay_core.py"
EXPECTED_V4O = json.loads(
    (HERE / "EXPECTED_SCRAP_WORLD_V4O.json")
    .read_text(encoding="utf-8")
)

RUNTIME_ROOT = HERE.parent / "data" / "runtime_maps"

MASK32 = 0xFFFFFFFF


def now_iso() -> str:
    return datetime.now().astimezone().isoformat()


def stamp() -> str:
    return datetime.now().astimezone().strftime("%Y%m%d_%H%M%S")


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load module: {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def build_v4j1_args(args: argparse.Namespace) -> Namespace:
    return Namespace(
        portal=args.portal,
        packed=args.packed,
        galaxy=args.galaxy,
        dump=args.dump,
        v4i2_folder=args.v4i2_folder,
    )


def discover_v4o_folder(explicit: str | None) -> Path:
    if explicit:
        folder = Path(explicit)
        if not folder.is_dir():
            raise FileNotFoundError(folder)
        return folder

    folders = [
        path for path in RUNTIME_ROOT.glob(
            "scrap_world_building_level_capture_replay_v4o_*"
        )
        if path.is_dir()
    ]
    if not folders:
        raise FileNotFoundError(
            "No V4O runtime capture was found. Run V4O once with NMS open."
        )
    return max(folders, key=lambda path: path.stat().st_mtime)


def load_v4o_snapshot(folder: Path) -> dict[str, Any]:
    json_path = folder / "scrap_world_capture_replay_v4o.json"
    binary_path = folder / "scrap_context_table_v4o.bin"

    if not json_path.is_file():
        raise FileNotFoundError(json_path)
    if not binary_path.is_file():
        raise FileNotFoundError(binary_path)

    metadata = json.loads(json_path.read_text(encoding="utf-8-sig"))
    if metadata.get("status") != (
        "PASS_ADDRESS_DERIVED_BUILDING_LEVEL_AND_HAS_SCRAP_"
        "EXACT_CURRENT_SYSTEM"
    ):
        raise RuntimeError(
            f"V4O snapshot is not the exact pass: {metadata.get('status')}"
        )

    table = binary_path.read_bytes()
    table_meta = metadata.get("scrap_table", {})

    expected_size = int(table_meta.get("capture_size", -1))
    expected_hash = str(table_meta.get("sha256", "")).upper()
    if len(table) != expected_size:
        raise RuntimeError(
            f"V4O table size mismatch: {len(table)} != {expected_size}."
        )
    observed_hash = sha256(table)
    if observed_hash != expected_hash:
        raise RuntimeError("V4O table SHA-256 mismatch.")

    weight_offset = int(
        EXPECTED_V4O["offsets"]["has_scrap_by_building_level"]
    )
    weight_count = int(
        EXPECTED_V4O["offsets"]["has_scrap_weight_count"]
    )
    if weight_offset + weight_count * 4 > len(table):
        raise RuntimeError(
            "V4O eligibility vector is outside the captured table."
        )

    eligibility = list(
        struct.unpack_from(f"<{weight_count}f", table, weight_offset)
    )
    if not all(math.isfinite(value) for value in eligibility):
        raise RuntimeError(
            "V4O eligibility vector contains non-finite values."
        )

    metadata_eligibility = [
        float(value)
        for value in table_meta.get("eligibility", [])
    ]
    if len(metadata_eligibility) != weight_count:
        raise RuntimeError(
            "V4O metadata eligibility vector has the wrong length."
        )
    for index, (binary_value, metadata_value) in enumerate(
        zip(eligibility, metadata_eligibility)
    ):
        if struct.pack("<f", binary_value) != struct.pack(
            "<f", metadata_value
        ):
            raise RuntimeError(
                f"V4O eligibility value {index} differs between JSON "
                "and binary snapshot."
            )

    gate_probability = float(
        table_meta["global_gate_probability"]
    )
    expected_gate = float(
        EXPECTED_V4O["constants"]["global_scrap_gate_probability"]
    )
    if struct.pack("<f", gate_probability) != struct.pack(
        "<f", expected_gate
    ):
        raise RuntimeError(
            "V4O global scrap-gate probability differs from the "
            "validated build."
        )

    override_mode = int(table_meta["global_override_mode"])
    if override_mode != 1:
        raise RuntimeError(
            f"Unsupported V4O override mode: {override_mode}."
        )

    return {
        "folder": str(folder),
        "json_path": str(json_path),
        "binary_path": str(binary_path),
        "metadata": metadata,
        "table_size": len(table),
        "table_sha256": observed_hash,
        "weight_offset": weight_offset,
        "weight_count": weight_count,
        "eligibility": eligibility,
        "gate_probability": gate_probability,
        "override_mode": override_mode,
    }


def to_f32(value: float) -> float:
    return struct.unpack("<f", struct.pack("<f", float(value)))[0]


def word_to_native_f32(word: int) -> float:
    return to_f32((word & MASK32) * (1.0 / 4294967296.0))


def generate_children(root_seed: int, replay) -> list[int]:
    state = replay.state_direct_64(root_seed)
    children = []
    for _ in range(26):
        low = state.draw()
        high = state.draw()
        combined = (
            ((high & MASK32) << 32)
            | (low & MASK32)
        )
        children.append(replay.avalanche_mix_64(combined))
    return children


def calculate_building_level(
    planet_class: int,
    biome: int,
    subtype: int,
) -> tuple[int, str]:
    if planet_class == 1:
        return 3, "planet_class_1"
    if biome == 7:
        return 4, "biome_7"
    if subtype == 24:
        return 5, "subtype_24"
    if biome == 14:
        return 6, "biome_14"
    if biome == 15:
        return 7, "biome_15"
    if biome == 6:
        return 0, "biome_6"
    return 2, "default"


def replay_has_scrap(
    child_seed_1: int,
    *,
    planet_class: int,
    biome: int,
    building_level: int,
    eligibility: list[float],
    gate_probability: float,
    replay,
) -> dict[str, Any]:
    if not (0 <= building_level < len(eligibility)):
        raise RuntimeError(
            f"BuildingLevel {building_level} is outside the eligibility "
            "vector."
        )

    state = replay.state_direct_64(child_seed_1)
    draw_trace: list[dict[str, Any]] = []

    ordinary_weighted = (
        planet_class != 1 and biome not in {6, 14, 15}
    )

    if ordinary_weighted:
        first = state.draw()
        draw_trace.append({
            "label": "preloop_3458_weighted_pick",
            "word": f"0x{first:08X}",
            "unit_f32": word_to_native_f32(first),
        })

        second = state.draw()
        draw_trace.append({
            "label": "preloop_344C_weighted_pick",
            "word": f"0x{second:08X}",
            "unit_f32": word_to_native_f32(second),
        })

    third = state.draw()
    draw_trace.append({
        "label": "preloop_3460_boolean",
        "word": f"0x{third:08X}",
        "unit_f32": word_to_native_f32(third),
    })

    weight = float(eligibility[building_level])
    eligible = weight != 0.0

    if biome == 7:
        return {
            "has_scrap": False,
            "reason": "biome_7_forces_false_without_gate_draw",
            "gate_draw_consumed": False,
            "gate_word": None,
            "gate_random_f32": None,
            "gate_passed": False,
            "eligibility_weight": weight,
            "eligibility_nonzero": eligible,
            "draw_trace": draw_trace,
        }

    gate_word = state.draw()
    gate_random = word_to_native_f32(gate_word)
    gate_passed = not (gate_probability < gate_random)

    draw_trace.append({
        "label": "has_scrap_global_gate",
        "word": f"0x{gate_word:08X}",
        "unit_f32": gate_random,
    })

    has_scrap = gate_passed and eligible

    if not gate_passed:
        reason = "global_probability_gate_failed"
    elif not eligible:
        reason = "building_level_eligibility_zero"
    else:
        reason = "gate_passed_and_eligibility_nonzero"

    return {
        "has_scrap": has_scrap,
        "reason": reason,
        "gate_draw_consumed": True,
        "gate_word": f"0x{gate_word:08X}",
        "gate_random_f32": gate_random,
        "gate_passed": gate_passed,
        "eligibility_weight": weight,
        "eligibility_nonzero": eligible,
        "draw_trace": draw_trace,
    }


def validate_same_address(
    predictions: list[dict[str, Any]],
    portal: str,
    metadata: dict[str, Any],
) -> dict[str, Any]:
    expected_portal = (
        metadata.get("current_system", {})
        .get("canonical_planet_zero_portal")
    )
    same_address = portal == expected_portal

    expected_by_slot = {
        int(row["slot"]): row
        for row in metadata.get("planet_rows", [])
    }

    rows = []
    for predicted in predictions:
        slot = int(predicted["slot"])
        expected = expected_by_slot.get(slot)

        if expected is None:
            rows.append({
                "slot": slot,
                "expected_available": False,
                "record_exact": False,
            })
            continue

        child_exact = (
            str(predicted["child_1_seed_hex"]).upper()
            == str(expected["child_1_seed_hex"]).upper()
        )
        building_exact = (
            int(predicted["building_level"])
            == int(expected["actual_building_level"])
        )
        scrap_exact = (
            bool(predicted["has_scrap"])
            == bool(expected["actual_has_scrap"])
        )

        gate_random_exact = False
        predicted_gate = predicted.get("gate_random_f32")
        expected_gate = expected.get("gate_random_f32")
        if predicted_gate is None and expected_gate is None:
            gate_random_exact = True
        elif predicted_gate is not None and expected_gate is not None:
            gate_random_exact = (
                struct.pack("<f", float(predicted_gate))
                == struct.pack("<f", float(expected_gate))
            )

        row = {
            "slot": slot,
            "expected_available": True,
            "child_1_exact": child_exact,
            "building_level_exact": building_exact,
            "gate_random_exact": gate_random_exact,
            "has_scrap_exact": scrap_exact,
        }
        row["record_exact"] = all(
            row[key]
            for key in (
                "child_1_exact",
                "building_level_exact",
                "gate_random_exact",
                "has_scrap_exact",
            )
        )
        rows.append(row)

    count = len(predictions)
    exact_count = sum(
        1 for row in rows if row.get("record_exact")
    )
    child_exact_count = sum(
        1 for row in rows if row.get("child_1_exact")
    )
    building_exact_count = sum(
        1 for row in rows if row.get("building_level_exact")
    )
    gate_exact_count = sum(
        1 for row in rows if row.get("gate_random_exact")
    )
    scrap_exact_count = sum(
        1 for row in rows if row.get("has_scrap_exact")
    )

    all_exact = (
        same_address
        and count > 0
        and count == len(expected_by_slot)
        and exact_count == count
    )

    return {
        "same_address": same_address,
        "input_portal": portal,
        "expected_portal": expected_portal,
        "rows": rows,
        "record_count": count,
        "record_exact_count": exact_count,
        "child_1_exact_count": child_exact_count,
        "building_level_exact_count": building_exact_count,
        "gate_random_exact_count": gate_exact_count,
        "has_scrap_exact_count": scrap_exact_count,
        "all_exact": all_exact,
    }


def run(args: argparse.Namespace) -> dict[str, Any]:
    v4j1 = load_module("v4p_v4j1", V4J1_PATH)
    replay = load_module("v4p_replay_core", REPLAY_PATH)

    v4j1_result = v4j1.run(build_v4j1_args(args))
    if not str(v4j1_result.get("status", "")).startswith("PASS_"):
        raise RuntimeError(
            f"Internal V4J1 phase failed: {v4j1_result.get('status')}"
        )

    v4o_folder = discover_v4o_folder(args.v4o_folder)
    snapshot = load_v4o_snapshot(v4o_folder)
    metadata = snapshot["metadata"]

    predictions = []

    for planet in v4j1_result.get("planet_rows", []):
        slot = int(planet["slot"])
        root_seed = int(planet["planet_seed_hex"], 16)
        children = generate_children(root_seed, replay)
        child_1 = int(children[0])

        planet_class = int(planet["planet_class"])
        biome = int(planet["biome"])
        subtype = int(planet["biome_subtype"])

        building, building_reason = calculate_building_level(
            planet_class,
            biome,
            subtype,
        )
        scrap = replay_has_scrap(
            child_1,
            planet_class=planet_class,
            biome=biome,
            building_level=building,
            eligibility=snapshot["eligibility"],
            gate_probability=snapshot["gate_probability"],
            replay=replay,
        )

        predictions.append({
            "slot": slot,
            "planet_seed_hex": f"0x{root_seed:016X}",
            "child_1_seed_hex": f"0x{child_1:016X}",
            "biome": biome,
            "biome_subtype": subtype,
            "planet_class": planet_class,
            "building_level": building,
            "building_level_reason": building_reason,
            "eligibility_weight": scrap["eligibility_weight"],
            "eligibility_nonzero": scrap["eligibility_nonzero"],
            "gate_draw_consumed": scrap["gate_draw_consumed"],
            "gate_word": scrap["gate_word"],
            "gate_random_f32": scrap["gate_random_f32"],
            "gate_probability": snapshot["gate_probability"],
            "gate_passed": scrap["gate_passed"],
            "has_scrap": bool(scrap["has_scrap"]),
            "has_scrap_reason": scrap["reason"],
            "draw_trace": scrap["draw_trace"],
        })

    portal = v4j1_result["input"]["planet_zero_portal"]
    validation = validate_same_address(
        predictions,
        portal,
        metadata,
    )

    if validation["all_exact"]:
        status = (
            "PASS_ADDRESS_ONLY_BUILDING_LEVEL_AND_HAS_SCRAP_REPLAY_EXACT"
        )
    elif validation["same_address"]:
        status = (
            "PASS_ADDRESS_ONLY_BUILDING_LEVEL_HAS_SCRAP_WITH_MISMATCHES"
        )
    else:
        status = (
            "PASS_ADDRESS_ONLY_BUILDING_LEVEL_HAS_SCRAP_"
            "PREDICTION_UNVALIDATED_ADDRESS"
        )

    return {
        "version": VERSION,
        "tag": TAG,
        "timestamp": now_iso(),
        "status": status,
        "mode": "OFFLINE_ADDRESS_ONLY_BUILDING_LEVEL_HAS_SCRAP_REPLAY",
        "safety": {
            "nms_process_required": False,
            "nms_process_access": False,
            "process_memory_writes": False,
            "game_file_writes": False,
            "save_writes": False,
            "mod_writes": False,
        },
        "input": v4j1_result["input"],
        "v4j1_status": v4j1_result["status"],
        "v4o_snapshot_folder": snapshot["folder"],
        "v4o_status": metadata["status"],
        "scrap_table": {
            "binary_path": snapshot["binary_path"],
            "table_size": snapshot["table_size"],
            "table_sha256": snapshot["table_sha256"],
            "weight_offset": f"0x{snapshot['weight_offset']:X}",
            "weight_count": snapshot["weight_count"],
            "eligibility": snapshot["eligibility"],
            "gate_probability": snapshot["gate_probability"],
            "override_mode": snapshot["override_mode"],
        },
        "planet_count": len(predictions),
        "planet_rows": predictions,
        "validation": validation,
        "claim_boundary": {
            "portal_to_planet_seed_exact": True,
            "portal_to_biome_subtype_class_exact": True,
            "portal_to_child_seed_1_exact": True,
            "portal_to_building_level_exact_current_system": True,
            "portal_to_has_scrap_exact_current_system": True,
            "arbitrary_address_prediction_generated": True,
            "broad_multi_system_branch_validation_complete": False,
            "complete_planet_visual_predictor_claimed": False,
            "next_phase": (
                "Map and replay the deep-water precursor fields and their "
                "probability chain."
            ),
        },
    }


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return

    fields: list[str] = []
    for row in rows:
        for key, value in row.items():
            if isinstance(value, (list, dict)):
                continue
            if key not in fields:
                fields.append(key)

    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({
                key: row.get(key)
                for key in fields
            })


def write_outputs(result: dict[str, Any], output: Path) -> Path:
    output.mkdir(parents=True, exist_ok=True)

    json_path = (
        output / "address_only_building_level_has_scrap_v4p.json"
    )
    json_path.write_text(
        json.dumps(result, indent=2),
        encoding="utf-8",
    )

    write_csv(
        output / "address_only_building_level_has_scrap_v4p.csv",
        result.get("planet_rows", []),
    )
    write_csv(
        output / "building_level_has_scrap_validation_v4p.csv",
        result.get("validation", {}).get("rows", []),
    )

    validation = result.get("validation", {})
    table = result.get("scrap_table", {})

    report = f"""FIBONACCI NMS ADDRESS-ONLY BUILDING LEVEL + HAS SCRAP REPLAY V4P
Timestamp={result['timestamp']}
Version={VERSION}

RESULT
------
STATUS={result['status']}
ERROR={result.get('error', 'NONE')}
MODE=OFFLINE_ADDRESS_ONLY_BUILDING_LEVEL_HAS_SCRAP_REPLAY
NMS_PROCESS_REQUIRED=False
PROCESS_MEMORY_WRITES=False
GAME_FILE_WRITES=False
SAVE_WRITES=False
MOD_WRITES=False
COMPLETE_PLANET_VISUAL_PREDICTOR_CLAIMED=False

ADDRESS INPUT
-------------
SOURCE={result.get('input', {}).get('source', 'UNKNOWN')}
PORTAL={result.get('input', {}).get('planet_zero_portal', 'UNKNOWN')}
PACKED_INPUT={result.get('input', {}).get('packed_input', 'UNKNOWN')}
GALAXY_INDEX={result.get('input', {}).get('galaxy_index', 'UNKNOWN')}

UPSTREAM PHASES
---------------
V4J1_STATUS={result.get('v4j1_status', 'UNKNOWN')}
V4O_STATUS={result.get('v4o_status', 'UNKNOWN')}

PORTABLE SCRAP TABLE
--------------------
TABLE_BYTES={table.get('table_size', 0)}
TABLE_SHA256={table.get('table_sha256', 'UNKNOWN')}
BUILDING_LEVEL_WEIGHT_OFFSET={table.get('weight_offset', 'UNKNOWN')}
BUILDING_LEVEL_WEIGHTS={table.get('eligibility', [])}
GLOBAL_GATE_PROBABILITY={table.get('gate_probability', 'UNKNOWN')}
GLOBAL_OVERRIDE_MODE={table.get('override_mode', 'UNKNOWN')}

OFFLINE VALIDATION
------------------
V4O_SAME_ADDRESS={validation.get('same_address', False)}
PLANET_RECORDS_EXACT={validation.get('record_exact_count', 0)}/{validation.get('record_count', 0)}
CHILD1_EXACT={validation.get('child_1_exact_count', 0)}/{validation.get('record_count', 0)}
BUILDING_LEVEL_EXACT={validation.get('building_level_exact_count', 0)}/{validation.get('record_count', 0)}
GATE_RANDOM_EXACT={validation.get('gate_random_exact_count', 0)}/{validation.get('record_count', 0)}
HAS_SCRAP_EXACT={validation.get('has_scrap_exact_count', 0)}/{validation.get('record_count', 0)}

ADDRESS-ONLY BUILDING LEVEL + HAS SCRAP
---------------------------------------
"""
    for row in result.get("planet_rows", []):
        report += (
            f"SLOT={row['slot']} "
            f"SEED={row['planet_seed_hex']} "
            f"CHILD1={row['child_1_seed_hex']} "
            f"BIOME={row['biome']} "
            f"SUBTYPE={row['biome_subtype']} "
            f"CLASS={row['planet_class']} "
            f"BUILDING_LEVEL={row['building_level']} "
            f"BUILDING_REASON={row['building_level_reason']} "
            f"WEIGHT={row['eligibility_weight']} "
            f"GATE_RANDOM={row['gate_random_f32']} "
            f"GATE_PASSED={row['gate_passed']} "
            f"HAS_SCRAP={row['has_scrap']} "
            f"SCRAP_REASON={row['has_scrap_reason']}\n"
        )

    report += f"""
INTERPRETATION
--------------
V4P is completely offline.

It obtains each planet's root seed, Biome, BiomeSubType and class from the
address-only V4J1 pipeline, derives child seed #1, reproduces the exact
pre-loop draw schedule, calculates BuildingLevel, then applies the captured
build-global eligibility vector and the 0.2 scrap gate.

A byte/float-exact same-address validation closes the current tested system.
The program can also generate predictions for arbitrary addresses, but broad
multi-system validation of every rare BuildingLevel branch remains pending.

NEXT PHASE
----------
Map and replay the deep-water precursor fields and their probability chain.

OUTPUT FILES
------------
{output / 'ATLAS_APF_RESULT_ADDRESS_ONLY_SCRAP_V4P.txt'}
{json_path}
{output / 'address_only_building_level_has_scrap_v4p.csv'}
{output / 'building_level_has_scrap_validation_v4p.csv'}
"""
    report_path = (
        output / "ATLAS_APF_RESULT_ADDRESS_ONLY_SCRAP_V4P.txt"
    )
    report_path.write_text(report, encoding="utf-8")
    return report_path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--portal")
    parser.add_argument("--packed")
    parser.add_argument("--galaxy", type=int, default=0)
    parser.add_argument("--dump")
    parser.add_argument("--v4i2-folder")
    parser.add_argument("--v4o-folder")
    args = parser.parse_args()

    output = RUNTIME_ROOT / f"{TAG}_{stamp()}"
    try:
        result = run(args)
    except Exception as exc:
        result = {
            "version": VERSION,
            "tag": TAG,
            "timestamp": now_iso(),
            "status": f"ERROR_{type(exc).__name__}",
            "error": str(exc),
            "input": {},
            "scrap_table": {},
            "planet_rows": [],
            "planet_count": 0,
            "validation": {
                "rows": [],
                "record_count": 0,
                "record_exact_count": 0,
                "child_1_exact_count": 0,
                "building_level_exact_count": 0,
                "gate_random_exact_count": 0,
                "has_scrap_exact_count": 0,
            },
        }

    report = write_outputs(result, output)
    print(f"STATUS={result['status']}")
    print(f"OUTPUT_DIR={output}")
    print(f"REPORT={report}")
    if result.get("error"):
        print(f"ERROR={result['error']}")
    return 0 if str(result["status"]).startswith("PASS_") else 1


if __name__ == "__main__":
    raise SystemExit(main())
