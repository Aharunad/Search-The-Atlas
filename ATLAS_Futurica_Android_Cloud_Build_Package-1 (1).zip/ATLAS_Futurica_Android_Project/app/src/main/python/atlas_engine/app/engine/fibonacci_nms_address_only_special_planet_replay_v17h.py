#!/usr/bin/env python3
"""Exact V17H2 special-planet rules and release regression."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Callable

VERSION = "17H2.0.0"
INFESTED_BIOME_SUBTYPE = 24
DIRECT_DISSONANT_STAR_TYPE = 4
DIRECT_DISSONANT_PLANET_INDEX = 1
DIRECT_DISSONANT_SENTINEL_PATTERN = (0, 3, 3, 3)
DIRECT_DISSONANT_RULE = "StarType == 4 AND PlanetIndex == 1"


def load_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8-sig") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise TypeError(f"Expected JSON object: {path}")
    return value


def predict_special_planet_state(
    *,
    star_type: int,
    planet_index: int,
    biome_subtype: int,
) -> dict[str, Any]:
    star_type = int(star_type)
    planet_index = int(planet_index)
    biome_subtype = int(biome_subtype)

    infested_planet = biome_subtype == INFESTED_BIOME_SUBTYPE
    dissonant_planet = bool(
        star_type == DIRECT_DISSONANT_STAR_TYPE
        and planet_index == DIRECT_DISSONANT_PLANET_INDEX
    )
    return {
        "planet_index": planet_index,
        "infested_planet": infested_planet,
        "infested_rule": "BiomeSubType == 24",
        "infested_prediction_status": (
            "validated_v17a_address_only_current_build"
        ),
        "dissonant_planet": dissonant_planet,
        "dissonant_rule": DIRECT_DISSONANT_RULE,
        "dissonant_sentinel_pattern": (
            list(DIRECT_DISSONANT_SENTINEL_PATTERN)
            if dissonant_planet
            else []
        ),
        "dissonant_prediction_status": (
            "validated_v17f_native_direct_rule_current_build"
        ),
    }


def verify_static(regression_path: Path) -> dict[str, Any]:
    regression = load_json(regression_path)
    rows = list(regression.get("rows", []))
    checks = {
        "regression_rows_71": len(rows) == 71,
        "rule_exact": regression.get("rule") == DIRECT_DISSONANT_RULE,
        "infested_rule_exact": (
            regression.get("infested_rule") == "BiomeSubType == 24"
        ),
        "direct_rows_5": sum(
            bool(row.get("expected_dissonant_planet")) for row in rows
        ) == 5,
        "infested_rows_1": sum(
            bool(row.get("expected_infested_planet")) for row in rows
        ) == 1,
    }
    return {
        "version": VERSION,
        "checks": checks,
        "exact": all(checks.values()),
    }


def run_regression(
    core_module: Any,
    regression_path: Path,
    progress: Callable[[int, int, str], None] | None = None,
) -> dict[str, Any]:
    regression = load_json(regression_path)
    rows = list(regression.get("rows", []))
    by_system: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        by_system.setdefault(
            str(row["system_portal"]).upper(),
            [],
        ).append(row)

    metric_names = (
        "planet_index",
        "infested_predicate",
        "direct_dissonance",
        "direct_dissonance_pattern",
        "existing_sentinel_level_unchanged",
        "dissonant_filter",
        "infested_filter",
    )
    metrics = {
        name: {"correct": 0, "total": 0}
        for name in metric_names
    }
    failures: list[dict[str, Any]] = []

    systems = sorted(by_system)
    for index, system_portal in enumerate(systems, start=1):
        if progress:
            progress(index, len(systems), system_portal)
        prediction = core_module.predict_system(system_portal, 0)
        actual_by_slot = {
            int(row["slot"]): row
            for row in prediction["planet_rows"]
        }

        for expected in by_system[system_portal]:
            slot = int(expected["slot"])
            actual = actual_by_slot.get(slot)
            if actual is None:
                failures.append({
                    "system_portal": system_portal,
                    "slot": slot,
                    "field": "missing_slot",
                })
                for name in metric_names[:5]:
                    metrics[name]["total"] += 1
                continue

            checks = {
                "planet_index": (
                    int(actual.get("planet_index", -1)) == slot
                    and int(expected["planet_portal"][0], 16) == slot
                ),
                "infested_predicate": (
                    bool(actual.get("infested_planet"))
                    == bool(expected["expected_infested_planet"])
                ),
                "direct_dissonance": (
                    bool(actual.get("dissonant_planet"))
                    == bool(expected["expected_dissonant_planet"])
                ),
                "direct_dissonance_pattern": (
                    list(actual.get("dissonant_sentinel_pattern", []))
                    == list(
                        expected[
                            "expected_dissonant_sentinel_pattern"
                        ]
                    )
                ),
                "existing_sentinel_level_unchanged": (
                    int(actual.get("sentinel_level", -1))
                    == int(expected["expected_existing_sentinel_level"])
                ),
            }
            for name, exact in checks.items():
                metrics[name]["total"] += 1
                metrics[name]["correct"] += int(exact)
                if not exact:
                    failures.append({
                        "system_portal": system_portal,
                        "slot": slot,
                        "field": name,
                        "actual": actual.get(name),
                        "expected": expected,
                    })

            expected_dissonant = bool(
                expected["expected_dissonant_planet"]
            )
            # This legacy V17H2 regression proves the preserved direct-Corrupt
            # branch. The public Dissonance filter now intentionally uses the
            # portal-safe native Sentinel difficulty enum instead.
            actual_direct_dissonant = bool(
                actual.get(
                    "legacy_direct_corrupt_branch",
                    actual.get("dissonant_planet"),
                )
            )
            for requested in (True, False):
                exact = (
                    (actual_direct_dissonant == requested)
                    == (expected_dissonant == requested)
                )
                metrics["dissonant_filter"]["total"] += 1
                metrics["dissonant_filter"]["correct"] += int(exact)
                if not exact:
                    failures.append({
                        "system_portal": system_portal,
                        "slot": slot,
                        "field": "dissonant_filter",
                        "requested": requested,
                    })

            expected_infested = bool(
                expected["expected_infested_planet"]
            )
            for requested in (True, False):
                exact = (
                    core_module.planet_matches(
                        actual,
                        prediction["system"],
                        infested=requested,
                    )
                    == (expected_infested == requested)
                )
                metrics["infested_filter"]["total"] += 1
                metrics["infested_filter"]["correct"] += int(exact)
                if not exact:
                    failures.append({
                        "system_portal": system_portal,
                        "slot": slot,
                        "field": "infested_filter",
                        "requested": requested,
                    })

    for metric in metrics.values():
        metric["exact"] = bool(
            metric["total"] > 0
            and metric["correct"] == metric["total"]
        )

    expected_totals = {
        "planet_index": 71,
        "infested_predicate": 71,
        "direct_dissonance": 71,
        "direct_dissonance_pattern": 71,
        "existing_sentinel_level_unchanged": 71,
        "dissonant_filter": 142,
        "infested_filter": 142,
    }
    exact = all(
        metrics[name]["exact"]
        and metrics[name]["total"] == expected_total
        for name, expected_total in expected_totals.items()
    ) and not failures

    return {
        "version": VERSION,
        "status": (
            "PASS_SPECIAL_PLANET_RELEASE_REGRESSION_V17H2_EXACT"
            if exact
            else "ERROR_SPECIAL_PLANET_RELEASE_REGRESSION_V17H2"
        ),
        "exact": exact,
        "systems": len(systems),
        "rows": len(rows),
        "metrics": metrics,
        "failure_count": len(failures),
        "failures": failures,
    }
