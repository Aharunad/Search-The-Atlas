#!/usr/bin/env python3
"""Deterministic descriptive colour names and GUI swatch metadata.

V20F4 exposes this for generated Grass and GrassAlt palettes. The
functions are deliberately generic so later releases can reuse the exact same
presentation layer for atmosphere, sky, sunset, night and cloud colours.
"""
from __future__ import annotations

import colorsys
import re
from typing import Any

VERSION = "20F4.0.0"
_HEX_RE = re.compile(r"^#?([0-9A-Fa-f]{6})$")


def normalize_hex(value: str) -> str:
    match = _HEX_RE.fullmatch(str(value).strip())
    if not match:
        raise ValueError(f"Expected a six-digit RGB hexadecimal colour; got {value!r}.")
    return "#" + match.group(1).upper()


def rgb_from_hex(value: str) -> tuple[int, int, int]:
    text = normalize_hex(value)
    return tuple(int(text[index:index + 2], 16) for index in (1, 3, 5))


def _colour_metrics(value: str) -> dict[str, float | int | str]:
    text = normalize_hex(value)
    r, g, b = rgb_from_hex(text)
    rf, gf, bf = r / 255.0, g / 255.0, b / 255.0
    hue, saturation, brightness = colorsys.rgb_to_hsv(rf, gf, bf)
    _hue_hls, lightness, saturation_hls = colorsys.rgb_to_hls(rf, gf, bf)
    # Relative luminance is used only to choose readable black/white swatch text.
    def linear(channel: float) -> float:
        return channel / 12.92 if channel <= 0.04045 else ((channel + 0.055) / 1.055) ** 2.4
    luminance = 0.2126 * linear(rf) + 0.7152 * linear(gf) + 0.0722 * linear(bf)
    return {
        "hex": text,
        "red": r,
        "green": g,
        "blue": b,
        "hue_degrees": (hue * 360.0) % 360.0,
        "saturation": saturation,
        "brightness": brightness,
        "lightness": lightness,
        "hls_saturation": saturation_hls,
        "relative_luminance": luminance,
    }


def describe_colour(value: str) -> str:
    """Return a deterministic, deliberately descriptive English colour name.

    The hexadecimal value remains the authoritative colour. The name is a
    readable description, not an attempt to replace the exact RGB value.
    """
    m = _colour_metrics(value)

    # Live/community-validated NMS rendering closure:
    # the generated grass input #AD9284 appears as rare white grass in-game.
    # The exact RGB and raw swatch remain visible, while the user-facing name is
    # the observed rendered colour requested by the live tester.
    if str(m["hex"]) == "#AD9284":
        return "White"

    h = float(m["hue_degrees"])
    s = float(m["saturation"])
    v = float(m["brightness"])
    l = float(m["lightness"])

    # Neutral and near-neutral colours first.
    if s < 0.055:
        if v < 0.12:
            return "Near black"
        if v < 0.25:
            return "Charcoal grey"
        if v < 0.45:
            return "Dark grey"
        if v < 0.68:
            return "Mid grey"
        if v < 0.86:
            return "Light grey"
        if v < 0.97:
            return "Pale grey"
        return "White"

    if s < 0.16:
        if v < 0.34:
            return "Dark neutral grey-brown"
        if v < 0.60:
            return "Muted grey-brown"
        if v < 0.82:
            return "Warm pale grey" if h < 75 or h >= 330 else "Cool pale grey"
        return "Soft off-white"

    # Warm earth tones need special treatment because calling every low-value
    # orange simply "orange" was the ambiguity that prompted V20F3.
    if 12 <= h < 23:
        if v < 0.42:
            return "Dark red-brown"
        if v < 0.62:
            return "Rust red / brown"
        if s < 0.48:
            return "Muted terracotta"
        return "Terracotta red"
    if 23 <= h < 34:
        if v < 0.46:
            return "Dark brown"
        if v < 0.56:
            return "Dark rust brown"
        if v < 0.70:
            return "Burnt orange / rust brown"
        if s < 0.55:
            return "Muted burnt orange"
        return "Burnt orange"
    if 34 <= h < 47:
        if s < 0.36 and v < 0.60:
            return "Muted olive brown"
        if v < 0.43:
            return "Dark ochre brown"
        if v < 0.68:
            return "Ochre brown"
        if s < 0.52:
            return "Muted amber brown"
        return "Amber orange"
    if 47 <= h < 72:
        if s < 0.40 and v < 0.60:
            return "Muted olive brown"
        if v < 0.43:
            return "Dark olive"
        if h >= 65 and s >= 0.55:
            return "Olive green"
        if v < 0.70:
            return "Olive yellow"
        if s < 0.55:
            return "Soft golden yellow"
        return "Golden yellow"

    # Remaining chromatic hue families.
    if h < 12 or h >= 350:
        base = "Red"
    elif h < 72:
        base = "Yellow"
    elif h < 92:
        base = "Yellow-green"
    elif h < 145:
        base = "Green"
    elif h < 170:
        base = "Blue-green"
    elif h < 195:
        base = "Cyan"
    elif h < 220:
        base = "Sky blue"
    elif h < 252:
        base = "Blue"
    elif h < 276:
        base = "Indigo"
    elif h < 300:
        base = "Violet"
    elif h < 326:
        base = "Purple"
    elif h < 350:
        base = "Magenta pink"
    else:
        base = "Red"

    # Focused refinements for commonly observed generated colours.
    if h >= 350 or h < 8:
        if s < 0.48 and v > 0.86:
            return "Soft coral pink"
        if l > 0.73:
            return "Pale rose pink"
        if v < 0.42:
            return "Dark burgundy red"
    if 8 <= h < 18 and s < 0.58 and v > 0.78:
        return "Soft salmon pink"
    if 72 <= h < 100:
        if v < 0.46:
            return "Dark olive green"
        if s < 0.42:
            return "Muted yellow-green"
        return "Olive green"
    if 100 <= h < 145:
        if v < 0.42:
            return "Dark forest green"
        if s < 0.38:
            return "Muted sage green"
        if v > 0.84 and l > 0.66:
            return "Light spring green"
    if 145 <= h < 195:
        if v < 0.42:
            return "Dark teal"
        if s < 0.40:
            return "Muted teal"
        if v > 0.82 and l > 0.63:
            return "Light aqua cyan"
        return "Teal cyan"
    if 195 <= h < 220:
        if v > 0.88 and l > 0.66:
            return "Light sky blue"
        if s < 0.42:
            return "Muted sky blue"
    if 220 <= h < 252:
        if v < 0.38:
            return "Deep navy blue"
        if s < 0.40:
            return "Muted slate blue"
        if v > 0.88 and l > 0.65:
            return "Light blue"
    if 252 <= h < 300:
        if v < 0.40:
            return "Deep indigo violet"
        if s < 0.38:
            return "Muted lavender grey"
        if v > 0.86 and l > 0.68:
            return "Light lavender violet"
    if 300 <= h < 350:
        if v < 0.40:
            return "Deep plum purple"
        if s < 0.38 and v > 0.82:
            return "Soft mauve pink"
        if v > 0.88 and l > 0.68:
            return "Light pink-purple"

    if v < 0.35:
        prefix = "Very dark"
    elif v < 0.52:
        prefix = "Dark"
    elif s < 0.30:
        prefix = "Muted"
    elif v > 0.90 and l > 0.72:
        prefix = "Pale"
    elif v > 0.88 and s > 0.62:
        prefix = "Bright"
    elif l > 0.66:
        prefix = "Light"
    else:
        prefix = ""
    return f"{prefix} {base}".strip()


def swatch_foreground(value: str) -> str:
    """Return black or white for readable text/border contrast."""
    luminance = float(_colour_metrics(value)["relative_luminance"])
    return "#000000" if luminance > 0.42 else "#FFFFFF"


def display_payload(value: str) -> dict[str, Any]:
    metrics = _colour_metrics(value)
    text = str(metrics["hex"])
    name = describe_colour(text)
    return {
        **metrics,
        "name": name,
        "display": f"{name} {text}",
        "swatch_background": text,
        "swatch_foreground": swatch_foreground(text),
    }


def run_self_test() -> dict[str, Any]:
    expected = {
        "#A15505": "Burnt orange / rust brown",
        "#803E0F": "Dark rust brown",
        "#FBA0AB": "Soft coral pink",
        "#93A51D": "Olive green",
        "#696351": "Muted olive brown",
        "#575828": "Dark olive",
        "#9C6D21": "Ochre brown",
        "#6C4422": "Dark brown",
        "#93CFFE": "Light sky blue",
        "#AD9284": "White",
        "#FFFFFF": "White",
        "#111111": "Near black",
    }
    observed = {value: describe_colour(value) for value in expected}
    checks = {
        "normalization": normalize_hex("a15505") == "#A15505",
        "known_names": observed == expected,
        "display_contains_hex": display_payload("#A15505")["display"].endswith("#A15505"),
        "dark_swatch_text": swatch_foreground("#111111") == "#FFFFFF",
        "light_swatch_text": swatch_foreground("#FFFFFF") == "#000000",
    }
    return {
        "version": VERSION,
        "exact": all(checks.values()),
        "checks": checks,
        "expected": expected,
        "observed": observed,
    }


if __name__ == "__main__":
    import json
    result = run_self_test()
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result["exact"] else 1)
