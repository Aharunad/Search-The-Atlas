"""App-owned legacy system occupancy reconstruction for APF V20G1.

This module reproduces the current-build GeneratedLegacySystemCount calculation
without loading NMS.exe, a process image, a memory dump, or an emulator.

The generated count is:
    122 deterministic prefix systems
    + accepted points from a 19 x 19 x 19 simplex-noise grid.

The regional density threshold is selected from the same deterministic MWC
stream used by the generator.  Only the prefix-A *count* is reconstructed; no
NMS records or executable data are included.
"""
from __future__ import annotations

import math
import re
import struct
from dataclasses import dataclass
from typing import Any, Iterable

from fibonacci_nms_standalone_simplex_v20g1 import f32, normalized_fractal_noise3

VERSION = "20G1.0.0"
MWC_MULTIPLIER = 0x5A76F899
MASK32 = 0xFFFFFFFF
MASK64 = 0xFFFFFFFFFFFFFFFF
PREFIX_TOTAL = 122
GRID_AXIS = 19
GRID_POINTS = GRID_AXIS ** 3
BASE_THRESHOLD = f32(0.68)
LOW_DENSITY_MULTIPLIER = f32(1.2)
LOW_DENSITY_THRESHOLD = f32(BASE_THRESHOLD * LOW_DENSITY_MULTIPLIER)
DENSITY_SELECTOR_LIMIT = 15


def _u32(value: int) -> int:
    return int(value) & MASK32


def _u64(value: int) -> int:
    return int(value) & MASK64


def _s32(value: int) -> int:
    value = _u32(value)
    return value - 0x100000000 if value & 0x80000000 else value


def _ror32(value: int, bits: int) -> int:
    value = _u32(value)
    bits &= 31
    return _u32((value >> bits) | (value << (32 - bits)))


def _sign_extend(value: int, bits: int) -> int:
    mask = (1 << bits) - 1
    value &= mask
    sign = 1 << (bits - 1)
    return value - (1 << bits) if value & sign else value


def normalize_region_suffix(value: str) -> str:
    text = re.sub(r"[^0-9A-Fa-f]", "", str(value)).upper()
    if len(text) != 8:
        raise ValueError("Region suffix must be Y(2)+Z(3)+X(3), exactly eight hexadecimal characters.")
    int(text, 16)
    return text


def region_suffix_from_portal(value: str) -> str:
    text = re.sub(r"[^0-9A-Fa-f]", "", str(value)).upper()
    if len(text) != 12:
        raise ValueError("Portal address must contain exactly 12 hexadecimal characters.")
    int(text, 16)
    return text[4:]


def decode_region_suffix(value: str) -> dict[str, int | str]:
    text = normalize_region_suffix(value)
    y_raw = int(text[0:2], 16)
    z_raw = int(text[2:5], 16)
    x_raw = int(text[5:8], 16)
    return {
        "region_suffix": text,
        "x": _sign_extend(x_raw, 12),
        "y": _sign_extend(y_raw, 8),
        "z": _sign_extend(z_raw, 12),
        "x_raw": x_raw,
        "y_raw": y_raw,
        "z_raw": z_raw,
    }


def pack_voxel_key(region_suffix: str, galaxy_index: int) -> int:
    text = normalize_region_suffix(region_suffix)
    galaxy = int(galaxy_index)
    if not 0 <= galaxy <= 255:
        raise ValueError("Galaxy index must be between 0 and 255.")
    return _u64((galaxy << 32) | int(text, 16))


@dataclass
class MWCState:
    value: int
    carry: int

    def next_u32(self) -> int:
        combined = _u64(_u32(self.value) * MWC_MULTIPLIER + _u32(self.carry))
        self.value = _u32(combined)
        self.carry = _u32(combined >> 32)
        return self.value

    def next_f32(self) -> float:
        return f32(self.next_u32() / 4294967296.0)


def initial_region_mwc(region_suffix: str, galaxy_index: int) -> MWCState:
    key = pack_voxel_key(region_suffix, galaxy_index)
    low = _u32(key)
    value = low if low else 1
    carry = _u32(_ror32(low, 16) ^ _u32(key >> 32) ^ low)
    return MWCState(value, carry)


def _face_hash(boundary_coordinate: int, other_a: int, other_b: int) -> int:
    """Exact 32-bit hash used to seed each shared cube-face point."""
    boundary_coordinate = int(boundary_coordinate)
    eax = _u32(boundary_coordinate - 0x80000000)
    rcx = _s32(eax) & MASK64
    r8 = rcx
    # btr r8d,31; preserve the upper qword exactly as the native instruction does.
    r8 = (r8 & ~MASK32) | (_u32(r8) & ~0x80000000)
    if boundary_coordinate >= 0:
        r8 = rcx

    ecx = _u32((r8 & 0xFFFF) + _u32(int(other_a) ^ int(other_b)))
    edx = _u32(((_u32(r8) >> 5) & 0x07FFF800) ^ _u32(ecx << 16) ^ ecx)
    edx = _u32(edx + ((r8 >> 32) & 0xFFFF) + (edx >> 11))
    shifted_high = _u32(r8 >> 32)
    r8d = _u32(((shifted_high >> 5) & 0x07FFF800) ^ _u32(edx << 16) ^ edx)
    ecx = _u32(r8d + (r8d >> 11))
    edx = _u32((ecx << 3) ^ ecx)
    ecx = _u32(edx + (edx >> 5))
    edx = _u32((ecx << 4) ^ ecx)
    ecx = _u32(edx + (edx >> 17))
    edx = _u32((ecx << 25) ^ ecx)
    return _u32(edx + (edx >> 6))


def _seeded_face_random_pair(seed: int) -> tuple[float, float]:
    seed = _u32(seed)
    carry_mix = _u32(_ror32(seed, 16) ^ seed)
    value = seed if seed else 1
    state = MWCState(value, carry_mix)
    return state.next_f32(), state.next_f32()


def _helper_seed_state(x: int, y: int, z: int, galaxy_index: int) -> MWCState:
    # Native helper packs coordinates in memory order X, Z, Y.
    packed = _u64(
        (
            (((z & 0xFFF) | ((y & 0xFFFF) << 12)) & 0xFFFFF)
            | ((int(galaxy_index) & 0xFF) << 20)
        ) << 12
        | (x & 0xFFF)
    )
    mixed = _u64(packed ^ (packed >> 33))
    mixed = _u64(mixed * 0x64DD81482CBD31D7)
    mixed = _u64(mixed ^ (mixed >> 33))
    mixed = _u64(mixed * 0xE36AA5C613612997)
    mixed = _u64(mixed ^ (mixed >> 33))
    low = _u32(mixed)
    value = low if low else 1
    carry = _u32(_ror32(low, 16) ^ _u32(mixed >> 32) ^ low)
    return MWCState(value, carry)


def _face_points_unscaled(x: int, y: int, z: int) -> list[tuple[float, float, float, float]]:
    """Six shared boundary points in native face order: -Z,+Z,-Y,+Y,-X,+X."""
    specifications = (
        (z - 1, x, y, "z-"),
        (z, x, y, "z+"),
        (y - 1, z, x, "y-"),
        (y, z, x, "y+"),
        (x - 1, z, y, "x-"),
        (x, z, y, "x+"),
    )
    points: list[tuple[float, float, float, float]] = []
    for boundary, other_a, other_b, face in specifications:
        first, second = _seeded_face_random_pair(_face_hash(boundary, other_a, other_b))
        if face == "z-":
            point = (first, second, f32(-1.0), f32(1.0))
        elif face == "z+":
            point = (first, second, f32(1.0), f32(1.0))
        elif face == "y-":
            point = (first, f32(-1.0), second, f32(1.0))
        elif face == "y+":
            point = (first, f32(1.0), second, f32(1.0))
        elif face == "x-":
            point = (f32(-1.0), first, second, f32(1.0))
        else:
            point = (f32(1.0), first, second, f32(1.0))
        points.append(tuple(f32(component) for component in point))
    return points


def _centre_point_unscaled(x: int, y: int, z: int, galaxy_index: int) -> tuple[float, float, float, float]:
    state = _helper_seed_state(x, y, z, galaxy_index)
    return (
        f32(state.next_f32() - f32(0.5)),
        f32(state.next_f32() - f32(0.5)),
        f32(state.next_f32() - f32(0.5)),
        f32(1.0),
    )


def _distance3_f32(a: tuple[float, ...], b: tuple[float, ...]) -> float:
    dx = f32(b[0] - a[0])
    dy = f32(b[1] - a[1])
    dz = f32(b[2] - a[2])
    sx = f32(dx * dx)
    sy = f32(dy * dy)
    sz = f32(dz * dz)
    return f32(math.sqrt(f32(f32(sx + sy) + sz)))


def prefix_segments(region_suffix: str, galaxy_index: int) -> list[tuple[tuple[float, float, float, float], tuple[float, float, float, float]]]:
    decoded = decode_region_suffix(region_suffix)
    x, y, z = int(decoded["x"]), int(decoded["y"]), int(decoded["z"])
    faces = _face_points_unscaled(x, y, z)
    centre = _centre_point_unscaled(x, y, z, galaxy_index)
    nodes = faces + [centre]

    edges: set[tuple[int, int]] = {(face_index, 6) for face_index in range(6)}
    for first in range(6):
        for second in range(first + 1, 6):
            if _distance3_f32(faces[first], faces[second]) <= f32(1.0):
                edges.add((first, second))

    scale = f32(50.0)
    segments = []
    # Native adjacency order is centre-edge first for each face node, followed
    # by forward face-to-face neighbours in ascending node order.
    ordered_edges: list[tuple[int, int]] = []
    for first in range(6):
        ordered_edges.append((first, 6))
        ordered_edges.extend(
            (first, second)
            for second in range(first + 1, 6)
            if (first, second) in edges
        )
    for first, second in ordered_edges:
        start = tuple(f32(component * scale) for component in nodes[first])
        end = tuple(f32(component * scale) for component in nodes[second])
        segments.append((start, end))
    return segments


def prefix_path_a_count(region_suffix: str, galaxy_index: int) -> int:
    state = initial_region_mwc(region_suffix, galaxy_index)
    # The generator advances once before entering the prefix-A segment loop.
    state.next_u32()
    count = 0
    for start, end in prefix_segments(region_suffix, galaxy_index):
        length = _distance3_f32(start, end)
        if length <= f32(0.0):
            continue
        low_step = f32(f32(5.0) / length)
        high_step = f32(f32(10.0) / length)
        progress = low_step
        while progress <= f32(1.0):
            count += 1
            spacing_random = f32(0.0)
            # Five record-property draws, then the sixth draw controls spacing.
            for _ in range(6):
                spacing_random = state.next_f32()
            interval = f32(low_step + f32(spacing_random * f32(high_step - low_step)))
            progress = f32(progress + interval)
    return count


def density_metric(region_suffix: str, galaxy_index: int, prefix_a: int | None = None) -> int:
    if prefix_a is None:
        prefix_a = prefix_path_a_count(region_suffix, galaxy_index)
    state = initial_region_mwc(region_suffix, galaxy_index)
    for _ in range(855 - int(prefix_a)):
        state.next_u32()
    value = state.next_u32()
    return int((_u64(value * 100)) >> 32)


def density_threshold(region_suffix: str, galaxy_index: int, prefix_a: int | None = None) -> tuple[float, int]:
    metric = density_metric(region_suffix, galaxy_index, prefix_a)
    threshold = LOW_DENSITY_THRESHOLD if metric < DENSITY_SELECTOR_LIMIT else BASE_THRESHOLD
    return threshold, metric


def accepted_grid_count(region_suffix: str, galaxy_index: int, threshold: float) -> int:
    decoded = decode_region_suffix(region_suffix)
    x, y, z = int(decoded["x"]), int(decoded["y"]), int(decoded["z"])
    # Preserve native float32 operation order: coordinate -> *0.1 -> *0.15.
    # Collapsing this to *0.015 moves rare points across the threshold.
    region_tenth = f32(0.1)
    noise_scale = f32(0.15)
    grid_step = f32(f32(15.0) / f32(19.0))
    base_x = f32(f32(f32(x) * region_tenth) * noise_scale)
    base_y = f32(f32(f32(y) * region_tenth) * noise_scale)
    base_z = f32(f32(f32(z) * region_tenth) * noise_scale)
    threshold = f32(threshold)
    accepted = 0
    for x_index in range(GRID_AXIS):
        noise_x = f32(base_x + f32(f32(x_index - 9) * grid_step))
        for y_index in range(GRID_AXIS):
            noise_y = f32(base_y + f32(f32(y_index - 9) * grid_step))
            for z_index in range(GRID_AXIS):
                noise_z = f32(base_z + f32(f32(z_index - 9) * grid_step))
                value = normalized_fractal_noise3(
                    noise_x,
                    noise_y,
                    noise_z,
                    4,
                    f32(1.25),
                    f32(0.9),
                )
                if value > threshold:
                    accepted += 1
    return accepted


def generated_legacy_system_count(region_suffix: str, galaxy_index: int = 0, *, include_diagnostics: bool = False) -> int | dict[str, Any]:
    suffix = normalize_region_suffix(region_suffix)
    # The all-zero spatial key is handled separately by the game's origin route.
    # It does not expose the ordinary regional legacy vector.
    if int(suffix, 16) == 0 and int(galaxy_index) == 0:
        count = 0
        diagnostics = {
            "region_suffix": suffix,
            "galaxy_index": int(galaxy_index),
            "origin_special_case": True,
            "prefix_path_a_count": 0,
            "prefix_path_b_count": 0,
            "density_metric": None,
            "threshold": None,
            "accepted_grid_count": 0,
            "generated_legacy_system_count": count,
        }
        return diagnostics if include_diagnostics else count

    prefix_a = prefix_path_a_count(suffix, galaxy_index)
    threshold, metric = density_threshold(suffix, galaxy_index, prefix_a)
    grid_count = accepted_grid_count(suffix, galaxy_index, threshold)
    count = PREFIX_TOTAL + grid_count
    diagnostics = {
        "region_suffix": suffix,
        "galaxy_index": int(galaxy_index),
        "origin_special_case": False,
        "prefix_path_a_count": prefix_a,
        "prefix_path_b_count": PREFIX_TOTAL - prefix_a,
        "density_metric": metric,
        "threshold": threshold,
        "accepted_grid_count": grid_count,
        "generated_legacy_system_count": count,
        "last_valid_legacy_ssi": count - 1,
        "first_invalid_legacy_ssi": count,
    }
    return diagnostics if include_diagnostics else count


__all__ = [
    "VERSION",
    "PREFIX_TOTAL",
    "GRID_POINTS",
    "normalize_region_suffix",
    "region_suffix_from_portal",
    "decode_region_suffix",
    "pack_voxel_key",
    "prefix_segments",
    "prefix_path_a_count",
    "density_metric",
    "density_threshold",
    "accepted_grid_count",
    "generated_legacy_system_count",
]
