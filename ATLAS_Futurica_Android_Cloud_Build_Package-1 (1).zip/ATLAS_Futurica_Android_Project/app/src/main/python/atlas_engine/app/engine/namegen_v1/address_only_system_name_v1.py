#!/usr/bin/env python3
"""Portable exact English default procedural NMS system-name generator."""
from __future__ import annotations

import argparse
import json
import re
from typing import Any

from address_only_namegen_markov_v1 import (
    MWC,
    generate_markov,
    high_multiply_u32,
)

DATASET_CHOICES = (2, 3, 4, 5, 7)
ROMAN = (
    '', 'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX',
    'X', 'XI', 'XII', 'XIII', 'XIV', 'XV', 'XVI', 'XVII',
    'XVIII', 'XIX',
)


def _capitalise(word: str) -> str:
    return word[:1].upper() + word[1:]


def normalise_portal_address(portal: str) -> str:
    value = re.sub(r'[^0-9A-Fa-f]', '', portal).upper()
    if len(value) != 12:
        raise ValueError('Portal address must contain exactly 12 hexadecimal digits.')
    return value


def portal_to_system_seed(portal: str, galaxy_index: int = 0) -> dict[str, Any]:
    """Convert glyph/portal PSSSYYZZZXXX to the packed universal seed.

    The planet nibble P is deliberately omitted for system naming.
    Galaxy index occupies bits 32..39; Euclid is zero.
    """
    address = normalise_portal_address(portal)
    if not 0 <= galaxy_index <= 0xFF:
        raise ValueError('Galaxy index must be between 0 and 255.')

    planet = int(address[0], 16)
    system_index = int(address[1:4], 16)
    y = int(address[4:6], 16)
    z = int(address[6:9], 16)
    x = int(address[9:12], 16)

    seed = (
        x
        | (z << 12)
        | (y << 24)
        | (galaxy_index << 32)
        | (system_index << 40)
    )
    return {
        'portal_address': address,
        'ignored_planet_nibble': planet,
        'system_index': system_index,
        'y': y,
        'z': z,
        'x': x,
        'galaxy_index': galaxy_index,
        'packed_system_seed': seed,
        'packed_system_seed_hex': f'0x{seed:016X}',
    }


def predict_system_name_from_seed(seed: int) -> dict[str, Any]:
    state = MWC(seed)

    first_dataset = DATASET_CHOICES[
        high_multiply_u32(state.draw(), len(DATASET_CHOICES))
    ]
    first_maximum = 6 + (state.draw() >> 30)
    first_word = _capitalise(
        generate_markov(state, first_dataset, 6, first_maximum)
    )
    default_name = first_word

    second_word = None
    second_dataset = None
    second_word_gate = None
    if len(first_word) <= 7:
        second_word_gate = high_multiply_u32(state.draw(), 100)
        if second_word_gate < 50:
            second_dataset = DATASET_CHOICES[
                high_multiply_u32(state.draw(), len(DATASET_CHOICES))
            ]
            second_word = _capitalise(
                generate_markov(state, second_dataset, 3, 5)
            )
            default_name += '-' + second_word

    roman_gate = high_multiply_u32(state.draw(), 100)
    roman_number = None
    roman = None
    if roman_gate < 30:
        roman_number = 1 + high_multiply_u32(state.draw(), 19)
        roman = ROMAN[roman_number]
        default_name += ' ' + roman

    return {
        'status': 'PASS_ADDRESS_ONLY_DEFAULT_SYSTEM_NAME_V1',
        'packed_system_seed_hex': f'0x{seed & 0xFFFFFFFFFFFFFFFF:016X}',
        'default_procedural_name': default_name,
        'language': 'English',
        'components': {
            'first_dataset': first_dataset,
            'first_maximum_length': first_maximum,
            'first_word': first_word,
            'second_word_gate_0_to_99': second_word_gate,
            'second_dataset': second_dataset,
            'second_word': second_word,
            'roman_gate_0_to_99': roman_gate,
            'roman_number': roman_number,
            'roman': roman,
        },
        'final_mwc_state': state.state_dict(),
        'scope_boundary': (
            'This predicts the default procedural name. Player renames and '
            'uploaded discovery-server names are not derivable from the address.'
        ),
    }


def predict_system_name_from_portal(
    portal: str,
    galaxy_index: int = 0,
) -> dict[str, Any]:
    packed = portal_to_system_seed(portal, galaxy_index)
    result = predict_system_name_from_seed(packed['packed_system_seed'])
    return {**result, 'address_conversion': packed}


def main() -> int:
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--portal', help='12-hex portal address PSSSYYZZZXXX')
    group.add_argument('--seed', help='packed 64-bit system seed')
    parser.add_argument('--galaxy-index', type=int, default=0)
    args = parser.parse_args()

    if args.portal is not None:
        result = predict_system_name_from_portal(
            args.portal,
            args.galaxy_index,
        )
    else:
        result = predict_system_name_from_seed(int(args.seed, 0))
    print(json.dumps(result, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
