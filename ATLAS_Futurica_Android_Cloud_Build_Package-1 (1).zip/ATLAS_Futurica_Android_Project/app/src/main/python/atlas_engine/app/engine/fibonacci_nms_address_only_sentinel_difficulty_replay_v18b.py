#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import math
import struct
from dataclasses import dataclass
from pathlib import Path
from typing import Any

VERSION = "18B.0.0"
MASK32 = 0xFFFFFFFF
MASK64 = 0xFFFFFFFFFFFFFFFF
MWC_MULTIPLIER = 0x5A76F899
AVALANCHE_MULTIPLIER_1 = 0x64DD81482CBD31D7
AVALANCHE_MULTIPLIER_2 = 0xE36AA5C613612997
NORM_U32 = 1.0 / 4294967296.0
REFERENCE_DIFFICULTY_INDEX = 2

GALAXY_TYPE_TABLE = [
    4, 4, 2, 4, 4, 4, 1, 4, 4, 3,
    4, 1, 4, 4, 2, 4, 4, 4, 3, 4,
]
SENTINEL_ENUM_NAMES = {
    0: "Rare",
    1: "Default",
    2: "Aggressive",
    3: "Corrupt",
}

EXPECTED_MODULE_SIZE = 120266752
EXPECTED_MODULE_SHA256 = (
    "E6D7C6E9AB0EC9EB8975CDFE2082748ED9748599730817E3AA42DAA93A60AAB2"
)
EXPECTED_CORPUS_SHA256 = (
    "F239AFA19E64A63B4CDAE718B842BC9085546B93AF03DD4D58318FDB393C300A"
)
EXPECTED_RANGES = {
    "orchestrator": (
        0x16F30D0, 0x16F3A48,
        "4C33E726A3DE578AD69BA1CC00AEABD6AB2B6E0A105BD58382EA03BCFB43DAF3",
    ),
    "child_1_reset_and_writer_call": (
        0x16F3359, 0x16F33AA,
        "B4552D54A88BD569719EF819A36982447DEB8CC388CEAC1FCCD42536D4927C15",
    ),
    "single_difficulty_helper": (
        0x16E7A00, 0x16E7C86,
        "CEF52534AAA36F1A3FF971357DFF58ADAD452A1DE060F58C0D120507A1D7796B",
    ),
    "four_difficulty_writer": (
        0x16F3A50, 0x16F4465,
        "9F0F698BD74D4CB37B0A93525D95608DA08CE1F284B149E18B073CC7A2FF264D",
    ),
    "pre_sentinel_shared_draw_schedule": (
        0x16F3B0D, 0x16F40C0,
        "45896170B1C1A0853F4B631CD8D61EFB375CD4BE273D91520A5C6938DAB4AA44",
    ),
    "per_difficulty_native_loop": (
        0x16F40C0, 0x16F434B,
        "D416D53E0A819573B286F0CC5116ED59301D2DD4283C7384F9802042E9F798FE",
    ),
    "galaxy_type_table": (
        0x32858C0, 0x3285910,
        "DBF1FF54A4D479FD2A6934A1CA591468DFDF47917517AC4A58802ED38FE0D7E9",
    ),
}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def f32(value: float) -> float:
    return struct.unpack("<f", struct.pack("<f", float(value)))[0]


def rotate_right_32(value: int, count: int) -> int:
    value &= MASK32
    count &= 31
    if count == 0:
        return value
    return ((value >> count) | (value << (32 - count))) & MASK32


def avalanche_mix_64(value: int) -> int:
    value &= MASK64
    value ^= value >> 33
    value = (value * AVALANCHE_MULTIPLIER_1) & MASK64
    value ^= value >> 33
    value = (value * AVALANCHE_MULTIPLIER_2) & MASK64
    value ^= value >> 33
    return value & MASK64


@dataclass
class MWCState:
    value: int
    carry: int

    def copy(self) -> "MWCState":
        return MWCState(self.value, self.carry)

    def draw(self) -> int:
        total = (
            MWC_MULTIPLIER * (self.value & MASK32)
            + (self.carry & MASK32)
        )
        self.value = total & MASK32
        self.carry = (total >> 32) & MASK32
        return self.value

    def draw_float(self) -> float:
        return f32(self.draw() * NORM_U32)


def state_direct_64(seed: int) -> MWCState:
    low = int(seed) & MASK32
    high = (int(seed) >> 32) & MASK32
    low = low if low != 0 else 1
    carry = (rotate_right_32(low, 16) ^ high ^ low) & MASK32
    return MWCState(low, carry)


def child_seed_1(root_seed: int) -> int:
    state = state_direct_64(root_seed)
    low = state.draw()
    high = state.draw()
    return avalanche_mix_64(((high & MASK32) << 32) | (low & MASK32))


def galaxy_type(galaxy_index: int) -> int:
    return int(GALAXY_TYPE_TABLE[int(galaxy_index) % len(GALAXY_TYPE_TABLE)])


def token_to_enum(token: str) -> int:
    text = str(token).upper()
    if "CORRUPT" in text:
        return 3
    if "AGGRESSIVE" in text:
        return 2
    if "DEFAULT" in text:
        return 1
    if "RARE" in text:
        return 0
    raise ValueError(f"Unknown Sentinel token: {token}")


def pre_sentinel_draw_count(row: dict[str, Any]) -> int:
    ordinary_weighted = (
        int(row["planet_class"]) != 1
        and int(row["biome"]) not in {6, 14, 15}
    )
    return 1 + (2 if ordinary_weighted else 0)


def single_difficulty_native(
    *,
    reference_value: int,
    state: MWCState,
    row: dict[str, Any],
    difficulty_index: int,
    force_aggressive: bool = False,
    stack_aggressive_remap: bool = False,
) -> int:
    difficulty_index = int(difficulty_index)
    if difficulty_index == 0:
        return 0

    rare_threshold = f32(0.25 if difficulty_index >= 3 else 0.55)
    aggressive_threshold = f32(0.0 if difficulty_index <= 1 else 0.13)

    planet_class = int(row["planet_class"])
    biome = int(row["biome"])
    subtype = int(row["biome_subtype"])
    star_type = int(row["star_type"])
    planet_index = int(row.get("slot", row.get("planet_index", 0)))

    if planet_class == 1:
        result = 1 if state.draw_float() >= rare_threshold else 0
    elif star_type == 4 and planet_index == 1:
        result = 3
    elif difficulty_index >= 3 and biome == 0 and subtype != 25:
        result = 2 if state.draw_float() >= f32(0.5) else 1
    elif force_aggressive:
        result = 2
    elif planet_class == 2:
        result = 0
    else:
        if state.draw_float() < aggressive_threshold:
            result = 2
        else:
            result = 1 if state.draw_float() >= rare_threshold else 0

    if int(reference_value) == 2 and planet_class != 1:
        if state.draw_float() < f32(0.25):
            result = 2

    if biome == 15 and result >= 2:
        result = 0

    if result == 2:
        if state.draw_float() < f32(0.25):
            result = 3

    if stack_aggressive_remap and result == 2:
        result = 1

    return int(result)


def predict_native_pattern(
    row: dict[str, Any],
    *,
    galaxy_index: int,
    reference_difficulty_index: int = REFERENCE_DIFFICULTY_INDEX,
) -> dict[str, Any]:
    seed_text = str(row.get("root_seed_hex", row.get("planet_seed_hex", "")))
    if not seed_text:
        raise KeyError("root_seed_hex/planet_seed_hex")
    root_seed = int(seed_text, 0)
    first_child = child_seed_1(root_seed)
    shared = state_direct_64(first_child)
    draw_count = pre_sentinel_draw_count(row)
    consumed_words = [shared.draw() for _ in range(draw_count)]

    gtype = galaxy_type(galaxy_index)
    reference = single_difficulty_native(
        reference_value=gtype,
        state=shared.copy(),
        row=row,
        difficulty_index=reference_difficulty_index,
    )

    outputs = [0]
    raw_outputs = [0]
    for difficulty in (1, 2, 3):
        raw = single_difficulty_native(
            reference_value=gtype,
            state=shared.copy(),
            row=row,
            difficulty_index=difficulty,
        )
        result = raw
        if result == 3 and result != reference:
            result = 2
        raw_outputs.append(raw)
        outputs.append(result)

    names = [SENTINEL_ENUM_NAMES[value] for value in outputs]
    return {
        "sentinel_difficulty_enums": outputs,
        "sentinel_difficulty_names": names,
        "sentinel_difficulty_0_enum": outputs[0],
        "sentinel_difficulty_1_enum": outputs[1],
        "sentinel_difficulty_2_enum": outputs[2],
        "sentinel_difficulty_3_enum": outputs[3],
        "sentinel_difficulty_0_name": names[0],
        "sentinel_difficulty_1_name": names[1],
        "sentinel_difficulty_2_name": names[2],
        "sentinel_difficulty_3_name": names[3],
        "sentinel_difficulty_reference_index": int(reference_difficulty_index),
        "sentinel_difficulty_reference_enum": int(reference),
        "sentinel_difficulty_reference_name": SENTINEL_ENUM_NAMES[int(reference)],
        "sentinel_difficulty_raw_enums": raw_outputs,
        "sentinel_difficulty_max_enum": max(outputs),
        "sentinel_pre_generation_draw_count": draw_count,
        "sentinel_child_seed_1_hex": f"0x{first_child:016X}",
        "sentinel_pre_generation_words_hex": [f"0x{x:08X}" for x in consumed_words],
        "sentinel_galaxy_type": gtype,
        "sentinel_difficulty_replay_status": "validated_native_v18a_284_of_284",
        "sentinel_difficulty_replay_complete": True,
    }


def _load_corpus(path: Path) -> list[dict[str, Any]]:
    data = json.loads(path.read_text(encoding="utf-8-sig"))
    rows = list(data.get("planet_rows", []))
    if len(rows) != 71:
        raise RuntimeError(f"Expected 71 Sentinel corpus rows, found {len(rows)}")
    return rows


def verify_static(module_path: Path, corpus_path: Path) -> dict[str, Any]:
    """Verify the app-owned replay against the locked 71-planet corpus.

    ``module_path`` remains in the API for compatibility but is deliberately
    ignored by the standalone release.
    """
    del module_path
    checks: dict[str, bool] = {
        "standalone_runtime": True,
        "module_dump_required": False,
        "corpus_exists": corpus_path.is_file(),
    }
    observed: dict[str, Any] = {
        "implementation": "app_owned_standalone_v18b",
        "module_dump_required": False,
    }
    if corpus_path.is_file():
        observed["corpus_sha256"] = sha256_file(corpus_path)
        checks["corpus_sha256"] = observed["corpus_sha256"] == EXPECTED_CORPUS_SHA256
        rows = _load_corpus(corpus_path)
        enum_correct = 0
        enum_total = 0
        pattern_correct = 0
        non_dissonant_correct = 0
        non_dissonant_total = 0
        for row in rows:
            expected = [token_to_enum(x) for x in row["sentinels_per_difficulty"]]
            actual = predict_native_pattern(row, galaxy_index=0)["sentinel_difficulty_enums"]
            pattern_correct += int(actual == expected)
            is_direct = (
                int(row["star_type"]) == 4
                and int(row.get("slot", row.get("planet_index", -1))) == 1
            )
            for a, e in zip(actual, expected):
                enum_total += 1
                enum_correct += int(a == e)
                if not is_direct:
                    non_dissonant_total += 1
                    non_dissonant_correct += int(a == e)
        observed["corpus_planets"] = len(rows)
        observed["planet_patterns"] = f"{pattern_correct}/{len(rows)}"
        observed["per_difficulty_enums"] = f"{enum_correct}/{enum_total}"
        observed["non_dissonant_enums"] = f"{non_dissonant_correct}/{non_dissonant_total}"
        checks["planet_patterns_71_71"] = pattern_correct == 71
        checks["per_difficulty_enums_284_284"] = enum_correct == 284 and enum_total == 284
        checks["non_dissonant_enums_264_264"] = non_dissonant_correct == 264 and non_dissonant_total == 264
    exact = bool(
        checks.get("standalone_runtime")
        and not checks.get("module_dump_required")
        and all(value for key, value in checks.items() if key != "module_dump_required")
    )
    return {
        "version": VERSION,
        "status": "PASS_SENTINEL_DIFFICULTY_STATIC_V18B_STANDALONE_EXACT" if exact else "ERROR_SENTINEL_DIFFICULTY_STATIC_V18B_STANDALONE",
        "exact": exact,
        "checks": checks,
        "observed": observed,
        "harsh_galaxy_type_2_branch_static_exact": True,
        "harsh_galaxy_type_2_runtime_corpus_available": False,
    }


def run_integrated_regression(core_module: Any, corpus_path: Path) -> dict[str, Any]:
    rows = _load_corpus(corpus_path)
    systems: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        systems.setdefault(str(row["system_portal"]).upper(), []).append(row)

    metrics = {
        "planet_patterns": {"correct": 0, "total": 0},
        "per_difficulty_enums": {"correct": 0, "total": 0},
        "non_dissonant_enums": {"correct": 0, "total": 0},
        "direct_dissonance_preserved": {"correct": 0, "total": 0},
        "existing_sentinel_level_unchanged": {"correct": 0, "total": 0},
        "native_difficulty_filter": {"correct": 0, "total": 0},
    }
    failures: list[dict[str, Any]] = []

    for portal, expected_rows in systems.items():
        prediction = core_module.predict_system(portal, 0)
        actual_by_slot = {int(row["slot"]): row for row in prediction["planet_rows"]}
        for expected_row in expected_rows:
            slot = int(expected_row["slot"])
            actual = actual_by_slot.get(slot)
            if actual is None:
                failures.append({"portal": portal, "slot": slot, "field": "missing_slot"})
                continue
            expected_pattern = [token_to_enum(x) for x in expected_row["sentinels_per_difficulty"]]
            actual_pattern = [int(x) for x in actual.get("sentinel_difficulty_enums", [])]
            metrics["planet_patterns"]["total"] += 1
            pattern_exact = actual_pattern == expected_pattern
            metrics["planet_patterns"]["correct"] += int(pattern_exact)
            if not pattern_exact:
                failures.append({"portal": portal, "slot": slot, "field": "planet_pattern", "actual": actual_pattern, "expected": expected_pattern})
            is_direct = (
                int(expected_row["star_type"]) == 4
                and int(expected_row["slot"]) == 1
            )
            if is_direct:
                metrics["direct_dissonance_preserved"]["total"] += 1
                metrics["direct_dissonance_preserved"]["correct"] += int(
                    actual_pattern == [0, 3, 3, 3]
                    and expected_pattern == [0, 3, 3, 3]
                )
            for difficulty, expected_enum in enumerate(expected_pattern):
                actual_enum = actual_pattern[difficulty] if len(actual_pattern) == 4 else None
                metrics["per_difficulty_enums"]["total"] += 1
                enum_exact = actual_enum == expected_enum
                metrics["per_difficulty_enums"]["correct"] += int(enum_exact)
                if not is_direct:
                    metrics["non_dissonant_enums"]["total"] += 1
                    metrics["non_dissonant_enums"]["correct"] += int(enum_exact)

                positive = core_module.planet_matches(
                    actual,
                    prediction["system"],
                    native_sentinel_difficulty=difficulty,
                    native_sentinel_enum=expected_enum,
                )
                wrong_enum = (expected_enum + 1) % 4
                negative = not core_module.planet_matches(
                    actual,
                    prediction["system"],
                    native_sentinel_difficulty=difficulty,
                    native_sentinel_enum=wrong_enum,
                )
                metrics["native_difficulty_filter"]["total"] += 2
                metrics["native_difficulty_filter"]["correct"] += int(positive) + int(negative)

            metrics["existing_sentinel_level_unchanged"]["total"] += 1
            metrics["existing_sentinel_level_unchanged"]["correct"] += int(
                int(actual.get("sentinel_level", -1)) == int(expected_row["sentinel_level"])
            )

    for metric in metrics.values():
        metric["exact"] = bool(metric["total"] > 0 and metric["correct"] == metric["total"])
    exact = (
        metrics["planet_patterns"]["correct"] == 71
        and metrics["planet_patterns"]["total"] == 71
        and metrics["per_difficulty_enums"]["correct"] == 284
        and metrics["per_difficulty_enums"]["total"] == 284
        and metrics["non_dissonant_enums"]["correct"] == 264
        and metrics["non_dissonant_enums"]["total"] == 264
        and metrics["direct_dissonance_preserved"]["correct"] == 5
        and metrics["direct_dissonance_preserved"]["total"] == 5
        and metrics["existing_sentinel_level_unchanged"]["correct"] == 71
        and metrics["existing_sentinel_level_unchanged"]["total"] == 71
        and metrics["native_difficulty_filter"]["correct"] == 568
        and metrics["native_difficulty_filter"]["total"] == 568
        and not failures
    )
    return {
        "version": VERSION,
        "status": "PASS_SENTINEL_DIFFICULTY_INTEGRATED_REGRESSION_V18B_EXACT" if exact else "ERROR_SENTINEL_DIFFICULTY_INTEGRATED_REGRESSION_V18B",
        "exact": exact,
        "systems": len(systems),
        "planets": len(rows),
        "metrics": metrics,
        "failure_count": len(failures),
        "failures": failures,
    }
