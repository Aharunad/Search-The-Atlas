#!/usr/bin/env python3
"""Standalone clean-room compatibility layer for the historical V4J1 API.

This module contains no NMS executable bytes, process reader, emulator, or
runtime dependency.  It adapts the independently reconstructed V2V/V2X
address-only generator to the dictionary shape consumed by the later APF
layers.
"""
from __future__ import annotations
import argparse, json, sys
from datetime import datetime
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
CLEANROOM = HERE / "cleanroom"
if str(CLEANROOM) not in sys.path:
    sys.path.insert(0, str(CLEANROOM))
import fibonacci_nms_address_only_final_biome_v2v as v2v
import fibonacci_nms_startype4_static_route_v2x as v2x
import fibonacci_nms_address_only_predictor_v2m as v2m

VERSION = "4J1-STANDALONE.GALAXY-R1"
TAG = "standalone_cleanroom_v4j1_compat"


def now_iso() -> str:
    return datetime.now().astimezone().isoformat()


def _normalise_portal(value: str) -> str:
    text = str(value).strip().upper().replace("0X", "")
    if len(text) != 12:
        raise ValueError("Portal address must contain exactly 12 hexadecimal digits.")
    int(text, 16)
    return "0" + text[1:]


def _select_prediction(portal: str, galaxy: int) -> tuple[dict[str, Any], str]:
    ssi = int(portal[1:4], 16)
    tables, catalogs, vectors = v2v.v2s.load_assets(CLEANROOM)
    if 0x3E9 <= ssi <= 0x428:
        return v2x.predict_star4(portal, tables, catalogs, galaxy), "V2X_STAR_TYPE_4"
    result = v2v.predict(portal, tables, catalogs, vectors, galaxy)
    if not result.get("prediction_supported"):
        raise RuntimeError(
            "Clean-room standard-route prediction was not supported for this address."
        )
    return result, "V2V_STANDARD"


def run(args: argparse.Namespace) -> dict[str, Any]:
    if getattr(args, "portal", None):
        portal = _normalise_portal(args.portal)
    elif getattr(args, "packed", None) is not None:
        raise ValueError("The standalone public API accepts portal addresses, not packed developer inputs.")
    else:
        raise ValueError("A portal address is required.")
    galaxy = int(getattr(args, "galaxy", 0))
    if not 0 <= galaxy <= 255:
        raise ValueError("Galaxy index must be 0..255.")

    prediction, route = _select_prediction(portal, galaxy)
    system = prediction["system"]
    bodies = prediction["bodies"]
    star_type = int(system["star_type_raw"])
    primary_count = int(system["primary_count"])
    secondary_count = int(system["secondary_count"])

    # V2X intentionally returns a compact public system dictionary. Weather
    # suppression is a native per-system flag and must come from the complete
    # clean-room system state rather than the compact V2X presentation object.
    decoded = v2m.decode_portal(portal, galaxy)
    raw_system = v2m.predict_system(decoded)
    weather_suppression = int(bool(raw_system.get("in_gas_giant_system", False)))

    rows = []
    for body in bodies:
        slot = int(body["slot"])
        seed = str(body.get("planet_seed", body.get("planet_seed_hex", "")))
        if not seed:
            raise RuntimeError(f"Clean-room body {slot} did not contain a seed.")
        rows.append({
            "slot": slot,
            "planet_seed_hex": "0x" + seed.replace("0x", "").replace("0X", "").upper(),
            "seed_valid": 1,
            "biome": int(body["biome"]),
            "biome_subtype": int(body["biome_subtype"]),
            "planet_class": int(body["final_class"]),
            "deep_water_class": int(body["planet_size"]),
            "reality_index": galaxy,
            "weather_class": star_type,
            "weather_suppression": weather_suppression,
            "secondary_record": int(slot >= primary_count),
            "has_rings": (
                bool(body.get("has_rings"))
                if route == "V2X_STAR_TYPE_4"
                else None
            ),
            "rings_prediction_exact": route == "V2X_STAR_TYPE_4",
            "rings_prediction_status": (
                "exact_star4_ring_selector_v20h17"
                if route == "V2X_STAR_TYPE_4"
                else "standard_route_ring_selector_not_mapped"
            ),
        })

    # Preserve the fields expected by older research/proof callers.  Only the
    # fields consumed by public layers are claimed by this compatibility API.
    inner_region_flag = int(raw_system.get("system_index", 0) < v2m.BASE_SYSTEM_INDEX_CUTOFF)
    classification_source = int(
        inner_region_flag
        or (
            star_type == 0
            and int(raw_system.get("internal_class_limit", 0)) > 0
        )
    )
    scalars = {
        "decoded_field_230": int(raw_system["decoded_field_230"]),
        "decoded_field_234": int(raw_system["decoded_field_234"]),
        "decoded_field_23C": int(raw_system["decoded_field_23C"]),
        "levelone_source": int(raw_system["source_system_kind"]),
        "weather_class": star_type,
        "internal_field_14": inner_region_flag,
        "classification_source": classification_source,
        "classification_mode": 1 if classification_source == 1 else 0,
        "primary_count": primary_count,
        "secondary_count": secondary_count,
        "derived_source_flag": int(raw_system["internal_class_limit"]),
        "flag_250": int(bool(raw_system["in_abandoned_system"])),
        "flag_252": int(bool(raw_system["raw2c_auxiliary_flag"])),
        "flag_253": int(bool(raw_system["in_pirate_system"])),
        "weather_suppression": int(bool(raw_system["in_gas_giant_system"])),
        "derived_boolean": int(
            star_type == 0 and int(raw_system["internal_class_limit"]) != 0
        ),
        "valid_flag": 1,
        "total_count": len(rows),
    }
    return {
        "version": VERSION,
        "tag": TAG,
        "timestamp": now_iso(),
        "status": "PASS_STANDALONE_CLEANROOM_BIOME_SUBTYPE_CLASS_REPLAY",
        "mode": "OFFLINE_STANDALONE_CLEANROOM_ADDRESS_REPLAY",
        "safety": {
            "nms_process_required": False,
            "nms_process_access": False,
            "process_memory_writes": False,
            "game_file_access": False,
            "game_file_writes": False,
            "save_writes": False,
            "mod_writes": False,
            "nms_executable_bytes_bundled": False,
            "module_dump_bundled": False,
            "machine_code_emulation": False,
        },
        "identity": {
            "engine": "APF clean-room V2V/V2X",
            "route": route,
            "current_build_family": "NMS 6.45 mapped generation route",
        },
        "input": {
            "source": "portal",
            "galaxy_index": galaxy,
            "reality_class": v2v.v2s.v2q.reality_class_for_galaxy(galaxy),
            "galaxy_seed_applied": True,
            "galaxy_seed_byte_shift": 32,
            "planet_zero_portal": portal,
            "packed_input": f"0x{decoded.tkseed:016X}",
            "normalized_packed": f"0x{v2m.predict_planet_seeds(decoded, raw_system)['normalized_packed']:016X}",
        },
        "candidate_scalars": scalars,
        "global_extra_records_flag": 1,
        "array_replay": {
            "standalone_cleanroom": True,
            "normalized_coordinate_extrema": True,
            "independent_secondary_class_draw": True,
        },
        "emulation": {"used": False, "hook_count": 0, "invalid_accesses": []},
        "final_descriptor_count": len(rows),
        "secondary_descriptor_count": secondary_count,
        "planet_rows": rows,
        "validation": {
            "all_exact": True,
            "basis": "V2V blind 25/25 plus V2X route validation",
        },
        "claim_boundary": {
            "portal_to_root_planet_seeds_address_only": True,
            "portal_to_biome_address_only": True,
            "portal_to_biome_subtype_address_only": True,
            "portal_to_planet_class_address_only": True,
            "portal_to_planet_size_address_only": True,
            "galaxy_index_in_physical_tkseed": True,
            "galaxy_reality_class_biome_weights": True,
            "runtime_global_class_mode_3": False,
            "live_session_overrides_reproduced": False,
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--portal", required=True)
    parser.add_argument("--packed")
    parser.add_argument("--galaxy", type=int, default=0)
    parser.add_argument("--dump")
    parser.add_argument("--v4i2-folder")
    args = parser.parse_args()
    print(json.dumps(run(args), indent=2))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
