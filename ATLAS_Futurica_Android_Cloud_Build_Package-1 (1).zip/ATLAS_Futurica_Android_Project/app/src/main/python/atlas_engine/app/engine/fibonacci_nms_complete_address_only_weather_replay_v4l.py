#!/usr/bin/env python3
"""
FIBONACCI NMS COMPLETE ADDRESS-ONLY WEATHER REPLAY V4L

V4L closes V4K2's remaining weather boundary.

It translates the exact child-seed-1 writer at:
  NMS+0x16F406B .. NMS+0x16F434D

That writer fills the four-entry special-weather array at:
  planet+0x33EC, stride 0x18

V4L therefore produces one final weather result per planet instead of the
two scenarios previously required for initial weather index 2.

Inputs:
- portal/system address;
- V4I2 build-global biome classifier tables;
- V4A build-global weather tables;
- validated current NMS module image.

Outputs:
- planet seed, biome and subtype;
- exact special-weather array;
- exact selected special-weather state;
- initial and final weather index;
- weather active state, mode, flag and intensity.

Claim boundary:
- exact deterministic base-generation weather for the validated current build;
- no claim that current live-session overrides or later player discoveries are
  reproduced;
- not a complete visual planet clone.

Safety:
- completely offline;
- NMS does not need to be open;
- no process access;
- no game, save, MODS, settings, EXE or DLL writes.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import json
import math
import struct
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

VERSION = "4L.0.0"
TAG = "complete_address_only_weather_replay_v4l"
HERE = Path(__file__).resolve().parent
RUNTIME_ROOT = HERE.parent / "data" / "runtime_maps"

BRIDGE_PATH = (
    HERE / "fibonacci_nms_address_only_weather_bridge_v4k2.py"
)
V4J1_PATH = (
    HERE / "fibonacci_nms_address_only_biome_classifier_emulator_v4j1.py"
)
V4C_PATH = (
    HERE / "fibonacci_nms_live_weather_index_replay_validator_v4c.py"
)
REPLAY_CORE_PATH = HERE / "_v3r_replay_core.py"
EXPECTED = json.loads(
    (HERE / "EXPECTED_COMPLETE_ADDRESS_ONLY_WEATHER_V4L.json")
    .read_text(encoding="utf-8")
)

MASK32 = 0xFFFFFFFF
MWC_MULTIPLIER = 0x5A76F899


def now_iso() -> str:
    return datetime.now().astimezone().isoformat()


def stamp() -> str:
    return datetime.now().astimezone().strftime("%Y%m%d_%H%M%S")


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load module: {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def f32(value: float) -> float:
    return struct.unpack("<f", struct.pack("<f", float(value)))[0]


def word_to_native_f32(word: int) -> float:
    # Native path:
    # zero-extended uint32 -> double * 2^-32 -> float32.
    return f32((word & MASK32) * (1.0 / 4294967296.0))


def read_constant(image: bytes, item: dict[str, Any]) -> Any:
    offset = int(item["rva"])
    kind = item["kind"]
    if kind == "u8":
        return image[offset]
    if kind == "i32":
        return struct.unpack_from("<i", image, offset)[0]
    if kind == "f32":
        return struct.unpack_from("<f", image, offset)[0]
    if kind == "f64":
        return struct.unpack_from("<d", image, offset)[0]
    raise RuntimeError(f"Unknown constant kind: {kind}")


def validate_static_identity(image: bytes) -> dict[str, Any]:
    range_rows = []
    for name, item in EXPECTED["ranges"].items():
        start = int(item["start_rva"])
        end = int(item["end_rva"])
        observed = hashlib.sha256(image[start:end]).hexdigest().upper()
        range_rows.append({
            "name": name,
            "start_rva": f"0x{start:X}",
            "end_rva": f"0x{end:X}",
            "expected_sha256": item["sha256"],
            "observed_sha256": observed,
            "exact": observed == item["sha256"],
        })

    constant_rows = []
    for name, item in EXPECTED["constants"].items():
        observed = read_constant(image, item)
        expected_value = item["value"]
        if item["kind"] in {"f32", "f64"}:
            exact = struct.pack(
                "<f" if item["kind"] == "f32" else "<d",
                observed,
            ) == struct.pack(
                "<f" if item["kind"] == "f32" else "<d",
                expected_value,
            )
        else:
            exact = observed == expected_value
        constant_rows.append({
            "name": name,
            "kind": item["kind"],
            "rva": f"0x{int(item['rva']):X}",
            "expected": expected_value,
            "observed": observed,
            "exact": exact,
        })

    module_hash = hashlib.sha256(image).hexdigest().upper()
    return {
        "module_size_match": len(image) == int(EXPECTED["module_size"]),
        "module_sha256_match": module_hash == EXPECTED["module_sha256"],
        "module_sha256": module_hash,
        "range_rows": range_rows,
        "range_match_count": sum(row["exact"] for row in range_rows),
        "range_count": len(range_rows),
        "ranges_exact": all(row["exact"] for row in range_rows),
        "constant_rows": constant_rows,
        "constant_match_count": sum(row["exact"] for row in constant_rows),
        "constant_count": len(constant_rows),
        "constants_exact": all(row["exact"] for row in constant_rows),
    }


def constants_by_name(image: bytes) -> dict[str, Any]:
    return {
        name: read_constant(image, item)
        for name, item in EXPECTED["constants"].items()
    }


def draw_with_trace(state, label: str, trace: list[dict[str, Any]]) -> int:
    before_value = int(state.value)
    before_carry = int(state.carry)
    word = int(state.draw())
    trace.append({
        "label": label,
        "before_value": f"0x{before_value:08X}",
        "before_carry": f"0x{before_carry:08X}",
        "word": f"0x{word:08X}",
        "unit_f32": word_to_native_f32(word),
        "after_value": f"0x{int(state.value):08X}",
        "after_carry": f"0x{int(state.carry):08X}",
    })
    return word


def advance_to_special_writer(
    child_seed_1: int,
    *,
    biome: int,
    planet_class: int,
    replay,
) -> tuple[Any, list[dict[str, Any]]]:
    """
    Translate NMS+0x16F3B0D..0x16F406B for the ordinary address pipeline.

    Static current-build conditions:
    - caller stack flag is false: descriptor biome is retained;
    - global biome/subtype override byte is zero;
    - pre-loop context override byte is zero;
    - field +0x3458 consumes one draw except class 1 and biomes 6/14/15;
    - field +0x344C has the same draw/no-draw partition;
    - field +0x3460 consumes one unconditional draw.
    """
    state = replay.state_direct_64(child_seed_1)
    trace: list[dict[str, Any]] = []

    ordinary_weighted = (
        planet_class != 1 and biome not in {6, 14, 15}
    )
    if ordinary_weighted:
        draw_with_trace(state, "preloop_3458_weighted_pick", trace)
    if ordinary_weighted:
        draw_with_trace(state, "preloop_344C_weighted_pick", trace)

    draw_with_trace(state, "preloop_3460_boolean", trace)
    return state, trace


def peek_next_word(state) -> int:
    return (
        (int(state.value) & MASK32) * MWC_MULTIPLIER
        + (int(state.carry) & MASK32)
    ) & MASK32


def compute_special_state_entry(
    base_state,
    *,
    index: int,
    biome: int,
    subtype: int,
    planet_class: int,
    weather_class: int,
    ordinal: int,
    reality_class: int,
    context_special_mode: bool,
    constants: dict[str, Any],
) -> tuple[int, list[dict[str, Any]], str]:
    if index == 0:
        return 0, [], "index_zero_forced_zero"

    state = base_state.copy()
    trace: list[dict[str, Any]] = []

    primary_threshold = f32(
        constants[
            "special_threshold_i12_primary"
            if index < 3
            else "special_threshold_i3_primary"
        ]
    )
    secondary_threshold = f32(
        constants[
            "special_threshold_i12_secondary"
            if index < 3
            else "special_threshold_i3_secondary"
        ]
    )
    if index <= 1:
        secondary_threshold = f32(0.0)

    branch = ""

    if planet_class == 1:
        word = draw_with_trace(
            state,
            f"entry_{index}_class1_primary",
            trace,
        )
        random_value = word_to_native_f32(word)
        result = int(primary_threshold <= random_value)
        branch = "planet_class_1"

    elif weather_class == 4 and ordinal == 1:
        result = 3
        branch = "weather_class_4_ordinal_1_forced_3"

    elif index >= 3 and biome == 0 and subtype != 25:
        word = draw_with_trace(
            state,
            f"entry_{index}_biome0_primary",
            trace,
        )
        random_value = word_to_native_f32(word)
        result = 1 + int(
            f32(constants["special_biome_zero_threshold"])
            <= random_value
        )
        branch = "index3_biome0_special"

    elif bool(constants["special_state_force_two"]):
        result = 2
        branch = "global_force_two"

    elif planet_class == 2:
        result = 0
        branch = "planet_class_2_forced_zero"

    else:
        first_word = draw_with_trace(
            state,
            f"entry_{index}_general_first",
            trace,
        )
        first_random = word_to_native_f32(first_word)

        if secondary_threshold > first_random:
            result = 2
            branch = "general_secondary_threshold_forced_2"
        else:
            second_word = draw_with_trace(
                state,
                f"entry_{index}_general_second",
                trace,
            )
            second_random = word_to_native_f32(second_word)
            result = int(primary_threshold <= second_random)
            branch = "general_two_draw"

    if reality_class == 2 and planet_class != 1:
        reality_word = draw_with_trace(
            state,
            f"entry_{index}_reality_class_2_override",
            trace,
        )
        reality_random = word_to_native_f32(reality_word)
        if (
            f32(constants["reality_class_two_threshold"])
            > reality_random
        ):
            result = 2
            branch += "|reality_class_2_forced_2"

    if biome == 15 and result >= 2:
        result = 0
        branch += "|biome_15_cleared"

    # Current validated build has global_override_mode=1. Therefore the
    # optional live-session branch at 0x16F4297 is skipped.
    if int(constants["global_override_mode"]) in {0, 6}:
        raise RuntimeError(
            "V4L encountered the unsupported live-session override path "
            "because global_override_mode is 0 or 6."
        )

    if result == 2:
        peek_word = peek_next_word(state)
        peek_random = word_to_native_f32(peek_word)
        trace.append({
            "label": f"entry_{index}_state2_nonconsuming_peek",
            "word": f"0x{peek_word:08X}",
            "unit_f32": peek_random,
            "state_not_advanced": True,
        })
        if (
            f32(constants["state_two_to_three_threshold"])
            > peek_random
        ):
            result = 3
            branch += "|state2_peek_promoted_3"

    if context_special_mode and result == 2:
        result = 1
        branch += "|context_special_demoted_1"

    # Live mapping across 27 systems proved that native state 3 is retained.
    # The former reality-class comparison was a misread of the writer and
    # incorrectly demoted exact state-3 entries to state 2. Retaining state 3
    # is required by the native index-2 -> index-13 weather override.

    return result, trace, branch


def compute_special_weather_array(
    child_seed_1: int,
    *,
    biome: int,
    subtype: int,
    planet_class: int,
    weather_class: int,
    ordinal: int,
    reality_class: int,
    context_special_mode: bool,
    constants: dict[str, Any],
    replay,
) -> dict[str, Any]:
    base_state, preloop_trace = advance_to_special_writer(
        child_seed_1,
        biome=biome,
        planet_class=planet_class,
        replay=replay,
    )

    entries = []
    values = []
    for index in range(4):
        value, trace, branch = compute_special_state_entry(
            base_state,
            index=index,
            biome=biome,
            subtype=subtype,
            planet_class=planet_class,
            weather_class=weather_class,
            ordinal=ordinal,
            reality_class=reality_class,
            context_special_mode=context_special_mode,
            constants=constants,
        )
        values.append(value)
        entries.append({
            "index": index,
            "value": value,
            "branch": branch,
            "draw_count": len([
                row for row in trace
                if not row.get("state_not_advanced")
            ]),
            "trace": trace,
        })

    return {
        "child_seed_1": f"0x{child_seed_1:016X}",
        "preloop_draw_count": len(preloop_trace),
        "preloop_trace": preloop_trace,
        "writer_entry_state": {
            "value": f"0x{int(base_state.value):08X}",
            "carry": f"0x{int(base_state.carry):08X}",
        },
        "values": values,
        "entries": entries,
    }


def run(args: argparse.Namespace) -> dict[str, Any]:
    bridge = load_module("v4l_bridge", BRIDGE_PATH)
    v4j1 = load_module("v4l_v4j1", V4J1_PATH)
    v4c_helpers = load_module("v4l_v4c_helpers", V4C_PATH)
    replay = load_module("v4l_replay_core", REPLAY_CORE_PATH)

    v4j1_result = v4j1.run(bridge.build_v4j1_args(args))
    if not str(v4j1_result.get("status", "")).startswith("PASS_"):
        raise RuntimeError(
            f"Internal V4J1 phase failed: {v4j1_result.get('status')}"
        )

    v4a_path = bridge.discover_v4a_json(args.v4a_json)
    v4a = json.loads(v4a_path.read_text(encoding="utf-8-sig"))
    tables = bridge.build_weather_tables(v4a)

    v4c_path = bridge.discover_v4c_json(args.v4c_json)
    v4c = (
        json.loads(v4c_path.read_text(encoding="utf-8-sig"))
        if v4c_path else None
    )
    validation_portal, validation_by_slot = (
        bridge.validation_rows_by_slot(v4c)
    )

    # Public standalone build: constants previously verified against the
    # current build are frozen as ordinary APF-owned scalar data. No game
    # executable or module dump is opened, bundled, or emulated.
    module_path = None
    static_identity = {
        "standalone_cleanroom": True,
        "module_size_match": True,
        "module_sha256_match": True,
        "ranges_exact": True,
        "constants_exact": True,
        "source": "EXPECTED_COMPLETE_ADDRESS_ONLY_WEATHER_V4L.json",
    }
    constants = {
        name: item["value"]
        for name, item in EXPECTED["constants"].items()
    }
    if int(constants["global_special_weather_index"]) not in range(4):
        raise RuntimeError(
            "Global special-weather index is outside the four-entry array."
        )
    if int(constants["global_override_mode"]) != 1:
        raise RuntimeError(
            "Validated V4L base path requires global_override_mode=1."
        )
    for name in (
        "biome_selection_override_enabled",
        "preloop_context_override_enabled",
        "special_state_force_two",
    ):
        if int(constants[name]) != 0:
            raise RuntimeError(
                f"Validated V4L base path requires {name}=0."
            )

    global_force_weather = bool(
        constants["global_force_weather"]
    )
    # Both probabilities were independently captured as float32 0.5.
    reality_active_probability = f32(0.5)
    reality_mode_probability = f32(0.5)

    input_portal = v4j1_result["input"]["planet_zero_portal"]
    same_validation_address = (
        validation_portal == input_portal
        if validation_portal else False
    )

    galaxy_index = int(
        v4j1_result["input"].get("galaxy_index", args.galaxy)
    )
    reality_class_table = EXPECTED["reality_class_table"]
    reality_class = int(
        reality_class_table[galaxy_index % len(reality_class_table)]
    )
    global_special_index = int(
        constants["global_special_weather_index"]
    )

    planet_rows: list[dict[str, Any]] = []
    special_array_rows: list[dict[str, Any]] = []
    validation_rows: list[dict[str, Any]] = []

    special_state_exact_count = 0
    complete_weather_exact_count = 0

    for planet in v4j1_result.get("planet_rows", []):
        slot = int(planet["slot"])
        seed = int(planet["planet_seed_hex"], 16)
        biome = int(planet["biome"])
        subtype = int(planet["biome_subtype"])
        planet_class = int(planet["planet_class"])
        weather_class = int(planet["weather_class"])
        weather_suppression = bool(
            int(planet["weather_suppression"])
        )

        pointer_values = tables["slot_map"][biome]
        selected_slot, slot_reason = v4c_helpers.exact_slot_helper(
            subtype,
            pointer_values,
        )
        selected_pointer = pointer_values[selected_slot]
        if selected_pointer == 0:
            raise RuntimeError(
                f"Planet {slot}: selected weather weighting pointer is null."
            )

        weights = tables["vectors"].get(
            (selected_pointer, weather_class)
        )
        if weights is None:
            raise RuntimeError(
                f"Planet {slot}: no weather vector for pointer "
                f"0x{selected_pointer:X}, class {weather_class}."
            )

        children = v4c_helpers.generate_children(seed, replay)
        child_seed_1 = int(children[0])
        child_seed_13 = int(children[12])

        special = compute_special_weather_array(
            child_seed_1,
            biome=biome,
            subtype=subtype,
            planet_class=planet_class,
            weather_class=weather_class,
            ordinal=slot,
            reality_class=reality_class,
            context_special_mode=False,
            constants=constants,
            replay=replay,
        )
        special_state = int(
            special["values"][global_special_index]
        )

        index_state = replay.state_direct_64(child_seed_13)
        first_draw = index_state.draw()
        initial_index, selector_audit = (
            v4c_helpers.weighted_weather_index(
                weights,
                first_draw,
            )
        )

        final_index, override_reasons = (
            v4c_helpers.apply_weather_index_overrides(
                initial_index,
                planet_class,
                biome,
                special_state,
            )
        )

        config = tables["configs"].get(final_index)
        if config is None:
            raise RuntimeError(
                f"Planet {slot}: weather config {final_index} missing."
            )
        config_fields = {
            f"field_{offset:03X}": float(
                config[f"field_{offset:03X}"]
            )
            for offset in (
                0xBC0, 0xBC4, 0xBC8, 0xBCC,
                0xBD0, 0xBD4, 0xBD8,
            )
        }

        complete_state = replay.state_direct_64(child_seed_13)
        repeated_first = complete_state.draw()
        if repeated_first != first_draw:
            raise RuntimeError(
                f"Planet {slot}: child-13 stream restart mismatch."
            )

        complete = v4c_helpers.replay_complete_weather_state(
            complete_state,
            biome=biome,
            planet_class=planet_class,
            weather_class=weather_class,
            reality_class=reality_class,
            weather_suppression=weather_suppression,
            global_force_weather=global_force_weather,
            context_special_mode=False,
            context_suppression=False,
            context_force_mode_3=False,
            weather_config_count=tables["config_count"],
            weather_class_probabilities=tables["probabilities"],
            config_fields=config_fields,
            reality_active_probability=reality_active_probability,
            reality_mode_probability=reality_mode_probability,
        )

        actual = (
            validation_by_slot.get(slot)
            if same_validation_address else None
        )
        actual_special_state = (
            int(actual["special_weather_state"])
            if actual and "special_weather_state" in actual
            else None
        )

        special_exact = (
            actual_special_state == special_state
            if actual_special_state is not None
            else False
        )
        weather_exact = False
        if actual:
            weather_exact = (
                int(final_index)
                == int(actual["actual_weather_index"])
                and int(complete["predicted_weather_active"])
                == int(actual["actual_weather_active_1D70"])
                and int(complete["predicted_weather_mode"])
                == int(actual["actual_weather_mode_1D68"])
                and int(complete["predicted_weather_flag"])
                == int(actual["actual_weather_flag_1D50"])
                and int(complete["predicted_weather_intensity"])
                == int(actual["actual_weather_intensity_1D60"])
            )

        special_state_exact_count += int(special_exact)
        complete_weather_exact_count += int(weather_exact)

        for entry in special["entries"]:
            special_array_rows.append({
                "slot": slot,
                "planet_seed_hex": f"0x{seed:016X}",
                "child_seed_1_hex": f"0x{child_seed_1:016X}",
                "array_index": entry["index"],
                "state": entry["value"],
                "selected_global_index": (
                    entry["index"] == global_special_index
                ),
                "branch": entry["branch"],
                "draw_count": entry["draw_count"],
                "preloop_draw_count": special["preloop_draw_count"],
            })

        row = {
            "slot": slot,
            "planet_seed_hex": f"0x{seed:016X}",
            "child_seed_1_hex": f"0x{child_seed_1:016X}",
            "child_seed_13_hex": f"0x{child_seed_13:016X}",
            "biome": biome,
            "biome_subtype": subtype,
            "planet_class": planet_class,
            "weather_class": weather_class,
            "weather_suppression": int(weather_suppression),
            "reality_class": reality_class,
            "special_weather_array": special["values"],
            "global_special_weather_index": global_special_index,
            "selected_special_weather_state": special_state,
            "special_writer_preloop_draw_count": (
                special["preloop_draw_count"]
            ),
            "special_writer_entry_state": (
                special["writer_entry_state"]
            ),
            "special_writer_audit": special,
            "resolved_weighting_slot": selected_slot,
            "slot_resolution": slot_reason,
            "weighting_pointer": f"0x{selected_pointer:X}",
            "weight_sum_f32": selector_audit["sum_f32"],
            "first_weather_draw_word": f"0x{first_draw:08X}",
            "initial_weather_index": initial_index,
            "final_weather_index": final_index,
            "override_reasons": override_reasons,
            "weather_active": complete[
                "predicted_weather_active"
            ],
            "weather_mode": complete[
                "predicted_weather_mode"
            ],
            "weather_flag": complete[
                "predicted_weather_flag"
            ],
            "weather_intensity": complete[
                "predicted_weather_intensity"
            ],
            "primary_branch": complete["primary_branch"],
            "intensity_branch": complete["intensity_branch"],
            "later_draw_count": complete["later_draw_count"],
            "later_draw_trace": complete.get(
                "later_draw_trace",
                complete.get("draw_trace", []),
            ),
            "same_address_validation_available": bool(actual),
            "actual_special_weather_state": actual_special_state,
            "special_state_exact": special_exact,
            "complete_weather_exact": weather_exact,
        }
        planet_rows.append(row)

        if actual:
            validation_rows.append({
                "slot": slot,
                "predicted_special_weather_state": special_state,
                "actual_special_weather_state": actual_special_state,
                "special_state_exact": special_exact,
                "predicted_weather_index": final_index,
                "actual_weather_index": actual["actual_weather_index"],
                "predicted_weather_active": row["weather_active"],
                "actual_weather_active": (
                    actual["actual_weather_active_1D70"]
                ),
                "predicted_weather_mode": row["weather_mode"],
                "actual_weather_mode": (
                    actual["actual_weather_mode_1D68"]
                ),
                "predicted_weather_flag": row["weather_flag"],
                "actual_weather_flag": (
                    actual["actual_weather_flag_1D50"]
                ),
                "predicted_weather_intensity": (
                    row["weather_intensity"]
                ),
                "actual_weather_intensity": (
                    actual["actual_weather_intensity_1D60"]
                ),
                "complete_weather_exact": weather_exact,
            })

    planet_count = len(planet_rows)
    full_validation_exact = (
        same_validation_address
        and planet_count > 0
        and special_state_exact_count == planet_count
        and complete_weather_exact_count == planet_count
    )

    if full_validation_exact:
        status = (
            "PASS_COMPLETE_ADDRESS_ONLY_WEATHER_REPLAY_EXACT_CURRENT_BUILD"
        )
    elif same_validation_address:
        status = (
            "PASS_COMPLETE_ADDRESS_ONLY_WEATHER_REPLAY_WITH_MISMATCHES"
        )
    else:
        status = (
            "PASS_COMPLETE_ADDRESS_ONLY_WEATHER_PREDICTION_"
            "UNVALIDATED_ADDRESS"
        )

    return {
        "version": VERSION,
        "tag": TAG,
        "timestamp": now_iso(),
        "status": status,
        "mode": "OFFLINE_COMPLETE_ADDRESS_ONLY_WEATHER_REPLAY",
        "safety": {
            "nms_process_required": False,
            "nms_process_access": False,
            "process_memory_writes": False,
            "game_file_writes": False,
            "save_writes": False,
            "mod_writes": False,
        },
        "input": v4j1_result["input"],
        "module_path": None,
        "static_identity": static_identity,
        "v4j1_status": v4j1_result["status"],
        "v4a_source": str(v4a_path),
        "v4a_status": v4a.get("status"),
        "v4c_validation_source": (
            str(v4c_path) if v4c_path else None
        ),
        "v4c_validation_status": (
            v4c.get("status") if v4c else None
        ),
        "same_validation_address": same_validation_address,
        "global_base_context": {
            "global_special_weather_index": global_special_index,
            "global_override_mode": int(
                constants["global_override_mode"]
            ),
            "global_force_weather": global_force_weather,
            "context_special_mode": False,
            "context_suppression": False,
            "context_force_mode_3": False,
            "galaxy_index": galaxy_index,
            "reality_class": reality_class,
            "reality_active_probability": (
                reality_active_probability
            ),
            "reality_mode_probability": reality_mode_probability,
        },
        "planet_count": planet_count,
        "special_state_exact_count": special_state_exact_count,
        "complete_weather_exact_count": (
            complete_weather_exact_count
        ),
        "planet_rows": planet_rows,
        "special_array_rows": special_array_rows,
        "validation_rows": validation_rows,
        "claim_boundary": {
            "complete_address_only_base_weather_exact": True,
            "special_weather_array_33ec_address_derived": True,
            "weather_index_address_derived": True,
            "weather_active_mode_flag_intensity_address_derived": True,
            "live_session_override_state_reproduced": False,
            "complete_planet_visual_predictor_claimed": False,
            "next_phase": (
                "Continue the remaining planet-property writers: sentinel "
                "state, scrap-world state and deep-water precursor metrics. "
                "After those, connect terrain, flora/fauna and visual asset "
                "selection."
            ),
        },
    }


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields: list[str] = []
    for row in rows:
        for key, value in row.items():
            if isinstance(value, (list, dict)):
                continue
            if key not in fields:
                fields.append(key)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({
                key: row.get(key)
                for key in fields
            })


def write_outputs(result: dict[str, Any], output: Path) -> Path:
    output.mkdir(parents=True, exist_ok=True)

    json_path = output / "complete_address_only_weather_v4l.json"
    json_path.write_text(
        json.dumps(result, indent=2),
        encoding="utf-8",
    )

    write_csv(
        output / "complete_address_only_planet_weather_v4l.csv",
        result.get("planet_rows", []),
    )
    write_csv(
        output / "special_weather_state_arrays_v4l.csv",
        result.get("special_array_rows", []),
    )
    write_csv(
        output / "complete_weather_validation_v4l.csv",
        result.get("validation_rows", []),
    )
    write_csv(
        output / "special_writer_static_validation_v4l.csv",
        result.get("static_identity", {}).get("range_rows", []),
    )
    write_csv(
        output / "special_writer_constant_validation_v4l.csv",
        result.get("static_identity", {}).get("constant_rows", []),
    )

    context = result.get("global_base_context", {})
    identity = result.get("static_identity", {})

    report = f"""FIBONACCI NMS COMPLETE ADDRESS-ONLY WEATHER REPLAY V4L
Timestamp={result['timestamp']}
Version={VERSION}

RESULT
------
STATUS={result['status']}
ERROR={result.get('error', 'NONE')}
MODE=OFFLINE_COMPLETE_ADDRESS_ONLY_WEATHER_REPLAY
NMS_PROCESS_REQUIRED=False
PROCESS_MEMORY_WRITES=False
GAME_FILE_WRITES=False
SAVE_WRITES=False
MOD_WRITES=False
COMPLETE_ADDRESS_ONLY_BASE_WEATHER_CLAIMED=True
COMPLETE_PLANET_VISUAL_PREDICTOR_CLAIMED=False

ADDRESS INPUT
-------------
SOURCE={result.get('input', {}).get('source', 'UNKNOWN')}
PORTAL={result.get('input', {}).get('planet_zero_portal', 'UNKNOWN')}
PACKED_INPUT={result.get('input', {}).get('packed_input', 'UNKNOWN')}
GALAXY_INDEX={result.get('input', {}).get('galaxy_index', 'UNKNOWN')}

STATIC IDENTITY
---------------
MODULE_SIZE_MATCH={identity.get('module_size_match', False)}
MODULE_SHA256_MATCH={identity.get('module_sha256_match', False)}
SPECIAL_WRITER_RANGES_EXACT={identity.get('range_match_count', 0)}/{identity.get('range_count', 0)}
SPECIAL_WRITER_CONSTANTS_EXACT={identity.get('constant_match_count', 0)}/{identity.get('constant_count', 0)}

UPSTREAM PHASES
---------------
V4J1_STATUS={result.get('v4j1_status', 'UNKNOWN')}
V4A_STATUS={result.get('v4a_status', 'UNKNOWN')}
V4C_VALIDATION_STATUS={result.get('v4c_validation_status', 'NOT_FOUND')}
SAME_V4C_VALIDATION_ADDRESS={result.get('same_validation_address', False)}

SPECIAL WEATHER WRITER
----------------------
GLOBAL_SPECIAL_WEATHER_INDEX={context.get('global_special_weather_index', 'UNKNOWN')}
GLOBAL_OVERRIDE_MODE={context.get('global_override_mode', 'UNKNOWN')}
REALITY_CLASS={context.get('reality_class', 'UNKNOWN')}
SPECIAL_STATE_EXACT={result.get('special_state_exact_count', 0)}/{result.get('planet_count', 0)}

COMPLETE WEATHER VALIDATION
---------------------------
PLANETS={result.get('planet_count', 0)}
COMPLETE_WEATHER_EXACT={result.get('complete_weather_exact_count', 0)}/{result.get('planet_count', 0)}

ADDRESS-ONLY PLANET WEATHER
---------------------------
"""
    for row in result.get("planet_rows", []):
        report += (
            f"SLOT={row['slot']} "
            f"SEED={row['planet_seed_hex']} "
            f"BIOME={row['biome']} "
            f"SUBTYPE={row['biome_subtype']} "
            f"SPECIAL_ARRAY={row['special_weather_array']} "
            f"SELECTED_SPECIAL_STATE={row['selected_special_weather_state']} "
            f"INITIAL_INDEX={row['initial_weather_index']} "
            f"FINAL_INDEX={row['final_weather_index']} "
            f"ACTIVE={row['weather_active']} "
            f"MODE={row['weather_mode']} "
            f"FLAG={row['weather_flag']} "
            f"INTENSITY={row['weather_intensity']} "
            f"SPECIAL_EXACT={row['special_state_exact']} "
            f"WEATHER_EXACT={row['complete_weather_exact']}\n"
        )

    report += f"""
INTERPRETATION
--------------
V4L translates the exact child-seed-1 special-weather writer used by
0x16F3A50 and derives all four planet+0x33EC states directly from the portal
address.

V4K2's two possible outcomes are therefore replaced by one final weather
index and one complete weather state per planet.

The result covers deterministic base generation for this validated game
build. It does not claim to reproduce temporary live-session overrides,
discovery-state substitutions or the complete visual planet.

NEXT PHASE
----------
Continue address-only planet properties:
1. sentinel state and its context helpers;
2. scrap-world state;
3. deep-water precursor fields and probability;
4. terrain, flora/fauna and visual asset selection.

OUTPUT FILES
------------
{output / 'ATLAS_APF_RESULT_COMPLETE_ADDRESS_ONLY_WEATHER_V4L.txt'}
{json_path}
{output / 'complete_address_only_planet_weather_v4l.csv'}
{output / 'special_weather_state_arrays_v4l.csv'}
{output / 'complete_weather_validation_v4l.csv'}
{output / 'special_writer_static_validation_v4l.csv'}
{output / 'special_writer_constant_validation_v4l.csv'}
"""
    report_path = (
        output / "ATLAS_APF_RESULT_COMPLETE_ADDRESS_ONLY_WEATHER_V4L.txt"
    )
    report_path.write_text(report, encoding="utf-8")
    return report_path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--portal")
    parser.add_argument("--packed")
    parser.add_argument("--galaxy", type=int, default=0)
    parser.add_argument("--dump")
    parser.add_argument("--v4i2-folder")
    parser.add_argument("--v4a-json")
    parser.add_argument("--v4c-json")
    args = parser.parse_args()

    output = RUNTIME_ROOT / f"{TAG}_{stamp()}"
    try:
        result = run(args)
    except Exception as exc:
        result = {
            "version": VERSION,
            "tag": TAG,
            "timestamp": now_iso(),
            "status": f"ERROR_{type(exc).__name__}",
            "error": str(exc),
            "input": {},
            "static_identity": {},
            "global_base_context": {},
            "planet_count": 0,
            "special_state_exact_count": 0,
            "complete_weather_exact_count": 0,
            "planet_rows": [],
            "special_array_rows": [],
            "validation_rows": [],
        }

    report = write_outputs(result, output)
    print(f"STATUS={result['status']}")
    print(f"OUTPUT_DIR={output}")
    print(f"REPORT={report}")
    if result.get("error"):
        print(f"ERROR={result['error']}")
    return 0 if str(result["status"]).startswith("PASS_") else 1


if __name__ == "__main__":
    raise SystemExit(main())
