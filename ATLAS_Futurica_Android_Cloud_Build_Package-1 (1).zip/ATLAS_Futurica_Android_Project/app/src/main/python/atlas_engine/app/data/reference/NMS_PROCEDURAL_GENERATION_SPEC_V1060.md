# No Man’s Sky Address-derived Procedural World Generation
## Structured Process Specification

This document defines the data model, deterministic generation stages, rule catalogue, field semantics, dependencies, lookup tables, algorithms and claim boundaries used for address-derived procedural generation.

## Model counts

| Record class | Count |
|---|---:|
| Entities | 17 |
| Relationships | 18 |
| Address Segments | 3 |
| Numeric Primitives | 10 |
| Process Stages | 25 |
| Generation Rules | 129 |
| Data Fields | 666 |
| Algorithms | 13 |
| Dependency Edges | 39 |
| Enumeration Values | 331 |
| Weather Hazard Records | 16 |
| Gas Giant Atmosphere Records | 6 |
| Water Style Records | 19 |
| Worked Traces | 3 |
| Claim Boundaries | 7 |

## Entity model

| Entity | Primary Key | Cardinality | Contains | Description |
|---|---|---|---|---|
| Galaxy | galaxy_index_internal | 256 | Regions | Top-level procedural namespace. User numbering is 1–256; generator indexing is 0–255. |
| Region | region_suffix | coordinate-dependent | Star systems | Eight-hex portal suffix identifying the galactic voxel/region used for local system traversal. |
| Portal destination | canonical_system_portal | one per address | System target plus optional body target | Normalised 12-glyph input, decomposed into body nibble, solar-system index and region suffix. |
| Star system | canonical_system_portal + galaxy_index_internal | one per occupied destination | Planet bodies and system selectors | Deterministically generated system record containing star colour, population state, economy, conflict and race. |
| Planet body | system key + internal slot | 0–6 generated root bodies | Environment and visual properties | Root planetary body generated from a planet root seed. Public numbering is internal slot + 1. |
| Moon | parent planet key + moon ordinal | 0–5 per eligible parent | Moon environment properties | Child body associated with a large/giant parent. The moon retains parent metadata and has its own exact portal target. |
| Biome state | planet root seed + biome selectors | one effective state per body | Biome family, subtype, source and classification | Native biome selection plus source-table interpretation and public classification. |
| Terrain state | planet root seed + terrain selector | one record per body | Terrain family and source record | Generated independently from biome/subbiome; describes voxel terrain shape rather than prop-based subbiome content. |
| Water state | planet root seed + water branch | zero or one per body | Ocean depth, style, colour and emission | Water presence and complete water profile. Generated palettes and static WATERCOLOURS records are separate layers. |
| Weather state | planet root seed + biome branch | one base state per body | Storm, severity and passive condition fields | Functional weather generation, distinct from decorative discovery-name wording. |
| Life state | planet root seed + life streams | one per body | Life abundance, creature abundance and descriptors | Address-derived abundance and descriptor signals; not a complete species appearance generator. |
| Sentinel state | planet root seed + combat difficulty | four contextual records per body | Native Sentinel category and activity | Native Sentinel outcome is evaluated separately for each supported on-foot combat difficulty. |
| Surface visual state | planet root seed + object/palette streams | one per body | Grass, flora capability and palette channels | Separates exact palette values from object-list capability and final visual coverage. |
| Atmosphere state | planet root seed + atmosphere selectors | one per body | Cloud, sky, fog, sunset and night palettes | Native selector values and generated palettes; final rendered appearance may require a presentation mapping. |
| Resource state | planet root seed + biome/star/weather | one per body | Resource level and substance identifiers | Generated resource abundance and common/uncommon/rare substance selections. |
| Procedural name | system/body seed + language | one default name per entity | Default English system or planet name | Generated name before any player discovery rename. |
| Search match | scope ordinal + planet portal | zero or more | Flattened generated body record and match reasons | A generated body that satisfies every active filter in deterministic scan order. |

## Relationships

| From | Relationship | To | Cardinality | Key Rule |
|---|---|---|---|---|
| Galaxy | contains | Region | 1:N | galaxy_index_internal is retained through every downstream seed domain |
| Region | contains occupied | Star system | 1:N | region suffix + occupied solar-system index identifies the portal destination |
| Portal destination | targets | Star system | 1:1 | canonical first nibble is 0 |
| Portal destination | optionally targets | Planet body | 0:1 | first nibble 1–6 maps to internal slot 0–5 |
| Star system | contains | Planet body | 1:N | planet count bounds valid internal slots |
| Planet body | parents | Moon | 1:0..5 | moon generator consumes the parent structure result |
| Planet body | owns | Biome state | 1:1 | biome derives from body root seed and system context |
| Planet body | owns | Terrain state | 1:1 | terrain selector is independent from public subbiome |
| Planet body | may own | Water state | 1:0..1 | water-active branch gates profile generation |
| Planet body | owns | Weather state | 1:1 | weather consumes generated biome and weather streams |
| Planet body | owns | Life state | 1:1 | life and descriptors consume dedicated deterministic streams |
| Planet body | owns | Sentinel state | 1:4 | same body evaluated under four combat difficulty contexts |
| Planet body | owns | Surface visual state | 1:1 | object-list and palette selectors consume body seed plus biome source |
| Planet body | owns | Atmosphere state | 1:1 | native table selector and generated palette sequences are both retained |
| Planet body | owns | Resource state | 1:1 | resource selection depends on body seed, biome, class, star and weather |
| Star system | has | Procedural name | 1:1 | canonical address + galaxy + English name generator |
| Planet body | has | Procedural name | 1:1 | planet root seed + English name generator |
| Planet body | becomes | Search match | 1:0..1 per search | all active predicates must evaluate true |

## Portal-address schema

| Order | Segment | Hex Positions | Bits | Range | Meaning | Normalisation |
|---|---|---|---|---|---|---|
| 1 | Body target | 1 | 4 | 0x0–0x6 | 0 targets the canonical system; 1–6 targets generated internal slot 0–5 | canonical_system_portal = 0 + address[1:12] |
| 2 | Solar-system index (SSI) | 2–4 | 12 | 0x000–0xFFF raw | Selects a candidate system within the region | system_index = int(address[1:4], 16) |
| 3 | Region suffix | 5–12 | 32 | 0x00000000–0xFFFFFFFF | Encodes the local galactic region/voxel coordinates used by system generation | region_suffix = canonical_system_portal[4:12] |

## Deterministic numeric primitives

| Id | Formula | Purpose |
|---|---|---|
| MASK32 | value & 0xFFFFFFFF | Force unsigned 32-bit wraparound after native integer operations. |
| MASK64 | value & 0xFFFFFFFFFFFFFFFF | Force unsigned 64-bit wraparound after seed operations. |
| MWC_DRAW | total = 0x5A76F899 * (value & MASK32) + (carry & MASK32); value = total & MASK32; carry = (total >> 32) & MASK32 | Multiply-with-carry state transition used by deterministic streams. |
| ROTATE_RIGHT_32 | ((x >> n) \| (x << (32 - n))) & MASK32 | 32-bit rotation used while constructing an MWC carry value. |
| STATE_DIRECT_64 | low = seed.low32 or 1; carry = ROR32(low,16) XOR seed.high32 XOR low | Convert one 64-bit seed into the initial MWC state. |
| AVALANCHE64 | x ^= x>>33; x*=0x64DD81482CBD31D7; x^=x>>33; x*=0xE36AA5C613612997; x^=x>>33 | Mix a raw 64-bit draw pair into a child seed. |
| CHILD_SEEDS | repeat 26 times: low=draw(); high=draw(); child=AVALANCHE64((high<<32)\|low) | Derive named child seed domains from a root seed without sharing stream state. |
| SELECT_MULHI | index = ((word & MASK32) * count) >> 32 | Map a 32-bit word into an unbiased integer selector range [0,count). |
| WORD_TO_F32 | float32((word & MASK32) / 2^32) | Reproduce the native [0,1) random float conversion with single-precision rounding. |
| RESOURCE_THRESHOLD | resource_level = int(native_f32 > 0.75) | Convert the exact resource writer draw into the two-level resource family. |

## Generation pipeline

| Order | Stage Id | Stage | Entity | Depends On | Inputs | Operation | Outputs | Determinism | Unknown Policy |
|---|---|---|---|---|---|---|---|---|---|
| 1 | input_decode | Input decoding | Portal destination | None | 12 glyph/hex characters; user galaxy number | Sanitise separators; validate 12 hexadecimal digits; validate body nibble 0–6; convert galaxy 1–256 to internal 0–255. | requested body number, internal slot, canonical system address, SSI, region suffix, galaxy metadata | Pure validation and transformation | Reject malformed values; never coerce impossible body numbers. |
| 2 | reachability | Portal occupancy and domain resolution | Star system | input_decode | canonical address, SSI, region suffix, galaxy | Resolve region-specific legacy occupancy; classify Purple interval; reject unmapped or unsupported SSI bands. | address kind, real-system status, access guidance, exact searchable bounds | Exact native count replay for standard systems; fixed mapped interval for Purple systems | Do not include unresolved raw generator indices in travel results. |
| 3 | system_seed | System seed construction | Star system | reachability | canonical address and internal galaxy index | Encode coordinates and galaxy into the native system-generation seed domain. | system root state used by numeric generation | Bit-exact integer path | No approximate hashing substitutions. |
| 4 | system_numeric | System structural generation | Star system | system_seed | system root state | Replay the native numeric generator in exact draw order. | planet count, star type/colour, per-body root seeds and base numeric rows | Exact replay | Changing draw order invalidates every downstream selector. |
| 5 | system_state | System-state selection | Star system | system_numeric | system root state, star type, native selector streams | Resolve empty, abandoned, gas-giant, pirate/ordinary state and inhabited-system selectors. | primary state and state labels | Exact selector branches where mapped | Expose unavailable for selectors without a solved address assignment. |
| 6 | economy_conflict_race | Economy, conflict and race | Star system | system_state | system selector state | Select economy type, economy tier, conflict level and dominant race; apply pirate display semantics without discarding economy type or race. | raw/internal/public economy, conflict and race fields | Exact native selectors | Unavailable remains explicit. |
| 7 | body_hierarchy | Planet and moon hierarchy | Planet body / Moon | system_numeric | planet count, body root seeds, system structure streams | Assign internal slots, public planet numbers, parent/child status, native size class and moon count. | body type, generated size, moon count, parent relation and exact body portals | Exact mapped structure replay | Moon rows display no independent moon-count value. |
| 8 | rings | Rendered ring assignment | Planet body | body_hierarchy, system_state | system domain, body structure and ring selector state | Evaluate exact rendered-ring branch for eligible standard-system parent bodies; attach parent ring metadata to moon rows. | has_rings, exactness/status, moon-parent ring fields | Exact for mapped standard systems; current Purple branch is no rings | Do not infer ring texture, colour or visual thickness. |
| 9 | biome | Biome and subtype generation | Biome state | system_numeric, body_hierarchy | planet root seed, star/system context, biome tables | Select native biome family, subtype and source table; resolve effective biome and special subtype flags. | biome ID/name, subtype, source filename, effective biome | Exact selector and current tables | Keep native source values separate from public presentation labels. |
| 10 | classification | Planet classification | Biome state | biome, water, weather | biome, subtype, water state, weather and class branches | Derive discovery/scanner classification and Paradise/literal branches from generated state. | classification, description family/token, Paradise flags | Exact where token family coverage is complete | Do not replace generated family with a guessed visual description. |
| 11 | terrain | Terrain selection | Terrain state | system_numeric | body generation state and terrain selector stream | Select one voxel terrain record and map it to a public terrain family. | terrain record index/name/family | Exact selector rule | Terrain is independent from biome/subbiome; do not conflate Floating Islands terrain with prop subbiomes. |
| 12 | water_presence | Water and ocean structure | Water state | biome, body_hierarchy | water flags, high-water flag, sea level and body compatibility | Resolve no ocean, regular ocean, deep ocean or waterworld depth state. | water_active, high_water, sea_level, ocean_type | Exact generated fields | Impossible body/ocean combinations are blocked. |
| 13 | water_profile | Water style and glow profile | Water state | water_presence | planet root seed, water branch, static WATERCOLOURS records, generated colour streams | Select one of 19 water styles; derive WaterEmission, FoamEmission, murkiness, Water palette and DeepWaterBioLum palette. | style ID/index, emission enums, murkiness bits/float, generated palettes | Exact complete profile | Static EmissionColour is not the same field as generated night/deep-water glow. |
| 14 | weather | Weather generation | Weather state | biome, system_numeric | planet root seed, biome branch and weather streams | Replay base weather selector; classify active/mode/intensity, clear/extreme family, storm schedule and functional metadata. | weather indices, storm frequency, severity, special state, passive-condition fields | Exact base state; bounded passive/special hazards where assignment is not solved | Separate decorative discovery names from functional weather behaviour. |
| 15 | resources | Resource and substance generation | Resource state | biome, weather, system_numeric | planet root seed, biome, class, star type and weather | Use dedicated child stream for resource level; select common, uncommon and rare substance IDs by star/weather/biome tables. | resource level/family and substance identifiers | Exact writer and selectors | No hotspot coordinates or player-built extractor state. |
| 16 | life | Life and creature abundance | Life state | biome, weather | planet root seed and life selector streams | Select Life and CreatureLife abundance plus exact native descriptor values. | life levels, abundance tokens and four descriptor fields | Exact address-derived selectors | Descriptor signals are not a full species-model generator. |
| 17 | fauna_taxonomy | Fauna interpretation | Life state | life | native life abundance and descriptor fields | Map native descriptor combinations into professional taxonomy/archetype signals. | structured fauna profile, capability and danger-signal fields | Deterministic interpretation of exact descriptors | Dangerous-signal exclusion does not guarantee absolute predator absence. |
| 18 | sentinels | Sentinel activity | Sentinel state | system_numeric, biome | planet state and combat difficulty 0–3 | Replay native Sentinel outcome independently for each difficulty context. | native enum, public activity category and exactness | Exact per difficulty | Always retain the difficulty context with the result. |
| 19 | special_planet | Dissonance, infestation and salvage | Planet body | biome, sentinels, system_state | star type, planet index, subtype, Sentinel state and building level | Evaluate direct Purple dissonance branch, portal-safe dissonance, Infested subtype predicate and salvageable-scrap branch. | dissonant/corrupt, infested and scrap fields with reasons | Exact mapped predicates | Do not collapse distinct native Corrupt and public Dissonance meanings. |
| 20 | surface_assets | Surface object capability | Surface visual state | biome | biome source and object-list selector | Select surface object-list route and derive primary grass/mushroom/emissive capability flags. | asset capability and mapped visual-flora variant fields | Exact selector/capability mapping | Capability does not guarantee density or screen coverage. |
| 21 | surface_colours | Grass and surface colour palettes | Surface visual state | surface_assets | planet root seed and colour selector streams | Select Grass and GrassAlt indices and preserve exact RGBA/hex/native name plus verified rendered annotation where known. | Grass/GrassAlt source values, detailed names, families and swatches | Exact generated palette values | Rendered annotations never replace the native source value. |
| 22 | atmosphere | Atmosphere and sky palettes | Atmosphere state | biome, weather | planet root seed, atmosphere selector and native sky tables | Generate Cloud, Sky, Horizon, Fog, HeightFog, Sunset and Night sequences; preserve native Day/Dusk/Night selectors. | palette sequences, native selector values and rendered-family presentation fields | Exact native/generated values; rendered mapping only where directly verified | Unmapped final rendered appearance remains unavailable. |
| 23 | names | Default procedural names | Procedural name | system_seed, system_numeric | canonical system address + galaxy, or planet root seed; English language tables | Run the deterministic English name generator for system and body entities. | default system and planet/moon names | Exact default generated English names | Player-renamed discovery names are outside the offline model. |
| 24 | presentation | Public record construction | Planet body / Star system | all generation stages | native/generated fields and bounded interpretation layers | Emit raw, internal and public values together; attach exactness/status/claim-boundary fields; avoid destructive relabelling. | stable system and body records | Pure transformation | Unknown values are labelled unavailable, never guessed. |
| 25 | search | Finder traversal and predicate evaluation | Search match | reachability, presentation | anchor region, search domain, range, region order, active filters and result limit | Enumerate real portal systems in deterministic order; generate each system; evaluate every active body predicate; merge worker output in requested scan order. | ordered matches, tested counts and scan statistics | Deterministic ordering independent of worker count | Searches mapped portal destinations, not every raw 12-bit generator index. |

## Dependency graph

| From Stage | To Stage | Dependency Type | Reason |
|---|---|---|---|
| input_decode | reachability | required | A valid canonical address is needed before occupancy can be checked. |
| reachability | system_seed | required | Only a classified destination enters system generation. |
| system_seed | system_numeric | seed | System numeric replay consumes the system seed. |
| system_numeric | system_state | state | System selectors consume the generated system state. |
| system_state | economy_conflict_race | branch | Economy/race availability depends on system population/state. |
| system_numeric | body_hierarchy | state | Body count and root seeds determine body records. |
| body_hierarchy | rings | structure | Ring assignment requires parent body structure. |
| system_state | rings | domain | Purple/standard domain affects current ring branch. |
| system_numeric | biome | seed | Biome consumes each body root seed. |
| biome | classification | semantic | Classification depends on generated biome state. |
| system_numeric | terrain | seed | Terrain uses a separate deterministic selector stream. |
| biome | water_presence | compatibility | Biome/body state constrains water compatibility. |
| body_hierarchy | water_presence | compatibility | Body type constrains ocean support. |
| water_presence | water_profile | gate | Profile is generated only for active water. |
| biome | weather | branch | Weather table/family selection depends on biome. |
| weather | classification | semantic | Paradise/extreme wording depends on weather state. |
| biome | resources | lookup | Substances and branch schedules depend on biome. |
| weather | resources | lookup | Common substance route may depend on weather. |
| biome | life | branch | Life selector context includes biome state. |
| life | fauna_taxonomy | interpretation | Taxonomy interprets exact native life/descriptors. |
| system_numeric | sentinels | seed | Sentinel outcomes consume body generation state. |
| sentinels | special_planet | branch | Dissonance presentation uses native Sentinel outcome. |
| biome | special_planet | branch | Infested uses biome subtype 24. |
| biome | surface_assets | lookup | Object lists are selected within biome source context. |
| surface_assets | surface_colours | context | Colour presentation uses generated surface channels and capabilities. |
| biome | atmosphere | lookup | Atmosphere selector and palettes are generated within body context. |
| weather | atmosphere | presentation | Weather affects how generated sky may be experienced but does not overwrite native values. |
| system_seed | names | identity | System name derives from canonical system identity. |
| system_numeric | names | identity | Body name derives from body root seed. |
| classification | presentation | record | Classification fields feed the final body record. |
| terrain | presentation | record | Terrain fields feed the final body record. |
| water_profile | presentation | record | Water fields feed the final body record. |
| weather | presentation | record | Weather fields feed the final body record. |
| resources | presentation | record | Resource fields feed the final body record. |
| fauna_taxonomy | presentation | record | Life/fauna fields feed the final body record. |
| sentinels | presentation | record | Sentinel fields feed the final body record. |
| surface_colours | presentation | record | Surface visual fields feed the final body record. |
| atmosphere | presentation | record | Atmosphere fields feed the final body record. |
| presentation | search | predicate | Finder evaluates normalised filters against completed body records. |

## Algorithms and pseudocode

### A01 — Portal parser

- **Inputs:** text address
- **Outputs:** normalised 12-hex address, body number
- **Preconditions:** After separators are removed, length is 12 and every character is hexadecimal.
- **Invariant:** No address silently wraps or truncates.

```text
text = upper(remove_separators(input))
if text starts "0X": text = text[2:]
require len(text)==12 and hex(text)
body = hex_to_int(text[0])
require 0 <= body <= 6
return text, body
```

### A02 — Canonical system address

- **Inputs:** validated address
- **Outputs:** zero-prefixed system address
- **Preconditions:** Address passed A01.
- **Invariant:** All system-level generation ignores the public body target nibble.

```text
canonical = "0" + address[1:12]
```

### A03 — Exact body portal

- **Inputs:** canonical system address, internal slot
- **Outputs:** one-based exact body address
- **Preconditions:** 0 <= internal_slot <= 5.
- **Invariant:** System and planet addresses share the same SSI and region suffix.

```text
public_number = internal_slot + 1
return hex(public_number) + canonical[1:12]
```

### A04 — Portal domain classification

- **Inputs:** SSI, resolved standard occupancy count
- **Outputs:** legacy occupied, legacy unoccupied, Purple, gap or unsupported
- **Preconditions:** SSI in 0..4095.
- **Invariant:** Finder never treats an unoccupied or unmapped SSI as a travel destination.

```text
if 0 <= SSI < native_legacy_count: occupied_standard
elif 0 <= SSI <= 0x2FF: unoccupied_standard_candidate
elif 0x3E9 <= SSI <= 0x428: purple_portal_system
elif 0x300 <= SSI <= 0x3E8: unmapped_gap
else: unsupported
```

### A05 — MWC state initialisation

- **Inputs:** 64-bit seed
- **Outputs:** 32-bit value and carry
- **Preconditions:** Unsigned seed semantics.
- **Invariant:** Zero low word is replaced by one.

```text
low = seed & MASK32
high = seed >> 32
if low == 0: low = 1
carry = ROR32(low,16) XOR high XOR low
return MWC(low, carry)
```

### A06 — MWC draw

- **Inputs:** MWC state
- **Outputs:** next 32-bit word and updated state
- **Preconditions:** State created by A05.
- **Invariant:** All arithmetic wraps exactly as unsigned native integers.

```text
total = 0x5A76F899 * value + carry
value = total & MASK32
carry = (total >> 32) & MASK32
return value
```

### A07 — Child seed derivation

- **Inputs:** root seed
- **Outputs:** 26 deterministic child seeds
- **Preconditions:** Root seed is exact.
- **Invariant:** Child domains must be consumed by index; generating one domain must not advance another.

```text
state = A05(root)
for i in 0..25:
  low=A06(state); high=A06(state)
  raw=(high<<32)|low
  child[i]=AVALANCHE64(raw)
```

### A08 — Unbiased selector

- **Inputs:** 32-bit word, option count
- **Outputs:** index in [0,count)
- **Preconditions:** count >= 1.
- **Invariant:** Do not use modulo; modulo changes selector probabilities.

```text
if count <= 1: return 0
return ((word & MASK32) * count) >> 32
```

### A09 — Native random float

- **Inputs:** 32-bit word
- **Outputs:** single-precision value in [0,1)
- **Preconditions:** Unsigned word.
- **Invariant:** Single-precision rounding is part of branch compatibility.

```text
return float32((word & MASK32) * (1 / 4294967296))
```

### A10 — Resource-level writer

- **Inputs:** planet root seed, biome, planet class
- **Outputs:** resource level and family
- **Preconditions:** Body seed and native class/biome are known.
- **Invariant:** The two preceding draws occur only on the ordinary weighted branch.

```text
child1 = A07(root)[0]
state=A05(child1)
if class != 1 and biome not special:
  discard A06(state); discard A06(state)
word=A06(state)
r=A09(word)
level = 1 if r > 0.75 else 0
```

### A11 — Body filter conjunction

- **Inputs:** generated body row, normalised filter object
- **Outputs:** match boolean and reasons
- **Preconditions:** All filters validated for compatibility.
- **Invariant:** Blank/Any filters are not active predicates; every active predicate is AND-combined.

```text
for predicate in active_filters:
  if not predicate(row): return false
return true
```

### A12 — Deterministic multi-worker merge

- **Inputs:** ordered system tasks, worker outputs
- **Outputs:** ordered matches
- **Preconditions:** Each task has a stable scan ordinal.
- **Invariant:** Changing worker count cannot change result order.

```text
generate tasks in requested region/system order
execute independently
buffer by task ordinal
emit completed results only when all earlier ordinals are emitted
```

### A13 — Rendered/native colour separation

- **Inputs:** native colour record, verified rendered mapping table
- **Outputs:** native value plus public rendered family
- **Preconditions:** Native record retained.
- **Invariant:** Presentation mapping never overwrites the native hex, index or internal family.

```text
native = exact_generated_record
rendered = mapping.get(native.hex, native.family_or_unavailable)
return {native, rendered}
```

## Generation-rule catalogue

| Rule Id | Category | Rule | Statement | Operation Type | Exactness | Failure Or Boundary |
|---|---|---|---|---|---|---|
| ADR-001 | Addressing | Portal format | Input must contain exactly 12 hexadecimal glyph digits after separator removal. | reject | exact | Unavailable/reject when preconditions are not met. |
| ADR-002 | Addressing | Body nibble | First digit 0 is a system target; 1–6 maps to internal slot 0–5. | transform | exact | Unavailable/reject when preconditions are not met. |
| ADR-003 | Addressing | Canonical system | System generation always uses a zero-prefixed canonical address. | transform | exact | Unavailable/reject when preconditions are not met. |
| ADR-004 | Addressing | SSI extraction | Digits 2–4 are parsed as one unsigned 12-bit solar-system index. | transform | exact | Unavailable/reject when preconditions are not met. |
| ADR-005 | Addressing | Region suffix | Digits 5–12 are preserved as the region suffix. | transform | exact | Unavailable/reject when preconditions are not met. |
| ADR-006 | Addressing | Galaxy index | User galaxy number N maps to internal generator index N-1. | transform | exact | Unavailable/reject when preconditions are not met. |
| DOM-001 | Portal domains | Standard occupancy | A standard SSI is real only when SSI < the exact generated legacy-system count for that region. | branch | exact | Unavailable/reject when preconditions are not met. |
| DOM-002 | Portal domains | Purple interval | Purple portal destinations occupy SSI 0x3E9 through 0x428 inclusive. | branch | exact mapped interval | Unavailable/reject when preconditions are not met. |
| DOM-003 | Portal domains | Rejected upper bound | SSI 0x429 is not a direct Purple portal destination. | branch | exact mapped boundary | Unavailable/reject when preconditions are not met. |
| DOM-004 | Portal domains | Unmapped gap | SSI 0x300 through 0x3E8 is excluded from Finder travel results. | branch | bounded | Unavailable/reject when preconditions are not met. |
| DOM-005 | Portal domains | No range wrap | A system scan cannot wrap beyond the selected domain maximum. | validation | exact | Unavailable/reject when preconditions are not met. |
| RNG-001 | Determinism | Unsigned wrapping | 32-bit and 64-bit masks are applied after native-width operations. | numeric | exact | Unavailable/reject when preconditions are not met. |
| RNG-002 | Determinism | MWC multiplier | MWC draws use multiplier 0x5A76F899. | numeric | exact | Unavailable/reject when preconditions are not met. |
| RNG-003 | Determinism | Avalanche constants | Child-seed mixing uses 0x64DD81482CBD31D7 then 0xE36AA5C613612997. | numeric | exact | Unavailable/reject when preconditions are not met. |
| RNG-004 | Determinism | Selector mapping | Range selection uses multiply-high rather than modulo. | numeric | exact | Unavailable/reject when preconditions are not met. |
| RNG-005 | Determinism | Float precision | Native random floats are rounded to IEEE-754 single precision before comparisons. | numeric | exact | Unavailable/reject when preconditions are not met. |
| RNG-006 | Determinism | Draw-order invariant | Conditional discarded draws are part of the model and cannot be removed. | numeric | exact | Unavailable/reject when preconditions are not met. |
| SYS-001 | System generation | System key | Canonical system address and internal galaxy index jointly identify a generated system. | identity | exact | Unavailable/reject when preconditions are not met. |
| SYS-002 | System generation | Planet count | System numeric replay determines the valid body-slot count before body enrichment. | generate | exact | Unavailable/reject when preconditions are not met. |
| SYS-003 | System generation | Star colour | Star type is generated at system scope and copied to every body row. | generate | exact | Unavailable/reject when preconditions are not met. |
| SYS-004 | System generation | Empty state | Empty systems do not expose inhabited economy/race semantics. | branch | exact | Unavailable/reject when preconditions are not met. |
| SYS-005 | System generation | Pirate semantics | Pirate systems retain economy type and dominant race while tier/conflict display as Pirate/Pirate Controlled. | presentation | exact | Unavailable/reject when preconditions are not met. |
| SYS-006 | System generation | Unavailable selectors | Unsolved selectors are emitted as unavailable rather than synthesised. | boundary | exact policy | Unavailable/reject when preconditions are not met. |
| BOD-001 | Body structure | Public numbering | Public planet number equals internal generated slot plus one. | transform | exact | Unavailable/reject when preconditions are not met. |
| BOD-002 | Body structure | Normal moon eligibility | Only eligible large regular planets may generate 0–2 moons. | branch | exact mapped rule | Unavailable/reject when preconditions are not met. |
| BOD-003 | Body structure | Giant moons | Generated giant planets may carry 1–5 moons. | branch | exact mapped rule | Unavailable/reject when preconditions are not met. |
| BOD-004 | Body structure | Gas giant moons | Mapped gas giants expose five generated moon slots. | branch | exact mapped rule | Unavailable/reject when preconditions are not met. |
| BOD-005 | Body structure | Moon parent fields | Every moon row retains its parent portal, name, size, type and ring status. | enrich | exact | Unavailable/reject when preconditions are not met. |
| RNG-007 | Determinism | Root/child separation | A subsystem uses its assigned root or child seed; it cannot borrow state from another subsystem. | numeric | exact | Unavailable/reject when preconditions are not met. |
| RNG-008 | Determinism | No approximate RNG | Standard library random-number generators are not compatible substitutes. | boundary | exact policy | Unavailable/reject when preconditions are not met. |
| BIO-001 | Biome | Native family | Biome family is selected before public classification. | generate | exact | Unavailable/reject when preconditions are not met. |
| BIO-002 | Biome | Subtype 24 | BiomeSubType == 24 is the exact Infested predicate. | branch | exact | Unavailable/reject when preconditions are not met. |
| BIO-003 | Biome | Literal families | Native biome IDs 8, 9 and 10 retain Red, Green and Blue family labels. | presentation | exact | Unavailable/reject when preconditions are not met. |
| BIO-004 | Biome | Source/effective separation | Source biome table and effective public biome are separate fields. | model | exact | Unavailable/reject when preconditions are not met. |
| BIO-005 | Biome | Terrain independence | Terrain selection is independent from biome and subbiome. | dependency | exact | Unavailable/reject when preconditions are not met. |
| BIO-006 | Biome | Floating Islands distinction | Floating Islands terrain is not the same as a prop-based Floating Islands subbiome. | model | exact | Unavailable/reject when preconditions are not met. |
| WAT-001 | Water | Presence gate | Complete water-profile generation is only meaningful when the body has active water. | branch | exact | Unavailable/reject when preconditions are not met. |
| WAT-002 | Water | Style count | Water style selects one record from the 19-entry WATERCOLOURS table. | lookup | exact | Unavailable/reject when preconditions are not met. |
| WAT-003 | Water | Murkiness representation | Murkiness retains both exact source bits and decoded float. | representation | exact | Unavailable/reject when preconditions are not met. |
| WAT-004 | Water | Emission separation | WaterEmission, FoamEmission and DeepWaterBioLum are separate generated outputs. | model | exact | Unavailable/reject when preconditions are not met. |
| WAT-005 | Water | Static/generated separation | Static WATERCOLOURS EmissionColour is not the generated deep-water night-glow palette. | model | exact | Unavailable/reject when preconditions are not met. |
| WAT-006 | Water | Ocean compatibility | Bodies that cannot support oceans reject ocean-required filters. | validation | exact | Unavailable/reject when preconditions are not met. |
| WEA-001 | Weather | Functional state | Weather active/mode/intensity is retained separately from display wording. | model | exact | Unavailable/reject when preconditions are not met. |
| WEA-002 | Weather | Clear/extreme branches | Clear-family and extreme-family branches are derived from generated weather state. | branch | exact | Unavailable/reject when preconditions are not met. |
| WEA-003 | Weather | Storm frequency | Storm frequency is classified as none, occasional, frequent, extreme or special/unknown. | classify | exact/bounded by branch | Unavailable/reject when preconditions are not met. |
| WEA-004 | Weather | Passive hazards | Passive condition fields include exactness/status instead of implying universal certainty. | boundary | bounded | Unavailable/reject when preconditions are not met. |
| RES-001 | Resources | Resource stream | Resource level consumes child seed 1. | dependency | exact | Unavailable/reject when preconditions are not met. |
| RES-002 | Resources | Ordinary branch draws | Two preceding resource-stream words are consumed only for ordinary weighted bodies. | numeric | exact | Unavailable/reject when preconditions are not met. |
| RES-003 | Resources | Resource threshold | Resource level is one only when native float is strictly greater than 0.75. | branch | exact | Unavailable/reject when preconditions are not met. |
| RES-004 | Resources | Substance dependencies | Common substance depends on star/weather; uncommon depends on biome; rare selects from its recovered table. | dependency | exact | Unavailable/reject when preconditions are not met. |
| LIF-001 | Life | Life abundance | Life and CreatureLife are independent generated fields. | generate | exact | Unavailable/reject when preconditions are not met. |
| LIF-002 | Life | Descriptor preservation | All four native creature descriptors are retained before interpretation. | model | exact | Unavailable/reject when preconditions are not met. |
| LIF-003 | Life | Danger boundary | Absence of the DANGEROUS descriptor signal is not proof of no predators. | boundary | exact policy | Unavailable/reject when preconditions are not met. |
| SEN-001 | Sentinels | Difficulty context | Sentinel state is evaluated separately for difficulty indices 0,1,2,3. | dependency | exact | Unavailable/reject when preconditions are not met. |
| SEN-002 | Sentinels | Direct Purple rule | Direct Purple Corrupt branch requires star type 4 and planet index 1. | branch | exact | Unavailable/reject when preconditions are not met. |
| SEN-003 | Sentinels | Portal-safe dissonance | Public Dissonance derives from the native reference-difficulty Corrupt outcome. | presentation | exact | Unavailable/reject when preconditions are not met. |
| SEN-004 | Sentinels | Scrap writer | Salvageable Scrap derives from BuildingLevel/HasScrap replay and retains reason fields. | branch | exact | Unavailable/reject when preconditions are not met. |
| VIS-001 | Surface visuals | Capability/coverage separation | Object-list capability does not guarantee visible coverage or density. | boundary | exact policy | Unavailable/reject when preconditions are not met. |
| VIS-002 | Surface visuals | Grass channels | Grass and GrassAlt are independent generated palette channels. | generate | exact | Unavailable/reject when preconditions are not met. |
| VIS-003 | Surface visuals | Native/rendered separation | Verified rendered annotations do not replace the native RGBA/hex source. | presentation | exact policy | Unavailable/reject when preconditions are not met. |
| ATM-001 | Atmosphere | Palette channels | Cloud, Sky, Horizon, Fog, HeightFog, Sunset and Night are separate generated sequences. | generate | exact | Unavailable/reject when preconditions are not met. |
| ATM-002 | Atmosphere | Native selectors | Day, Dusk and Night native sky-table selections are retained separately. | lookup | exact | Unavailable/reject when preconditions are not met. |
| ATM-003 | Atmosphere | Verified 487CDA mapping | Native Blue #487CDA presents as Pink / Magenta on the verified control and is labelled accordingly at presentation layer. | presentation | verified bounded mapping | Unavailable/reject when preconditions are not met. |
| ATM-004 | Atmosphere | Unmapped rendered sky | No global rendered-family claim is made for native values without a verified mapping. | boundary | exact policy | Unavailable/reject when preconditions are not met. |
| RNG-009 | Determinism | Seed identity | System-level and body-level name generation use different deterministic identities. | dependency | exact | Unavailable/reject when preconditions are not met. |
| NAM-001 | Names | Default state | Generated names are default names and do not include player discovery renames. | boundary | exact policy | Unavailable/reject when preconditions are not met. |
| NAM-002 | Names | Language scope | Exact procedural naming is English in the current model. | boundary | exact | Unavailable/reject when preconditions are not met. |
| RNG-010 | Determinism | Canonical system naming | System name consumes canonical system address plus galaxy, not the requested body nibble. | dependency | exact | Unavailable/reject when preconditions are not met. |
| SEA-001 | Search | Predicate conjunction | All active filters are combined with logical AND. | filter | exact | Unavailable/reject when preconditions are not met. |
| SEA-002 | Search | Any/blank semantics | Blank or Any means no predicate for that property. | filter | exact | Unavailable/reject when preconditions are not met. |
| SEA-003 | Search | Scan order | Result order follows requested region order then system order then generated body order. | ordering | exact | Unavailable/reject when preconditions are not met. |
| SEA-004 | Search | Worker invariance | Worker count changes throughput but not match ordering or generated values. | ordering | exact | Unavailable/reject when preconditions are not met. |
| SEA-005 | Search | Stop limit | Search stops after requested match count unless Don’t stop is active. | control | exact | Unavailable/reject when preconditions are not met. |
| SEA-006 | Search | Real destinations only | Finder enumerates mapped, portal-addressable destinations rather than every raw SSI. | boundary | exact policy | Unavailable/reject when preconditions are not met. |
| FLT-075 | Filter / Planet | Paradise | Requires or excludes the literal Paradise condition. | predicate:tri-state | Exact generated Paradise branch. | Filter compatibility is validated before a search starts. |
| FLT-076 | Filter / Planet | Lush biome | Requires or excludes biome family 0. | predicate:tri-state | Exact biome family. | Filter compatibility is validated before a search starts. |
| FLT-077 | Filter / Water | Ocean type | Filters no ocean, any ocean, regular, deep or high-water ocean states. | predicate:enum | Exact where the body can support the requested ocean; impossible combinations are blocked unless explicitly allowed. | Filter compatibility is validated before a search starts. |
| FLT-078 | Filter / Planet | World Size | Filters planets, giants and moons by public generated size. | predicate:enum | Exact native structure/size mapping. | Filter compatibility is validated before a search starts. |
| FLT-079 | Filter / Planet | Moon parent body | For moon searches, selects normal, giant or gas-giant parent. | predicate:enum | Exact resolved parent row. | Filter compatibility is validated before a search starts. |
| FLT-080 | Filter / Planet | Parent rings | For moon searches, requires or excludes rings on the resolved parent. | predicate:enum | Exact rendered-ring selector. | Filter compatibility is validated before a search starts. |
| FLT-081 | Filter / Planet | Moon count | Filters parent bodies by exact generated moon count. | predicate:enum | Exact generated parent structure. | Filter compatibility is validated before a search starts. |
| FLT-082 | Filter / Planet | Terrain family | Selects the generated terrain family independently of biome/subbiome. | predicate:enum | Exact selector family; final visual asset mix remains bounded. | Filter compatibility is validated before a search starts. |
| FLT-083 | Filter / Planet | Rings | Requires or excludes rendered rings. | predicate:tri-state | Exact for supported current search domains. | Filter compatibility is validated before a search starts. |
| FLT-084 | Filter / Planet | Biome | Filters the generated biome family. | predicate:enum | Exact generated biome enum. | Filter compatibility is validated before a search starts. |
| FLT-085 | Filter / Planet | Allowed subbiomes | Requires at least one selected biome variant. | predicate:multi-select | Exact current biome-table presentation. | Filter compatibility is validated before a search starts. |
| FLT-086 | Filter / Planet | Excluded subbiomes | Rejects selected biome variants. | predicate:multi-select | Exact current biome-table presentation. | Filter compatibility is validated before a search starts. |
| FLT-087 | Filter / Planet | Planet / moon classification | Exact equality filter against the current public classification label. | predicate:enum | Exact current localisation catalog where available; live overrides retained. | Filter compatibility is validated before a search starts. |
| FLT-088 | Filter / Weather | Storm frequency | Filters by functional storm schedule rather than decorative weather name. | predicate:enum | Exact generated active/mode rule; special worlds marked explicitly. | Filter compatibility is validated before a search starts. |
| FLT-089 | Filter / Weather | Passive condition | Filters passive heat, cold, toxicity, radiation, life-support drain or bounded special cases. | predicate:enum | Field carries explicit exactness/boundary metadata. | Filter compatibility is validated before a search starts. |
| FLT-090 | Filter / Weather | Extreme weather | Requires or excludes the exact extreme-weather branch. | predicate:tri-state | Exact generated branch. | Filter compatibility is validated before a search starts. |
| FLT-091 | Filter / Weather | Clear / stormless | Requires or excludes stormless weather. | predicate:tri-state | Exact functional weather state. | Filter compatibility is validated before a search starts. |
| FLT-092 | Filter / Atmosphere | Rendered day-sky family | Filters the user-facing rendered day-sky family. | predicate:enum | Native selector exact; rendered family globally bounded, with verified #487CDA correction. | Filter compatibility is validated before a search starts. |
| FLT-093 | Filter / Atmosphere | Sky palette colour | Matches any colour family present in the generated sky palette. | predicate:enum | Exact generated palette channels. | Filter compatibility is validated before a search starts. |
| FLT-094 | Filter / Atmosphere | Sunset palette colour | Matches generated sunset palette colours. | predicate:enum | Exact generated palette channels. | Filter compatibility is validated before a search starts. |
| FLT-095 | Filter / Atmosphere | Night palette colour | Matches generated night palette colours. | predicate:enum | Exact generated palette channels. | Filter compatibility is validated before a search starts. |
| FLT-096 | Filter / Atmosphere | Cloud palette colour | Matches generated cloud palette colours. | predicate:enum | Exact generated palette channels. | Filter compatibility is validated before a search starts. |
| FLT-097 | Filter / Water | Generated Water colour | Matches the generated Water palette family. | predicate:enum | Exact generated Water channel. | Filter compatibility is validated before a search starts. |
| FLT-098 | Filter / Water | Deep-water biolum colour | Matches the DeepWaterBioLum palette family. | predicate:enum | Exact generated deep-water channel. | Filter compatibility is validated before a search starts. |
| FLT-099 | Filter / Flora / Grass | Generated grass assets | Requires or excludes generated primary-surface grass capability. | predicate:tri-state | Exact object-list capability; not a coverage percentage. | Filter compatibility is validated before a search starts. |
| FLT-100 | Filter / Flora / Grass | Bioluminescent Bubble Grass | Requires or excludes the live-confirmed emissive Bubble-Grass carpet variant. | predicate:tri-state | Exact mapped asset capability. | Filter compatibility is validated before a search starts. |
| FLT-101 | Filter / Flora / Grass | Major mushroom flora set | Requires or excludes major mushroom-style flora assets. | predicate:tri-state | Exact primary-surface object-list capability. | Filter compatibility is validated before a search starts. |
| FLT-102 | Filter / Flora / Grass | Large glowing mushroom trees | Requires or excludes the live-confirmed large glowing mushroom-tree variant. | predicate:tri-state | Exact mapped asset capability. | Filter compatibility is validated before a search starts. |
| FLT-103 | Filter / Flora / Grass | Grass primary colour | Filters the generated Grass slot-0 colour family. | predicate:enum | Exact source index/RGBA/hex; not necessarily the only visible surface colour. | Filter compatibility is validated before a search starts. |
| FLT-104 | Filter / Flora / Grass | GrassAlt primary colour | Filters generated GrassAlt slot-0 family. | predicate:enum | Exact source index/RGBA/hex. | Filter compatibility is validated before a search starts. |
| FLT-105 | Filter / Flora / Grass | Any grass palette slot | Matches any generated Grass or GrassAlt palette slot. | predicate:enum | Exact generated palette sequence. | Filter compatibility is validated before a search starts. |
| FLT-106 | Filter / Fauna | Fauna abundance | Filters generated fauna abundance. | predicate:enum | Exact native Life / CreatureLife replay. | Filter compatibility is validated before a search starts. |
| FLT-107 | Filter / Flora / Grass | Flora abundance | Filters generated flora abundance. | predicate:enum | Exact native abundance token schedule. | Filter compatibility is validated before a search starts. |
| FLT-108 | Filter / Fauna | Fauna profile text | Case-insensitive search inside the structured descriptor profile. | predicate:text | Descriptor profile exact; individual species generation not solved. | Filter compatibility is validated before a search starts. |
| FLT-109 | Filter / Fauna | Fauna archetype signal | Matches mapped community/archetype signals. | predicate:text | Signal-level claim only. | Filter compatibility is validated before a search starts. |
| FLT-110 | Filter / System | Star colour | Filters Yellow, Green, Blue, Red or Purple star type. | predicate:enum | Exact generated star type. | Filter compatibility is validated before a search starts. |
| FLT-111 | Filter / System | Empty system | Requires or excludes empty systems. | predicate:tri-state | Exact address-only system state. | Filter compatibility is validated before a search starts. |
| FLT-112 | Filter / System | Abandoned system | Requires or excludes abandoned systems. | predicate:tri-state | Exact address-only system state. | Filter compatibility is validated before a search starts. |
| FLT-113 | Filter / System | Gas-giant system | Requires or excludes gas-giant systems. | predicate:tri-state | Exact system-state selector; atmosphere assignment remains pending. | Filter compatibility is validated before a search starts. |
| FLT-114 | Filter / System | Outlaw / pirate system | Requires or excludes pirate systems. | predicate:tri-state | Exact system-state selector and public outlaw semantics. | Filter compatibility is validated before a search starts. |
| FLT-115 | Filter / System | Economy type | Filters economy industry. | predicate:enum | Exact when selector data is available. | Filter compatibility is validated before a search starts. |
| FLT-116 | Filter / System | Economy tier | Filters Low, Medium, High, Pirate or at-least-Medium tiers. | predicate:enum | Exact when selector data is available. | Filter compatibility is validated before a search starts. |
| FLT-117 | Filter / System | Conflict level | Filters Low, Medium, High, Pirate Controlled or at-most-Medium. | predicate:enum | Exact when selector data is available. | Filter compatibility is validated before a search starts. |
| FLT-118 | Filter / System | Allowed dominant races | Requires one of the selected races. | predicate:multi-select | Exact when selector data is available. | Filter compatibility is validated before a search starts. |
| FLT-119 | Filter / System | Excluded dominant races | Rejects selected races. | predicate:multi-select | Exact when selector data is available. | Filter compatibility is validated before a search starts. |
| FLT-120 | Filter / Resources | Resource abundance | Filters generated resource-level family. | predicate:enum | Exact recovered writer. | Filter compatibility is validated before a search starts. |
| FLT-121 | Filter / Resources | Common substance | Filters exact common resource ID/name. | predicate:enum | Exact generated substance selector. | Filter compatibility is validated before a search starts. |
| FLT-122 | Filter / Resources | Uncommon substance | Filters exact uncommon resource ID/name. | predicate:enum | Exact generated substance selector. | Filter compatibility is validated before a search starts. |
| FLT-123 | Filter / Resources | Rare substance | Filters exact rare resource ID/name. | predicate:enum | Exact generated substance selector. | Filter compatibility is validated before a search starts. |
| FLT-124 | Filter / Resources | Salvageable Scrap | Requires or excludes Scrap availability. | predicate:tri-state | Exact BuildingLevel / HasScrap replay. | Filter compatibility is validated before a search starts. |
| FLT-125 | Filter / Sentinels | Combat difficulty | Selects one of four native on-foot combat difficulty contexts. | predicate:enum | Exact difficulty replay. | Filter compatibility is validated before a search starts. |
| FLT-126 | Filter / Sentinels | Sentinel activity | Filters the activity enum at the selected difficulty. | predicate:enum | Exact native category. | Filter compatibility is validated before a search starts. |
| FLT-127 | Filter / Sentinels | Legacy Sentinel level | Maximum legacy Sentinel level filter retained for compatibility. | predicate:integer | Prefer the exact difficulty/category controls. | Filter compatibility is validated before a search starts. |
| FLT-128 | Filter / Special | Infested planet | Requires or excludes the exact Infested predicate. | predicate:tri-state | BiomeSubType == 24. | Filter compatibility is validated before a search starts. |
| FLT-129 | Filter / Special | Dissonant / corrupt Sentinel | Requires or excludes portal-safe corrupt Sentinel state. | predicate:tri-state | Exact native reference-difficulty enum plus direct purple rule. | Filter compatibility is validated before a search starts. |

## Claim boundaries

| Topic | Status | Boundary |
|---|---|---|
| Portal reachability | Exact within mapped domains | Finder includes region-resolved occupied standard systems and mapped Purple SSI 0x3E9–0x428. |
| Generated numeric fields | Exact | Requires bit-compatible integer width, float32 rounding and draw order. |
| Static lookup records | Exact current bundled tables | Table contents can change after a major game update. |
| Rendered sky appearance | Partially mapped | Native/generated values are exact; only verified final rendered mappings receive rendered-family labels. |
| Gas-giant atmosphere assignment | Unavailable | Definition records exist but the per-address assignment selector is not claimed. |
| Individual fauna appearance | Unavailable | Life abundance and native descriptors are generated; exact species models/appearance are outside this model. |
| Player discoveries | Out of scope | Renames and discovery-server state are not derivable from an offline address. |

## Worked generation traces

### Purple rendered-sky example — `13F15051E655`

| Field | Value |
|---|---|
| Input Address | 13F15051E655 |
| Galaxy Number User | 1 |
| Canonical System Portal | 03F15051E655 |
| Requested Internal Slot | 0 |
| System Index Hex | 0x3F1 |
| Address Kind | worlds_ii_purple_portal_system |
| Planet Count | 6 |
| Star Colour | Purple |
| System State | Ordinary inhabited |
| Economy | Mining |
| Race | Gek |
| Planet Portal | 03F15051E655 |
| Default Name |  |
| Body Type | 4 |
| Moon Count | 5 |
| Biome | Lush |
| Subtype | 7 |
| Classification | Paradise Giant |
| Terrain |  |
| Water Active | True |
| Water Style |  |
| Weather | Clear lush weather |
| Sentinels |  |
| Life |  |
| Grass Hex |  |
| Native Day Sky |  |
| Rendered Day Sky | Pink / Magenta (verified; native Blue #487CDA) |
| System Name |  |
| Dependency Path | input_decode → reachability → system_seed → system_numeric → body_hierarchy → biome/terrain/water/weather/resources/life/sentinels/visuals → names → presentation |

### Standard multi-body example — `0000656BE199`

| Field | Value |
|---|---|
| Input Address | 0000656BE199 |
| Galaxy Number User | 1 |
| Canonical System Portal | 0000656BE199 |
| Requested Internal Slot | 0 |
| System Index Hex | 0x000 |
| Address Kind | legacy_portal_system |
| Planet Count | 4 |
| Star Colour | Blue |
| System State | Ordinary inhabited |
| Economy | High Tech |
| Race | Gek |
| Planet Portal | 0000656BE199 |
| Default Name |  |
| Body Type | 1 |
| Moon Count | 0 |
| Biome | Frozen |
| Subtype | 24 |
| Classification | Icy Abhorrence |
| Terrain |  |
| Water Active | True |
| Water Style |  |
| Weather | Cold weather |
| Sentinels |  |
| Life |  |
| Grass Hex |  |
| Native Day Sky |  |
| Rendered Day Sky | Blue #93CFFE |
| System Name |  |
| Dependency Path | input_decode → reachability → system_seed → system_numeric → body_hierarchy → biome/terrain/water/weather/resources/life/sentinels/visuals → names → presentation |

### Water-profile example — `21F4FB38537B`

| Field | Value |
|---|---|
| Input Address | 21F4FB38537B |
| Galaxy Number User | 1 |
| Canonical System Portal | 01F4FB38537B |
| Requested Internal Slot | 1 |
| System Index Hex | 0x1F4 |
| Address Kind | legacy_portal_system |
| Planet Count | 6 |
| Star Colour | Yellow |
| System State | Ordinary inhabited |
| Economy | Mercantile |
| Race | Korvax |
| Planet Portal | 11F4FB38537B |
| Default Name |  |
| Body Type | 0 |
| Moon Count | 2 |
| Biome | Lush |
| Subtype | 19 |
| Classification | Paradise Planet |
| Terrain |  |
| Water Active | True |
| Water Style |  |
| Weather | Clear lush weather |
| Sentinels |  |
| Life |  |
| Grass Hex |  |
| Native Day Sky |  |
| Rendered Day Sky | Cyan #AEF2FC |
| System Name |  |
| Dependency Path | input_decode → reachability → system_seed → system_numeric → body_hierarchy → biome/terrain/water/weather/resources/life/sentinels/visuals → names → presentation |

## Generated-field dictionary

The complete field dictionary is provided in `NMS_GENERATED_FIELD_DICTIONARY_V1060.csv` to keep this manual navigable.

## Lookup tables

- Weather hazards: structured records in the JSON specification and static-table browser.
- Gas-giant atmosphere definitions: structured records; per-address assignment remains unavailable.
- WATERCOLOURS styles: all 19 records with static parameters; generated water palettes remain separate.

