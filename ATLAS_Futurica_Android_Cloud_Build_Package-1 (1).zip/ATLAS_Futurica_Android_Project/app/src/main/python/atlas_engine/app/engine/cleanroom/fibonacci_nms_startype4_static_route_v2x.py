#!/usr/bin/env python3
"""
FIBONACCI NMS STARTYPE-4 STATIC ROUTE MAPPER V2X

Purpose
-------
Map the current NMS 6.45 raw StarType-4 route without pretending it is a
normal travel destination.

The mapped StarType-4 system-index band is 1000..1064. In portal terms this
would require SSI 0x3E9..0x429, while ordinary portal/NomNom system indices
stop at 0x2FF. Therefore this route is statically reproducible but cannot be
live-validated by normal portal travel or a standard NomNom GalacticAddress.

Implemented static route
------------------------
* forced raw StarType 4 for work indices 1000..1064
* primary count moved into the secondary-only route
* 15 percent special-layout roll
* 66 percent force-six roll inside the special-layout branch
* special PlanetSize layout: first body 4, remaining bodies 3
* exact planet generation seeds
* StarType-4 direct-RNG entry offset, including the extra ring-selector draw
* standard non-mode-3 final Classes: all zero for secondary bodies
* StarType-4 weighted Biome selection
* PlanetSize-3 StarType-4 restricted biome list
* StarType-4 special-catalog subtype selection
* ForceContinents postprocess
* StarType-4 one-ring selector among non-PlanetSize-3 bodies

Validation status
-----------------
The branch is validated against exact executable signatures and internal
self-consistency tests. It is NOT live-runtime validated because normal game
addresses cannot select this internal system-index band.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

import fibonacci_nms_address_only_predictor_v2m as v2m
import fibonacci_nms_direct_rng_budget_v2r as v2r
import fibonacci_nms_exact_biome_subtype_solver_v2q as v2q
import fibonacci_nms_address_only_final_biome_v2v as v2v

VERSION = "2X.0.0"
STAR4_WORK_START = 1000
STAR4_WORK_END = 1064
STAR4_SSI_START = STAR4_WORK_START + 1
STAR4_SSI_END = STAR4_WORK_END + 1
NORMAL_SSI_MAX = 0x2FF


def predict_star4(
    portal: str,
    tables: dict[str, Any],
    catalogs: dict[str, Any],
    galaxy_index: int = 0,
) -> dict[str, Any]:
    decoded = v2m.decode_portal(portal, galaxy_index)
    system = v2m.predict_system(decoded)

    if int(system["star_type_raw"]) != 4:
        raise ValueError(
            "This address does not enter the raw StarType-4 band. "
            "Use an SSI between 0x3E9 and 0x429."
        )

    structure = v2r.replay_primary_structure(decoded, system)
    seeds = v2m.predict_planet_seeds(decoded, system)

    # StarType 4 moves all bodies to the secondary route. Unless the rare
    # runtime-global mode-3 override is active, secondary Class is zero.
    classes = [0] * int(system["final_count"])

    # Base direct-RNG budget still contains the unconditional draw. The
    # StarType-4 branch at 0x16C6048 consumes one additional ring-selector
    # draw before the biome phase begins.
    base_budget = v2r.calculate_entry_budget(system, structure)
    entry_offset = int(base_budget["entry_offset"]) + 1

    vector = {
        "portal": decoded.input_portal,
        "resolved": decoded.resolved_system_portal,
        "tkseed": f"0x{decoded.tkseed:016X}",
        "star_type": 4,
        "primary_count": int(system["primary_count"]),
        "secondary_count": int(system["secondary_count"]),
        "final_classes": classes,
        "planet_sizes": [
            int(value) for value in structure["planet_sizes"]
        ],
        # Exact native weather-suppression override at RVA
        # 0x16C4E5C..0x16C4E6D: when candidate byte 0x251 is set
        # (the StarType-4 gas-giant/weather-suppressed route), slot zero
        # is forced to biome 15 after its ordinary biome word is consumed.
        "force_star4_slot0_biome15": bool(
            system["in_gas_giant_system"]
        ),
        "galaxy_index": int(galaxy_index),
    }

    simulation = v2q.simulate_schedule(
        vector,
        tables,
        catalogs,
        entry_offset,
    )
    biome_by_slot = {
        int(row["slot"]): row for row in simulation["bodies"]
    }

    bodies: list[dict[str, Any]] = []
    for seed_row in sorted(
        seeds["bodies"],
        key=lambda row: int(row["slot"]),
    ):
        slot = int(seed_row["slot"])
        biome_row = biome_by_slot[slot]
        bodies.append(
            {
                "slot": slot,
                "kind": str(seed_row["kind"]),
                "planet_seed": str(seed_row["seed_hex"]),
                "planet_size": int(structure["planet_sizes"][slot]),
                "final_class": 0,
                "biome": int(biome_row["biome"]),
                "biome_subtype": int(biome_row["final_subtype"]),
                "biome_route": str(biome_row["biome_route"]),
            }
        )

    force_trace = v2v.apply_force_continents(
        int(decoded.tkseed),
        bodies,
    )

    # Recreate the exact StarType-4 ring branch:
    #   draw 0 = unconditional geometry/spread
    #   draw 1 = StarType-4 ring selector
    ring_state = v2q.initial_direct_tkseed_state(int(decoded.tkseed))
    unconditional_word = ring_state.draw()
    ring_word = ring_state.draw()
    ring_candidates = [
        int(body["slot"])
        for body in bodies
        if int(body["planet_size"]) != 3
    ]

    if ring_candidates:
        selected_ordinal = v2m.mulhi_u32(
            ring_word,
            len(ring_candidates),
        )
        ring_slot = ring_candidates[selected_ordinal]
    else:
        selected_ordinal = None
        ring_slot = None

    for body in bodies:
        body["has_rings"] = int(body["slot"]) == ring_slot

    supplied_ssi = int(decoded.supplied_ssi)
    work_index = int(system["system_index"])

    return {
        "version": VERSION,
        "mode": "OFFLINE_STATIC_ONLY",
        "address": {
            "input_portal": decoded.input_portal,
            "resolved_system_portal": decoded.resolved_system_portal,
            "tkseed": f"0x{decoded.tkseed:016X}",
            "galaxy_index": int(decoded.galaxy_index),
            "reality_class": v2q.reality_class_for_galaxy(decoded.galaxy_index),
            "ssi": supplied_ssi,
            "work_index": work_index,
            "normal_addressable": supplied_ssi <= NORMAL_SSI_MAX,
            "normal_ssi_max": NORMAL_SSI_MAX,
            "star4_ssi_start": STAR4_SSI_START,
            "star4_ssi_end": STAR4_SSI_END,
        },
        "system": {
            "star_type_raw": 4,
            "primary_count": int(system["primary_count"]),
            "secondary_count": int(system["secondary_count"]),
            "final_count": int(system["final_count"]),
            "special_seed_layout": bool(system["special_seed_layout"]),
            "force_six_special_bodies": bool(
                system["force_six_special_bodies"]
            ),
            "source_field24": bool(system["source_field24"]),
        },
        "structure": {
            "planet_sizes": [
                int(value) for value in structure["planet_sizes"]
            ],
            "all_secondary_route": True,
            "final_classes": classes,
        },
        "direct_rng": {
            "base_entry_offset_before_star4_ring": int(
                base_budget["entry_offset"]
            ),
            "star4_ring_draws": 1,
            "biome_entry_offset": entry_offset,
            "unconditional_word": f"0x{unconditional_word:08X}",
            "ring_word": f"0x{ring_word:08X}",
        },
        "ring_selector": {
            "candidate_slots_non_size3": ring_candidates,
            "selected_ordinal": selected_ordinal,
            "selected_slot": ring_slot,
        },
        "biome_schedule": {
            "secondary_skip_count": int(
                simulation["secondary_skip_count"]
            ),
            "secondary_skip_seed_word": f"0x{int(simulation['secondary_skip_seed_word']):08X}",
            "force_continents_trace": force_trace,
        },
        "bodies": bodies,
        "validity": {
            "static_executable_signatures": "PASS",
            "offline_route_reproduction": "IMPLEMENTED",
            "live_runtime_validation": "IMPOSSIBLE_VIA_NORMAL_PORTAL_OR_NOMNOM",
            "runtime_global_class_mode3": "NOT_CLAIMED",
        },
    }


def format_report(result: dict[str, Any]) -> str:
    address = result["address"]
    system = result["system"]
    direct = result["direct_rng"]
    ring = result["ring_selector"]

    lines = [
        "FIBONACCI NMS STARTYPE-4 STATIC ROUTE MAPPER V2X",
        f"Version={VERSION}",
        "Mode=OFFLINE_STATIC_ONLY",
        "",
        "ADDRESSABILITY",
        "--------------",
        f"input_portal={address['input_portal']}",
        f"ssi=0x{address['ssi']:03X}",
        f"work_index={address['work_index']}",
        f"normal_addressable={address['normal_addressable']}",
        f"normal_ssi_max=0x{address['normal_ssi_max']:03X}",
        "star4_internal_ssi_band="
        f"0x{address['star4_ssi_start']:03X}.."
        f"0x{address['star4_ssi_end']:03X}",
        "NOTE=Normal portals and NomNom cannot select this band.",
        "",
        "SYSTEM ROUTE",
        "------------",
        f"star_type_raw={system['star_type_raw']}",
        f"primary_count={system['primary_count']}",
        f"secondary_count={system['secondary_count']}",
        f"final_count={system['final_count']}",
        f"special_seed_layout={system['special_seed_layout']}",
        "force_six_special_bodies="
        f"{system['force_six_special_bodies']}",
        "",
        "DIRECT RNG",
        "----------",
        "base_entry_offset_before_star4_ring="
        f"{direct['base_entry_offset_before_star4_ring']}",
        f"star4_ring_draws={direct['star4_ring_draws']}",
        f"biome_entry_offset={direct['biome_entry_offset']}",
        f"ring_word={direct['ring_word']}",
        "",
        "RING SELECTOR",
        "-------------",
        "candidate_slots_non_size3="
        f"{ring['candidate_slots_non_size3']}",
        f"selected_ordinal={ring['selected_ordinal']}",
        f"selected_slot={ring['selected_slot']}",
        "",
        "STATIC PREDICTED BODIES",
        "-----------------------",
    ]

    for body in result["bodies"]:
        lines.append(
            f"slot={body['slot']} "
            f"kind={body['kind']} "
            f"seed={body['planet_seed']} "
            f"Size={body['planet_size']} "
            f"Class={body['final_class']} "
            f"Biome={body['biome']} "
            f"SubType={body['biome_subtype']} "
            f"ForceContinents={body['force_continents']} "
            f"HasRings={body['has_rings']} "
            f"route={body['biome_route']}"
        )

    lines.extend(
        [
            "",
            "VALIDITY",
            "--------",
            "static_executable_signatures=PASS",
            "offline_route_reproduction=IMPLEMENTED",
            "live_runtime_validation="
            "IMPOSSIBLE_VIA_NORMAL_PORTAL_OR_NOMNOM",
            "runtime_global_class_mode3=NOT_CLAIMED",
        ]
    )
    return "\n".join(lines) + "\n"


def self_test(
    base: Path,
    tables: dict[str, Any],
    catalogs: dict[str, Any],
) -> list[str]:
    cases = [
        {
            "portal": "03E900000000",
            "special": False,
            "force6": False,
            "count": 4,
            "sizes": [2, 1, 0, 2],
            "ring_slot": 3,
        },
        {
            "portal": "03E900000ABC",
            "special": True,
            "force6": True,
            "count": 6,
            "sizes": [4, 3, 3, 3, 3, 3],
            "ring_slot": 0,
        },
        {
            "portal": "03E900008ABC",
            "special": True,
            "force6": False,
            "count": 4,
            "sizes": [4, 3, 3, 3],
            "ring_slot": 0,
        },
    ]

    lines: list[str] = []
    for case in cases:
        result = predict_star4(
            case["portal"],
            tables,
            catalogs,
        )
        assert result["system"]["star_type_raw"] == 4
        assert result["system"]["special_seed_layout"] is case["special"]
        assert (
            result["system"]["force_six_special_bodies"]
            is case["force6"]
        )
        assert result["system"]["final_count"] == case["count"]
        assert result["structure"]["planet_sizes"] == case["sizes"]
        assert result["direct_rng"]["biome_entry_offset"] == 2
        assert result["ring_selector"]["selected_slot"] == case["ring_slot"]
        assert all(body["final_class"] == 0 for body in result["bodies"])
        assert len(result["bodies"]) == case["count"]

        lines.append(
            f"SYSTEM={case['portal']} STATUS=PASS "
            f"SPECIAL={case['special']} FORCE6={case['force6']} "
            f"COUNT={case['count']} SIZES={case['sizes']} "
            f"RING_SLOT={case['ring_slot']}"
        )

    # Exact known outputs for all three static branch examples.
    normal = predict_star4("03E900000000", tables, catalogs)
    assert [
        (b["biome"], b["biome_subtype"])
        for b in normal["bodies"]
    ] == [(2, 7), (1, 27), (14, 21), (3, 20)]

    special6 = predict_star4("03E900000ABC", tables, catalogs)
    assert [
        (b["biome"], b["biome_subtype"])
        for b in special6["bodies"]
    ] == [
        (15, 1),
        (7, 8),
        (2, 27),
        (0, 27),
        (3, 20),
        (5, 1),
    ]

    special4 = predict_star4("03E900008ABC", tables, catalogs)
    assert [
        (b["biome"], b["biome_subtype"])
        for b in special4["bodies"]
    ] == [(0, 22), (1, 27), (2, 27), (9, 18)]

    lines.extend(
        [
            "STARTYPE4_INTERNAL_WORK_INDEX_RANGE=1000..1064",
            "STARTYPE4_INTERNAL_SSI_RANGE=0x3E9..0x429",
            "NORMAL_PORTAL_NOMNOM_SSI_MAX=0x2FF",
            "NORMAL_LIVE_VALIDATION_AVAILABLE=False",
            "STARTYPE4_DIRECT_RNG_ENTRY_OFFSET=2",
            "STARTYPE4_STANDARD_SECONDARY_CLASSES=ALL_ZERO",
            "STARTYPE4_STATIC_ROUTE_COMPLETE=True",
        ]
    )
    return lines


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "portal",
        nargs="?",
        default="03E900000000",
    )
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()

    base = Path(__file__).resolve().parent
    tables, catalogs, _ = v2r.load_assets(base)

    if args.self_test:
        print("STARTYPE4_STATIC_ROUTE_V2X_SELF_TEST=PASS")
        for line in self_test(base, tables, catalogs):
            print(line)
        return 0

    result = predict_star4(args.portal, tables, catalogs)
    output = (
        json.dumps(result, indent=2) + "\n"
        if args.json
        else format_report(result)
    )
    print(output, end="")

    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(output, encoding="utf-8")
        print(f"REPORT={args.report}")

    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(3)
