#!/usr/bin/env python3
"""Standalone clean-room candidate planet class and root-seed replay.

This module is APF-owned Python. It reads no game files, process memory,
executables, DLLs, or module dumps. It reproduces the deterministic class and
root-seed schedule used by the mapped NMS 6.45 generation route.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

MASK32 = 0xFFFFFFFF
MASK64 = 0xFFFFFFFFFFFFFFFF
MWC_MULTIPLIER = 0x5A76F899
AVALANCHE_MULTIPLIER_1 = 0x64DD81482CBD31D7
AVALANCHE_MULTIPLIER_2 = 0xE36AA5C613612997
DESCRIPTOR_CAPACITY = 8
CURRENT_BUILD_EXTRA_RECORDS_FLAG = 1


def sign_extend(value: int, bits: int) -> int:
    sign = 1 << (bits - 1)
    return (value & (sign - 1)) - (value & sign)


def normalize_and_repack_address(packed: int) -> dict[str, int]:
    """Clamp the three signed coordinate fields to the native safe extrema."""
    packed &= MASK64
    low32 = packed & MASK32
    x_raw = sign_extend(low32 & 0xFFF, 12)
    z_raw = sign_extend((low32 >> 12) & 0xFFF, 12)
    y_raw = sign_extend((low32 >> 24) & 0xFF, 8)

    x = min(max(x_raw, -2047), 2047)
    z = min(max(z_raw, -2047), 2047)
    y = min(max(y_raw, -127), 127)
    coordinate_bits = (
        (x & 0xFFF)
        | ((z & 0xFFF) << 12)
        | ((y & 0xFF) << 24)
    )
    upper_bits = packed & 0x000FFFFF00000000
    normalized = (upper_bits | coordinate_bits) & MASK64
    return {
        "packed_input": packed,
        "x_raw": x_raw,
        "z_raw": z_raw,
        "y_raw": y_raw,
        "x_normalized": x,
        "z_normalized": z,
        "y_normalized": y,
        "normalized_packed": normalized,
    }


def avalanche_mix_64(value: int) -> int:
    value &= MASK64
    value ^= value >> 33
    value = (value * AVALANCHE_MULTIPLIER_1) & MASK64
    value ^= value >> 33
    value = (value * AVALANCHE_MULTIPLIER_2) & MASK64
    value ^= value >> 33
    return value & MASK64


def rotate_right_32(value: int, count: int) -> int:
    value &= MASK32
    count &= 31
    if not count:
        return value
    return ((value >> count) | (value << (32 - count))) & MASK32


def mulhi_u32(left: int, right: int) -> int:
    return (((left & MASK32) * (right & MASK32)) >> 32) & MASK32


@dataclass
class MWCState:
    low: int
    high: int
    draw_count: int = 0

    @classmethod
    def from_normalized_address(cls, packed: int) -> "MWCState":
        mixed = avalanche_mix_64(packed)
        low = mixed & MASK32
        if low == 0:
            low = 1
        high = (
            rotate_right_32(mixed & MASK32, 16)
            ^ ((mixed >> 32) & MASK32)
            ^ (mixed & MASK32)
        ) & MASK32
        return cls(low=low, high=high)

    def draw(self, role: str, trace: list[dict[str, Any]]) -> int:
        product = (
            (self.low & MASK32) * MWC_MULTIPLIER
            + (self.high & MASK32)
        ) & MASK64
        self.low = product & MASK32
        self.high = (product >> 32) & MASK32
        self.draw_count += 1
        trace.append({
            "draw": self.draw_count,
            "draw_index": self.draw_count - 1,
            "role": role,
            "low": self.low,
            "low_hex": f"0x{self.low:08X}",
            "high": self.high,
            "high_hex": f"0x{self.high:08X}",
        })
        return self.low


def make_seed_from_two_draws(
    state: MWCState,
    role_prefix: str,
    trace: list[dict[str, Any]],
) -> tuple[int, int, list[int]]:
    first_index = state.draw_count
    first_low = state.draw(f"{role_prefix}_draw_1", trace)
    second_index = state.draw_count
    second_low = state.draw(f"{role_prefix}_draw_2", trace)
    combined = ((second_low & MASK32) << 32) | (first_low & MASK32)
    return combined, avalanche_mix_64(combined), [first_index, second_index]


def replay_candidate_arrays(
    packed_address: int,
    *,
    primary_count: int,
    secondary_count: int,
    weather_suppression: int,
    flag_252: int,
    derived_source_flag: int,
    global_extra_records_flag: int = CURRENT_BUILD_EXTRA_RECORDS_FLAG,
    capacity: int = DESCRIPTOR_CAPACITY,
) -> dict[str, Any]:
    if primary_count < 0 or secondary_count < 0:
        raise RuntimeError("Negative candidate-context record count.")
    total_count = primary_count + secondary_count
    if total_count > capacity:
        raise RuntimeError(
            f"Candidate-context total {total_count} exceeds capacity {capacity}."
        )

    normalization = normalize_and_repack_address(packed_address)
    normalized_packed = int(normalization["normalized_packed"])
    state = MWCState.from_normalized_address(normalized_packed)
    initial_state = {"low": state.low, "high": state.high}
    trace: list[dict[str, Any]] = []
    root_seeds: list[int | None] = [None] * capacity
    raw_seed_materials: list[int | None] = [None] * capacity
    seed_draw_indices: list[list[int]] = [[] for _ in range(capacity)]
    valid_flags: list[int] = [0] * capacity
    deep_classes: list[int | None] = [None] * capacity
    auxiliary_parent_indices: list[int] = [0] * capacity
    classification_draw_indices: list[int | None] = [None] * capacity

    native_extra_stop_index = (int(derived_source_flag) - 1) & MASK32
    special_branch = bool(flag_252 or weather_suppression)

    if special_branch:
        for index in range(total_count):
            deep_classes[index] = 4 if index == 0 else 3
            raw, seed, indices = make_seed_from_two_draws(
                state, f"special_record_{index}_seed", trace
            )
            raw_seed_materials[index] = raw
            root_seeds[index] = seed
            seed_draw_indices[index] = indices
            valid_flags[index] = 1
            if index:
                auxiliary_parent_indices[index] = 0
        branch = "special_flag_252_or_weather_suppression"
    else:
        generated = 0
        class_index = 0
        while generated < primary_count:
            draw_index = state.draw_count
            low = state.draw(f"primary_class_{class_index}", trace)
            parent_index = generated
            generated += 1
            deep_class = mulhi_u32(low, 3)
            deep_classes[class_index] = deep_class
            classification_draw_indices[class_index] = draw_index
            class_index += 1

            if deep_class == 0 and global_extra_records_flag:
                remaining = max(primary_count - generated, 0)
                bounded = min(remaining, 2)
                state.draw(
                    f"primary_class_{class_index - 1}_extra_count", trace
                )
                extra_draw = trace[-1]["low"]
                extra_count = mulhi_u32(extra_draw, bounded + 1)
                for _ in range(extra_count):
                    if generated == native_extra_stop_index:
                        break
                    deep_classes[class_index] = 3
                    auxiliary_parent_indices[class_index] = parent_index
                    generated += 1
                    class_index += 1

        for index in range(primary_count):
            raw, seed, indices = make_seed_from_two_draws(
                state, f"primary_record_{index}_seed", trace
            )
            raw_seed_materials[index] = raw
            root_seeds[index] = seed
            seed_draw_indices[index] = indices
            valid_flags[index] = 1

        record_index = primary_count
        while record_index < total_count:
            class_draw_index = state.draw_count
            class_low = state.draw(
                f"secondary_record_{record_index}_class_draw_A", trace
            )
            parent_index = record_index
            deep_class = mulhi_u32(class_low, 3)
            deep_classes[record_index] = deep_class
            classification_draw_indices[record_index] = class_draw_index

            raw, seed, indices = make_seed_from_two_draws(
                state, f"secondary_record_{record_index}_seed", trace
            )
            raw_seed_materials[record_index] = raw
            root_seeds[record_index] = seed
            seed_draw_indices[record_index] = indices
            valid_flags[record_index] = 1
            record_index += 1

            if deep_class == 0 and global_extra_records_flag:
                remaining = max(total_count - record_index, 0)
                bounded = min(remaining, 2)
                extra_draw = state.draw(
                    f"secondary_record_{parent_index}_extra_count_draw_D", trace
                )
                extra_count = mulhi_u32(extra_draw, bounded + 1)
                for _ in range(extra_count):
                    if record_index == native_extra_stop_index:
                        break
                    deep_classes[record_index] = 3
                    raw, seed, indices = make_seed_from_two_draws(
                        state,
                        f"secondary_inserted_record_{record_index}_seed",
                        trace,
                    )
                    raw_seed_materials[record_index] = raw
                    root_seeds[record_index] = seed
                    seed_draw_indices[record_index] = indices
                    valid_flags[record_index] = 1
                    auxiliary_parent_indices[record_index] = parent_index
                    record_index += 1
        branch = "ordinary"

    return {
        "branch": branch,
        "normalization": normalization,
        "normalized_packed": normalized_packed,
        "mixed_system_seed": avalanche_mix_64(normalized_packed),
        "initial_state": initial_state,
        "final_state": {
            "low": state.low,
            "high": state.high,
            "draws_consumed": state.draw_count,
        },
        "draw_count": state.draw_count,
        "root_seeds": root_seeds,
        "raw_seed_materials": raw_seed_materials,
        "seed_draw_indices": seed_draw_indices,
        "valid_flags": valid_flags,
        "deep_classes": deep_classes,
        "auxiliary_parent_indices": auxiliary_parent_indices,
        "classification_draw_indices": classification_draw_indices,
        "draw_trace": trace,
        "global_extra_records_flag": int(bool(global_extra_records_flag)),
    }
