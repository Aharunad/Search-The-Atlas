"""ATLAS APF Android bridge. Search runs locally inside the app via Chaquopy."""
import json, sys, threading, time, traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parent / 'atlas_engine'
APP = ROOT / 'app'
if str(APP) not in sys.path:
    sys.path.insert(0, str(APP))

import any_planet_finder_core as core

_lock = threading.RLock()
_cancel = threading.Event()
_pause = threading.Event()
_state = {"running": False, "paused": False, "status": "Ready", "tested_systems": 0,
          "tested_planets": 0, "matches": [], "error": None, "system_limit": 0,
          "batch": 64, "until_found": True, "target": 1, "request": {}}
_worker = None
_last_args = None
_next_start = 0

def _progress(done, total, message):
    with _lock:
        _state["tested_systems"] = int(done or 0)
        _state["status"] = str(message or "Searching")

def _paused():
    while _pause.is_set() and not _cancel.is_set():
        time.sleep(0.15)
    return False

def start_search(payload_json):
    global _worker, _last_args, _next_start
    try:
        payload = json.loads(payload_json or '{}')
        filters = payload.get('filters', payload)
        portal = str(filters.get('portal', '')).strip().upper()
        if not portal:
            raise ValueError('Enter a portal address before starting a real search.')
        galaxy = int(filters.get('galaxy', 0) or 0)
        batch = max(1, int(filters.get('batch', 64) or 64))
        limit = max(batch, int(filters.get('systemLimit', 6400) or 6400))
        target = max(1, int(filters.get('stopAfter', 1) or 1))
        until = bool(filters.get('until', True))
        args = {"anchor_portal": portal, "galaxy": galaxy, "result_limit": target,
                "system_workers": 1, "progress": _progress, "cancel": _cancel.is_set,
                "pause": _paused}
        # Only map filter values whose semantics match an exposed core parameter.
        if filters.get('paradise'): args['paradise'] = True
        if filters.get('mustWater') or filters.get('water') == 'required': args['water'] = True
        if filters.get('extreme') == 'exclude': args['non_extreme'] = True
        if filters.get('weather') and str(filters.get('weather')).lower() not in ('any','all',''):
            args['weather_family'] = str(filters['weather'])
        if filters.get('size') and str(filters.get('size')).lower() not in ('any','all',''):
            args['world_size'] = str(filters['size'])
        if filters.get('terrainSettings'):
            # One selected family per pass is not silently treated as an OR by the core.
            args['terrain_setting'] = str(filters['terrainSettings'][0])
        with _lock:
            _cancel.clear(); _pause.clear()
            _state.update({"running": True, "paused": False, "status": "Starting engine scan", "tested_systems": 0,
                "tested_planets": 0, "matches": [], "error": None, "system_limit": limit,
                "batch": batch, "until_found": until, "target": target, "request": payload})
        with _lock:
            _last_args = args
            _next_start = 0
        _worker = threading.Thread(target=_run_scan, args=(args,), daemon=True)
        _worker.start()
    except Exception as e:
        with _lock: _state.update({"running": False, "status": "Could not start search", "error": str(e)})

def _run_scan(args):
    global _next_start
    with _lock: start = _next_start
    try:
        while not _cancel.is_set():
            with _lock:
                limit = int(_state['system_limit']); batch = int(_state['batch'])
                until = bool(_state['until_found']); target = int(_state['target'])
                current_matches = len(_state['matches'])
            if start >= limit or (until and current_matches >= target): break
            count = min(batch, limit - start)
            result = core.find_planets(start_system=start, system_count=count, **args)
            matches = result.get('matches', []) or []
            with _lock:
                known = {json.dumps(x, sort_keys=True, default=str) for x in _state['matches']}
                for item in matches:
                    key = json.dumps(item, sort_keys=True, default=str)
                    if key not in known:
                        _state['matches'].append(item); known.add(key)
                _state['tested_systems'] = start + int(result.get('tested_systems', count) or count)
                _state['tested_planets'] += int(result.get('tested_planets', 0) or 0)
                _state['status'] = 'Found target' if len(_state['matches']) >= target else f"Scanned through system {start + count}"
            start += count
            with _lock: _next_start = start
            if not until and start >= limit: break
        with _lock:
            _state['running'] = False
            _state['status'] = 'Stopped' if _cancel.is_set() else ('Target reached' if len(_state['matches']) >= _state['target'] else 'Search limit reached')
    except Exception as e:
        with _lock: _state.update({"running": False, "status": "Engine error", "error": str(e), "traceback": traceback.format_exc()})

def set_paused(value):
    if value: _pause.set()
    else: _pause.clear()
    with _lock: _state['paused'] = bool(value); _state['status'] = 'Paused' if value else ('Searching' if _state['running'] else _state['status'])

def extend_search(systems):
    global _worker
    restart = False
    with _lock:
        _state['system_limit'] += max(1, int(systems or _state['batch']))
        _state['until_found'] = False
        _state['status'] = 'Search range extended'
        if not _state['running'] and _last_args is not None and _next_start < _state['system_limit']:
            _cancel.clear(); _pause.clear(); _state['running'] = True; restart = True
            args = _last_args
    if restart:
        _worker = threading.Thread(target=_run_scan, args=(args,), daemon=True)
        _worker.start()

def set_until_found(value):
    global _worker
    restart = False
    with _lock:
        _state['until_found'] = bool(value)
        if value and not _state['running'] and _last_args is not None and len(_state['matches']) < _state['target']:
            _cancel.clear(); _pause.clear(); _state['running'] = True; restart = True; args = _last_args
    if restart:
        _worker = threading.Thread(target=_run_scan, args=(args,), daemon=True)
        _worker.start()

def stop_search():
    _cancel.set(); _pause.clear()

def get_status_json():
    with _lock: return json.dumps(_state, default=str)
